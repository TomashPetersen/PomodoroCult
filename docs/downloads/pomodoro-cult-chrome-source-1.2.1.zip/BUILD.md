# Pomodoro Cult 1.2.1 - исходники выпуска для Chrome

Исходники приложения распространяются по Mozilla Public License 2.0. Текст
лицензии находится в файле LICENSE. Авторы и лицензии звуков указаны в
docs/chrome-store/audio-credits.txt.

## Сборка

Распакуйте архив в отдельную папку. Команды для Windows с Node.js 24.15.0,
npm 11.12.1 и PowerShell 7.6.9:

```powershell
npm.cmd ci --no-audit --no-fund
$env:TARGET_BROWSER = 'chrome'
npm.cmd run build
.\scripts\package-chrome-artifacts.ps1
```

При наличии зависимостей в локальном кеше можно выполнить
`npm.cmd ci --offline --no-audit --no-fund`. Номера версий зависимостей и
контрольные суммы закреплены в package-lock.json.

Результат: artifacts/pomodoro-cult-chrome-1.2.1.zip. Принятый пакет имеет
SHA-256 44a4ee2021ec5ea212d48a2159b72b2cde306e82e127dbf2c4e7e2dc490c2222.

Архив содержит исходники и ресурсы для выпуска Chrome. Файлы сборки ссылаются
на манифест Firefox, поэтому он входит в архив. Ресурсы исключительно для
Firefox, рабочие документы и готовые пакеты исключены.
