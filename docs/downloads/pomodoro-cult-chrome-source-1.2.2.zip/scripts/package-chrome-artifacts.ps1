Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$repoRoot = Split-Path -Parent $PSScriptRoot
$distDir = Join-Path $repoRoot 'dist'
$distManifestPath = Join-Path $distDir 'manifest.json'
if (!(Test-Path -LiteralPath $distManifestPath -PathType Leaf)) {
  throw "Chrome build not found. Run 'npm.cmd run build' first."
}

$sourceManifest = Get-Content -LiteralPath (Join-Path $repoRoot 'manifest.json') -Raw | ConvertFrom-Json
$manifest = Get-Content -LiteralPath $distManifestPath -Raw | ConvertFrom-Json
$version = $manifest.version
if ($version -notmatch '^\d+\.\d+\.\d+$' -or $version -ne $sourceManifest.version) {
  throw 'Built Chrome version does not match the source manifest. Rebuild before packaging.'
}

$permissions = ($manifest.permissions | Sort-Object) -join ','
if (
  $manifest.manifest_version -ne 3 -or
  $manifest.background.service_worker -cne 'service-worker-loader.js' -or
  $manifest.action.default_popup -cne 'index.html' -or
  $manifest.default_locale -cne 'en' -or
  $permissions -cne 'alarms,notifications,offscreen,storage' -or
  $manifest.PSObject.Properties['browser_specific_settings'] -or
  $manifest.PSObject.Properties['host_permissions'] -or
  $manifest.PSObject.Properties['optional_host_permissions'] -or
  $manifest.PSObject.Properties['optional_permissions'] -or
  $manifest.PSObject.Properties['content_scripts']
) {
  throw 'Built Chrome manifest does not match the release contract.'
}

$requiredFiles = @(
  'manifest.json', 'service-worker-loader.js', 'index.html', 'app.html', 'offscreen.html',
  '_locales/en/messages.json', '_locales/ru/messages.json',
  'icons/icon-16.png', 'icons/icon-32.png', 'icons/icon-48.png', 'icons/icon-128.png',
  'sounds/focus-birds.ogg', 'sounds/focus-clock.wav', 'sounds/focus-stream.ogg'
)
$unusedPublicFiles = @(
  'icons/firefox-icon-16.png', 'icons/firefox-icon-32.png', 'icons/firefox-icon-48.png', 'icons/firefox-icon-128.png',
  'icons/firefox-tomato-icon-16.png', 'icons/firefox-tomato-icon-32.png',
  'icons/firefox-tomato-icon-48.png', 'icons/firefox-tomato-icon-128.png',
  'sounds/firefox-completion-chime.mp3', 'sounds/completion-chime.mp3'
)

$files = [ordered]@{}
foreach ($file in Get-ChildItem -LiteralPath $distDir -Recurse -File -Force | Sort-Object FullName) {
  $entryName = $file.FullName.Substring($distDir.Length + 1).Replace('\', '/')
  if ($entryName -cin $unusedPublicFiles) {
    continue
  }
  if (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or (
    $entryName -cnotin $requiredFiles -and $entryName -cnotmatch '^assets/[A-Za-z0-9_.-]+-[a-f0-9]+\.(js|css)$'
  )) {
    throw "Unexpected Chrome build file: $entryName"
  }
  if ($file.Extension -in '.html', '.js', '.css') {
    $contents = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8
    if ($contents -match 'PHASE4_DEV_ACCESS_SIMULATOR_|sourceMappingURL=|@vite/client') {
      throw "Development material in Chrome build file: $entryName"
    }
  }
  $files.Add($entryName, $file.FullName)
}
foreach ($requiredFile in $requiredFiles) {
  if (!$files.Contains($requiredFile)) {
    throw "Required Chrome build file is missing: $requiredFile"
  }
  if ($requiredFile -match '^(icons|sounds)/') {
    $sourceAsset = Join-Path $repoRoot "public/$requiredFile"
    if ((Get-FileHash -LiteralPath $files[$requiredFile]).Hash -ne (Get-FileHash -LiteralPath $sourceAsset).Hash) {
      throw "Stale Chrome build asset: $requiredFile"
    }
  }
}
foreach ($locale in 'en', 'ru') {
  $entryName = "_locales/$locale/messages.json"
  $sourceMessages = Get-Content -LiteralPath (Join-Path $repoRoot $entryName) -Raw -Encoding UTF8 | ConvertFrom-Json
  $builtMessages = Get-Content -LiteralPath $files[$entryName] -Raw -Encoding UTF8 | ConvertFrom-Json
  if (
    $builtMessages.appName.message -cne $sourceMessages.appName.message -or
    $builtMessages.appDescription.message -cne $sourceMessages.appDescription.message
  ) {
    throw "Stale Chrome build locale: $locale"
  }
}

$files.Add('LICENSE', (Join-Path $repoRoot 'LICENSE'))
$files.Add('AUDIO-CREDITS.txt', (Join-Path $repoRoot 'docs/chrome-store/audio-credits.txt'))
$files.Add('SOURCE.txt', (Join-Path $repoRoot 'docs/chrome-store/source-notice.txt'))
foreach ($dependency in 'lucide-react', 'react', 'react-dom', 'scheduler', 'zustand') {
  $files.Add("LICENSES/$dependency.txt", (Join-Path $repoRoot "node_modules/$dependency/LICENSE"))
}

$artifactsDir = Join-Path $repoRoot 'artifacts'
New-Item -ItemType Directory -Force -Path $artifactsDir | Out-Null
$zipPath = Join-Path $artifactsDir "pomodoro-cult-chrome-$version.zip"
$tempZipPath = Join-Path $artifactsDir "pomodoro-cult-chrome-$version-$([guid]::NewGuid()).tmp"

try {
  $archive = [IO.Compression.ZipFile]::Open($tempZipPath, [IO.Compression.ZipArchiveMode]::Create)
  try {
    foreach ($entryName in $files.Keys) {
      $entry = $archive.CreateEntry($entryName, [IO.Compression.CompressionLevel]::Optimal)
      $entry.LastWriteTime = [DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
      $fileStream = [IO.File]::OpenRead($files[$entryName])
      try {
        $entryStream = $entry.Open()
        try {
          $fileStream.CopyTo($entryStream)
        } finally {
          $entryStream.Dispose()
        }
      } finally {
        $fileStream.Dispose()
      }
    }
  } finally {
    $archive.Dispose()
  }

  Move-Item -LiteralPath $tempZipPath -Destination $zipPath -Force
} finally {
  if (Test-Path -LiteralPath $tempZipPath) {
    Remove-Item -LiteralPath $tempZipPath -Force
  }
}

Write-Output "Created $zipPath"
Get-FileHash -LiteralPath $zipPath -Algorithm SHA256
