export const isFocusPlanEditorActive = (
  editingPlanId: string | null,
  title: string,
  stepCount: number
): boolean => editingPlanId !== null || title.length > 0 || stepCount > 0;

export const canSelectFocusPlan = (
  selectedPlanId: string | null,
  nextPlanId: string,
  editorActive: boolean
): boolean => !editorActive || selectedPlanId === nextPlanId;

export const isFocusPlanEditSelectionValid = (
  editingPlanId: string | null,
  selectedPlanId: string | null
): boolean => editingPlanId === null || editingPlanId === selectedPlanId;
