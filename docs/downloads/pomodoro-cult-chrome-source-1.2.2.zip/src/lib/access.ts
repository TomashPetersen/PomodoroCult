import { AccessContext, ProFeature } from './types';

export const PRO_FEATURES: Readonly<Record<ProFeature, { label: string }>> = {
  focusPlans: { label: 'Focus Plans' },
  taskTemplates: { label: 'Task templates' },
  recurringPlans: { label: 'Recurring plans' }
};

export const DEFAULT_ACCESS_CONTEXT: AccessContext = {
  tier: 'free',
  entitlementStatus: 'none'
};

export const canUseFeature = (
  feature: ProFeature,
  context: AccessContext
): boolean =>
  Object.prototype.hasOwnProperty.call(PRO_FEATURES, feature) &&
  context.tier === 'pro' &&
  (context.entitlementStatus === 'valid' || context.entitlementStatus === 'grace');

export const requireFeature = (feature: ProFeature, context: AccessContext): void => {
  if (!canUseFeature(feature, context)) {
    throw new Error('FEATURE_ACCESS_DENIED');
  }
};
