import { AccessContext } from './types';

export interface RuntimeAccessDiagnosticsBridge {
  getAccessContext(): AccessContext;
  handleMessage(message: unknown): Promise<Record<string, unknown> | null>;
}

export interface RuntimeAccessDiagnosticsDependencies {
  enqueue<T>(operation: () => Promise<T> | T): Promise<T>;
  broadcast(message: unknown): Promise<void>;
}
