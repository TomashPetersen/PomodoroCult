import {
  applyLiveFocusMusicSettings,
  applyManualSettings,
  applySelectedFocusMode,
  createCustomFocusMode,
  deleteCustomFocusMode,
  normalizeFocusModes,
  resolveActiveWorkFocusMusicSettings,
  updateCustomFocusMode
} from './focusModes';
import { FOCUS_MUSIC_TRACKS } from './constants';
import { areTimerDurationsLocked, normalizeSettings } from './storage';
import { DEFAULT_SETTINGS, RuntimeMessage, Settings, StoredData } from './types';

export type FocusModeMutationMessage = Extract<
  RuntimeMessage,
  | { type: 'SELECT_FOCUS_MODE' }
  | { type: 'CREATE_FOCUS_MODE' }
  | { type: 'UPDATE_FOCUS_MODE' }
  | { type: 'DELETE_FOCUS_MODE' }
  | { type: 'SET_TASK_FOCUS_MODE' }
  | { type: 'SAVE_MANUAL_SETTINGS' }
  | { type: 'SAVE_FOCUS_MUSIC_SETTINGS' }
>;

export interface FocusModeMutationResult {
  patch: Partial<StoredData>;
  focusModeId?: string;
}

export interface FocusModeMutationContext {
  now: number;
  includePlanningCascade: boolean;
}

const mergeChangedSettings = (
  data: StoredData,
  payload: Extract<RuntimeMessage, { type: 'SAVE_MANUAL_SETTINGS' }>['payload']
): Settings => {
  const changedKeys: unknown = payload.changedKeys;
  if (!Array.isArray(changedKeys) ||
      Reflect.ownKeys(changedKeys).length !== changedKeys.length + 1) {
    throw new Error('Invalid settings change list.');
  }
  const requested: unknown = payload.settings;
  if (!requested || typeof requested !== 'object' || Array.isArray(requested)) {
    throw new Error('Invalid settings changes.');
  }

  const keys = new Set<keyof Settings>();
  const merged = { ...data.settings };
  for (let index = 0; index < changedKeys.length; index += 1) {
    const key: unknown = changedKeys[index];
    if (!Object.prototype.hasOwnProperty.call(changedKeys, index) ||
        typeof key !== 'string' ||
        !Object.prototype.hasOwnProperty.call(DEFAULT_SETTINGS, key) ||
        keys.has(key as keyof Settings) ||
        !Object.prototype.hasOwnProperty.call(requested, key)) {
      throw new Error('Invalid settings change list.');
    }
    keys.add(key as keyof Settings);
    Object.assign(merged, { [key]: (requested as Record<string, unknown>)[key] });
  }

  const settings = normalizeSettings(merged);
  for (const key of keys) {
    if (!Object.is(merged[key], settings[key])) {
      throw new Error(`Invalid setting value: ${key}.`);
    }
  }
  if (settings.shortBreak > settings.longBreak) {
    throw new Error('Short break cannot be longer than long rest.');
  }
  if (areTimerDurationsLocked(data.settings, data.timerState) &&
      (['workTime', 'shortBreak', 'longBreak'] as const).some((key) =>
        keys.has(key) && settings[key] !== data.settings[key])) {
    throw new Error('Timer durations cannot be changed during an active cycle.');
  }
  return settings;
};

export const applyFocusModeMutation = (
  data: StoredData,
  message: FocusModeMutationMessage,
  context: FocusModeMutationContext = { now: Date.now(), includePlanningCascade: true }
): FocusModeMutationResult => {
  switch (message.type) {
    case 'SELECT_FOCUS_MODE':
      return { patch: applySelectedFocusMode(data, message.payload.focusModeId) };

    case 'CREATE_FOCUS_MODE': {
      const created = createCustomFocusMode(data.focusModes, message.payload.values);
      return {
        patch: { focusModes: created.focusModes },
        focusModeId: created.focusMode.id
      };
    }

    case 'UPDATE_FOCUS_MODE': {
      const updated = updateCustomFocusMode(
        data.focusModes,
        message.payload.focusModeId,
        message.payload.values
      );
      const nextData = { ...data, focusModes: updated.focusModes };
      return {
        patch: {
          focusModes: updated.focusModes,
          ...(data.selectedFocusModeId === message.payload.focusModeId
            ? applySelectedFocusMode(nextData, message.payload.focusModeId)
            : {})
        },
        focusModeId: updated.focusMode.id
      };
    }

    case 'DELETE_FOCUS_MODE': {
      const patch: Partial<StoredData> = deleteCustomFocusMode(data, message.payload.focusModeId);
      if (!context.includePlanningCascade) return { patch };

      const taskTemplates = data.taskTemplates.map((template) =>
        template.focusModeId === message.payload.focusModeId
          ? {
              ...template,
              focusModeId: null,
              updatedAt: Math.max(template.createdAt, template.updatedAt, context.now)
            }
          : template
      );
      const focusPlans = data.focusPlans.map((plan) => {
        const changed = plan.steps.some((step) => step.focusModeIdSnapshot === message.payload.focusModeId);
        return changed
          ? {
              ...plan,
              steps: plan.steps.map((step) =>
                step.focusModeIdSnapshot === message.payload.focusModeId
                  ? { ...step, focusModeIdSnapshot: null }
                  : step
              ),
              updatedAt: Math.max(plan.createdAt, plan.updatedAt, context.now)
            }
          : plan;
      });
      if (taskTemplates.some((template, index) => template !== data.taskTemplates[index])) {
        patch.taskTemplates = taskTemplates;
      }
      if (focusPlans.some((plan, index) => plan !== data.focusPlans[index])) {
        patch.focusPlans = focusPlans;
      }
      return { patch };
    }

    case 'SET_TASK_FOCUS_MODE': {
      const target = data.tasks.find((task) => task.id === message.payload.taskId);
      if (!target || target.system) throw new Error('Task not found.');
      const focusModeId = message.payload.focusModeId;
      if (focusModeId && !normalizeFocusModes(data.focusModes).some((mode) => mode.id === focusModeId)) {
        throw new Error('Focus Mode not found.');
      }
      return {
        patch: {
          tasks: data.tasks.map((task) =>
            task.id === target.id ? { ...task, focusModeId } : task
          )
        }
      };
    }

    case 'SAVE_MANUAL_SETTINGS': {
      const settings = message.payload.changedKeys === undefined
        ? normalizeSettings(message.payload.settings)
        : mergeChangedSettings(data, message.payload);
      return { patch: applyManualSettings(data, settings) };
    }

    case 'SAVE_FOCUS_MUSIC_SETTINGS': {
      const current = resolveActiveWorkFocusMusicSettings(data.settings, data.timerState);
      const payload = message.payload;
      let audioPatch: Partial<typeof current>;

      switch (payload.type) {
        case 'toggle':
          audioPatch = { focusMusicEnabled: !current.focusMusicEnabled };
          break;
        case 'set-enabled':
          if (typeof payload.enabled !== 'boolean') {
            throw new Error('Invalid focus music settings.');
          }
          audioPatch = { focusMusicEnabled: payload.enabled };
          break;
        case 'set-track':
          if (!FOCUS_MUSIC_TRACKS.some((track) => track.id === payload.track)) {
            throw new Error('Invalid focus music settings.');
          }
          audioPatch = { focusMusicTrack: payload.track };
          break;
        case 'set-volume':
          if (typeof payload.volume !== 'number' || !Number.isFinite(payload.volume)) {
            throw new Error('Invalid focus music settings.');
          }
          audioPatch = { focusMusicVolume: payload.volume };
          break;
        default:
          throw new Error('Invalid focus music settings.');
      }

      const settings = normalizeSettings({
        ...current,
        ...audioPatch
      });
      return { patch: applyLiveFocusMusicSettings(data, settings) };
    }
  }
};
