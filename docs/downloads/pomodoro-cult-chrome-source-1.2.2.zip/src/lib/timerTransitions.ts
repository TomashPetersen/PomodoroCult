import { getSnapshotDurationSeconds, resolveNextWorkSnapshot } from './focusModes';
import { ensureNoTask, getLocalDateKey, getLocalStartMinute, getNextTimerRevision, sortTasks } from './storage';
import { NO_TASK_ID } from './constants';
import { StoredData, TimerState } from './types';

// Called inside the authoritative queue. One patch owns the next cycle and task usage.
export const prepareWorkAfterBreak = (
  data: StoredData,
  now: number,
  createCycleId: () => string,
  allowAutoStart = true
): Pick<StoredData, 'tasks' | 'timerState'> => {
  const tasks = ensureNoTask(data.tasks);
  const activeTaskId = tasks.some(task => task.id === data.timerState.activeTaskId && !task.archived)
    ? data.timerState.activeTaskId
    : NO_TASK_ID;
  const snapshot = resolveNextWorkSnapshot({ ...data, tasks, activeTaskId });
  const isRunning = allowAutoStart && snapshot.autoStartWork === true;
  const duration = getSnapshotDurationSeconds(snapshot, 'work');
  const timerState: TimerState = {
    ...data.timerState,
    isRunning,
    isPaused: false,
    cycleStarted: isRunning,
    revision: getNextTimerRevision(data.timerState),
    currentMode: 'work',
    remainingSeconds: duration,
    targetEndTime: isRunning ? now + duration * 1000 : null,
    cycleId: isRunning ? createCycleId() : null,
    cycleStartedAt: isRunning ? now : null,
    cycleStartedLocalDate: isRunning ? getLocalDateKey(new Date(now)) : null,
    cycleLocalStartMinute: isRunning ? getLocalStartMinute(new Date(now)) : null,
    activeCycleSnapshot: isRunning ? snapshot : null,
    activeTaskId
  };
  return {
    timerState,
    tasks: isRunning ? sortTasks(tasks.map(task => task.id === activeTaskId
      ? { ...task, usageCount: task.usageCount + 1, lastUsed: now }
      : task)) : data.tasks
  };
};
