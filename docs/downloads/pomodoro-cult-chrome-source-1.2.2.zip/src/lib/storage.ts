import {
  FOCUS_MUSIC_TRACKS,
  FOCUS_MUSIC_VOLUME,
  NO_TASK_ID,
  SETTINGS_FIELDS,
  TASK_TITLE_MAX_LENGTH
} from './constants';
import {
  focusModeToSnapshot,
  materializeSnapshotSettings,
  normalizeFocusModeSnapshot,
  normalizeFocusModes,
  settingsToFocusModeSnapshot
} from './focusModes';
import { getTaskTitle } from './i18n';
import { normalizeFocusReviewGoals } from './focusReviewGoals';
import { normalizePlanningCollections } from './focusPlanStorage';
import {
  CURRENT_STORAGE_VERSION,
  DEFAULT_FOCUS_REVIEW_GOALS,
  DEFAULT_SETTINGS,
  DailyStatistics,
  ExportedDataDocument,
  Locale,
  MigrationBackup,
  PersistedStorage,
  RecoveryExportDocument,
  Settings,
  SessionEvent,
  STORAGE_KEYS,
  Statistics,
  StorageIntegrityState,
  StoredData,
  StoredDataReadResult,
  Task,
  ThemeMode,
  TimerLifecycleState,
  TimerMode,
  TimerState
} from './types';

export const defaultTimerState = (settings: Settings = DEFAULT_SETTINGS): TimerState => ({
  isRunning: false,
  isPaused: false,
  cycleStarted: false,
  revision: 0,
  currentMode: 'work',
  remainingSeconds: settings.workTime * 60,
  targetEndTime: null,
  cycleId: null,
  cycleStartedAt: null,
  cycleStartedLocalDate: null,
  cycleLocalStartMinute: null,
  activeCycleSnapshot: null,
  activeTaskId: null,
  completedSessions: 0
});

const LEGACY_STORAGE_VERSION = 0;
const SESSION_EVENT_LOG_STARTED_AT_STORAGE_VERSION = 4;

const getStoredVersion = (value: unknown): number => {
  const parsed = Math.floor(Number(value));
  return Number.isFinite(parsed) && parsed > 0 ? parsed : LEGACY_STORAGE_VERSION;
};

export const getDurationSeconds = (settings: Settings, mode: TimerMode): number => {
  if (mode === 'work') return settings.workTime * 60;
  if (mode === 'shortBreak') return settings.shortBreak * 60;
  return settings.longBreak * 60;
};

export const getRunningDisplaySeconds = (
  targetEndTime: number,
  now = Date.now()
): number => {
  const remainingMs = targetEndTime - now;
  if (remainingMs <= 0) return 0;
  return Math.max(0, Math.ceil(remainingMs / 1000));
};

export const getNextTimerRevision = (timerState: TimerState): number =>
  timerState.revision + 1;

export const getStartDurationSeconds = (
  settings: Settings,
  timerState: TimerState,
  mode: TimerMode
): number =>
  timerState.currentMode === mode && timerState.remainingSeconds > 0
    ? timerState.remainingSeconds
    : getDurationSeconds(settings, mode);

export const isResumingPausedTimer = (
  settings: Settings,
  timerState: TimerState,
  mode: TimerMode
): boolean => {
  const fullDuration = getDurationSeconds(settings, mode);

  return (
    !timerState.isRunning &&
    timerState.targetEndTime === null &&
    timerState.currentMode === mode &&
    timerState.remainingSeconds > 0 &&
    timerState.remainingSeconds < fullDuration
  );
};

export const getStartTargetEndTime = (
  settings: Settings,
  timerState: TimerState,
  mode: TimerMode,
  now = Date.now()
): number => {
  const durationSeconds = getStartDurationSeconds(settings, timerState, mode);
  return now + durationSeconds * 1000;
};

export const canStartTimerMode = (
  settings: Settings,
  timerState: TimerState,
  mode: TimerMode
): boolean => {
  if (timerState.isRunning) {
    return timerState.currentMode === mode;
  }
  return timerState.currentMode === mode;
};

export const hasStartedTimerCycle = (
  _settings: Settings,
  timerState: TimerState
): boolean => timerState.cycleStarted;

export const getTimerLifecycleState = (
  settings: Settings,
  timerState: TimerState
): TimerLifecycleState => {
  if (timerState.isRunning) return 'running';
  if (!hasStartedTimerCycle(settings, timerState)) return 'idle';
  if (timerState.isPaused) return 'paused';
  return 'ready';
};

export const isTimerTaskLocked = (settings: Settings, timerState: TimerState): boolean => {
  return hasStartedTimerCycle(settings, timerState) && timerState.currentMode === 'work';
};

export const areTimerDurationsLocked = (settings: Settings, timerState: TimerState): boolean => {
  return hasStartedTimerCycle(settings, timerState);
};

export const clampTaskTitle = (title: string): string =>
  title.trim().replace(/\s+/g, ' ').slice(0, TASK_TITLE_MAX_LENGTH);

export const getTaskTitleKey = (title: string): string => clampTaskTitle(title).toLocaleLowerCase('en');

export const createId = (): string => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }

  return `task-${Date.now()}-${Math.random().toString(16).slice(2)}`;
};

export const createCycleId = (): string => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return `cycle-${crypto.randomUUID()}`;
  }

  return `cycle-${Date.now()}-${Math.random().toString(16).slice(2)}`;
};

type NumericSettingKey = (typeof SETTINGS_FIELDS)[number]['key'];

export const createTask = (title: string, system = false): Task => ({
  id: system ? NO_TASK_ID : createId(),
  title: clampTaskTitle(title),
  createdAt: Date.now(),
  usageCount: 0,
  lastUsed: 0,
  system,
  archived: false,
  archivedAt: null,
  focusModeId: null
});

export const createNoTask = (): Task => ({
  id: NO_TASK_ID,
  title: '',
  createdAt: 0,
  usageCount: 0,
  lastUsed: 0,
  system: true,
  archived: false,
  archivedAt: null,
  focusModeId: null
});

const normalizeSettingNumber = (settings: Partial<Settings> | undefined, key: NumericSettingKey): number => {
  const field = SETTINGS_FIELDS.find((item) => item.key === key)!;
  const value = Math.round(Number(settings?.[key] ?? DEFAULT_SETTINGS[key]));
  return Math.max(field.min, Math.min(field.max, Number.isFinite(value) ? value : DEFAULT_SETTINGS[key]));
};

export const normalizeSettings = (settings?: Partial<Settings>): Settings => {
  const focusMusicTrack = settings?.focusMusicTrack;

  return {
    workTime: normalizeSettingNumber(settings, 'workTime'),
    shortBreak: normalizeSettingNumber(settings, 'shortBreak'),
    longBreak: normalizeSettingNumber(settings, 'longBreak'),
    longBreakInterval: normalizeSettingNumber(settings, 'longBreakInterval'),
    languagePreference:
      settings?.languagePreference === 'ru' || settings?.languagePreference === 'en'
        ? settings.languagePreference
        : 'auto',
    autoStartBreaks: Boolean(settings?.autoStartBreaks),
    autoStartWork: settings?.autoStartWork === true,
    focusMusicEnabled: Boolean(settings?.focusMusicEnabled),
    focusMusicVolume: Math.max(
      FOCUS_MUSIC_VOLUME.min,
      Math.min(
        FOCUS_MUSIC_VOLUME.max,
        Number.isFinite(Number(settings?.focusMusicVolume))
          ? Number(settings?.focusMusicVolume)
          : DEFAULT_SETTINGS.focusMusicVolume
      )
    ),
    focusMusicTrack: FOCUS_MUSIC_TRACKS.some((track) => track.id === focusMusicTrack)
      ? focusMusicTrack!
      : DEFAULT_SETTINGS.focusMusicTrack
  };
};

export const normalizeTasks = (tasks?: Task[], validFocusModeIds?: Set<string>): Task[] => {
  const seen = new Set<string>();
  const normalized: Task[] = [];

  if (!Array.isArray(tasks)) {
    return [];
  }

  for (const task of tasks) {
    if (!task || typeof task !== 'object') continue;

    const title = clampTaskTitle(typeof task.title === 'string' ? task.title : '');
    const rawId = typeof task.id === 'string' ? task.id : '';
    const id = rawId === NO_TASK_ID || task.system ? NO_TASK_ID : rawId || createId();
    const rawFocusModeId = typeof task.focusModeId === 'string' ? task.focusModeId.trim() : '';
    const focusModeId = rawFocusModeId &&
      (!validFocusModeIds || validFocusModeIds.has(rawFocusModeId))
      ? rawFocusModeId
      : null;

    if (id !== NO_TASK_ID && !title) continue;
    if (seen.has(id)) continue;
    seen.add(id);

    normalized.push({
      id,
      title: id === NO_TASK_ID ? '' : title,
      createdAt:
        id === NO_TASK_ID
          ? 0
          : Number(task.createdAt) > 0
            ? Number(task.createdAt)
            : Math.max(0, Number(task.lastUsed) || 0),
      usageCount: Math.max(0, Number(task.usageCount) || 0),
      lastUsed: Math.max(0, Number(task.lastUsed) || 0),
      system: id === NO_TASK_ID || Boolean(task.system),
      archived: id === NO_TASK_ID ? false : Boolean(task.archived),
      archivedAt: Number(task.archivedAt) > 0 ? Number(task.archivedAt) : null,
      focusModeId: id === NO_TASK_ID ? null : focusModeId
    });
  }

  return normalized.sort(sortTasksByUse);
};

export const normalizeStatistics = (statistics?: Statistics): Statistics => {
  if (!statistics || typeof statistics !== 'object' || Array.isArray(statistics)) {
    return {};
  }

  return statistics;
};

export const MAX_JS_DATE_TIMESTAMP = 8.64e15;
export const MAX_SESSION_DURATION_SECONDS = 86_400;

const LOCAL_DATE_KEY_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

export const isValidLocalDateKey = (value: unknown): value is string => {
  if (typeof value !== 'string') return false;
  const match = LOCAL_DATE_KEY_PATTERN.exec(value);
  if (!match) return false;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day;
};

export const getLocalStartMinute = (date = new Date()): number =>
  date.getHours() * 60 + date.getMinutes();

const getOffsetLocalDateKey = (timestamp: number, offsetMinutes: number): string => {
  const date = new Date(timestamp - offsetMinutes * 60_000);
  const year = String(date.getUTCFullYear()).padStart(4, '0');
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const readOptionalLocalDate = (
  value: unknown
): { valid: boolean; value?: string } =>
  value === undefined
    ? { valid: true }
    : isValidLocalDateKey(value)
      ? { valid: true, value }
      : { valid: false };

const readOptionalInteger = (
  value: unknown,
  min: number,
  max: number
): { valid: boolean; value?: number } => {
  if (value === undefined) return { valid: true };
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= min && parsed <= max
    ? { valid: true, value: parsed }
    : { valid: false };
};

const compareOrdinal = (left: string, right: string): number =>
  left < right ? -1 : left > right ? 1 : 0;

export const normalizeSessionEvents = (sessionEvents?: SessionEvent[]): SessionEvent[] => {
  if (!Array.isArray(sessionEvents)) return [];

  const seen = new Set<string>();
  const normalized: SessionEvent[] = [];

  for (const event of sessionEvents) {
    if (!event || typeof event !== 'object') continue;

    const id = typeof event.id === 'string' ? event.id.trim() : '';
    const taskId = typeof event.taskId === 'string' ? event.taskId.trim() : '';
    const startedAt = Math.floor(Number(event.startedAt));
    const completedAt = Math.floor(Number(event.completedAt));
    const durationSeconds = Math.floor(Number(event.durationSeconds));
    const completedLocalDate = readOptionalLocalDate(event.completedLocalDate);
    const startedLocalDate = readOptionalLocalDate(event.startedLocalDate);
    const localStartMinute = readOptionalInteger(event.localStartMinute, 0, 1439);
    const timeZoneOffsetMinutes = readOptionalInteger(
      event.timeZoneOffsetMinutes,
      -1440,
      1440
    );

    if (
      !id ||
      !taskId ||
      seen.has(id) ||
      !Number.isFinite(startedAt) ||
      !Number.isFinite(completedAt) ||
      !Number.isFinite(durationSeconds) ||
      startedAt < 0 ||
      startedAt > MAX_JS_DATE_TIMESTAMP ||
      completedAt < startedAt ||
      completedAt > MAX_JS_DATE_TIMESTAMP ||
      durationSeconds <= 0 ||
      durationSeconds > MAX_SESSION_DURATION_SECONDS ||
      !completedLocalDate.valid ||
      !startedLocalDate.valid ||
      !localStartMinute.valid ||
      !timeZoneOffsetMinutes.valid ||
      (completedLocalDate.value !== undefined &&
        timeZoneOffsetMinutes.value !== undefined &&
        completedLocalDate.value !== getOffsetLocalDateKey(completedAt, timeZoneOffsetMinutes.value))
    ) {
      continue;
    }

    normalized.push({
      id,
      taskId,
      taskTitleSnapshot:
        typeof event.taskTitleSnapshot === 'string'
          ? event.taskTitleSnapshot.slice(0, TASK_TITLE_MAX_LENGTH)
          : '',
      focusModeId:
        typeof event.focusModeId === 'string' && event.focusModeId.trim()
          ? event.focusModeId.trim()
          : null,
      startedAt,
      completedAt,
      durationSeconds,
      ...(completedLocalDate.value !== undefined
        ? { completedLocalDate: completedLocalDate.value }
        : {}),
      ...(startedLocalDate.value !== undefined
        ? { startedLocalDate: startedLocalDate.value }
        : {}),
      ...(localStartMinute.value !== undefined
        ? { localStartMinute: localStartMinute.value }
        : {}),
      ...(timeZoneOffsetMinutes.value !== undefined
        ? { timeZoneOffsetMinutes: timeZoneOffsetMinutes.value }
        : {})
    });
    seen.add(id);
  }

  return normalized.sort(
    (left, right) => left.completedAt - right.completedAt || compareOrdinal(left.id, right.id)
  );
};

interface CreateSessionEventInput {
  cycleId: string | null;
  taskId: string;
  taskTitleSnapshot: string;
  focusModeId: string | null;
  cycleStartedAt: number | null;
  cycleStartedLocalDate?: string | null;
  cycleLocalStartMinute?: number | null;
  completedAt: number;
  durationSeconds: number;
}

export const createSessionEvent = ({
  cycleId,
  taskId,
  taskTitleSnapshot,
  focusModeId,
  cycleStartedAt,
  cycleStartedLocalDate,
  cycleLocalStartMinute,
  completedAt,
  durationSeconds
}: CreateSessionEventInput): SessionEvent => {
  const normalizedCompletedAt = Math.max(0, Math.floor(completedAt));
  const normalizedDuration = Math.min(
    MAX_SESSION_DURATION_SECONDS,
    Math.max(1, Math.floor(durationSeconds))
  );
  const fallbackStartedAt = Math.max(
    0,
    normalizedCompletedAt - normalizedDuration * 1000
  );
  const normalizedCycleStartedAt =
    typeof cycleStartedAt === 'number' && Number.isFinite(cycleStartedAt)
      ? Math.floor(cycleStartedAt)
      : null;
  const startedAt =
    normalizedCycleStartedAt !== null && normalizedCycleStartedAt >= 0
      ? Math.min(normalizedCompletedAt, normalizedCycleStartedAt)
      : fallbackStartedAt;
  const fallbackId =
    typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID()
      : `${normalizedCompletedAt}-${Math.random().toString(16).slice(2)}`;

  const completionDate = new Date(normalizedCompletedAt);
  const capturedStartedLocalDate = isValidLocalDateKey(cycleStartedLocalDate)
    ? cycleStartedLocalDate
    : undefined;
  const capturedLocalStartMinute = Number.isInteger(cycleLocalStartMinute) &&
    Number(cycleLocalStartMinute) >= 0 && Number(cycleLocalStartMinute) <= 1439
    ? Number(cycleLocalStartMinute)
    : undefined;

  return {
    id: cycleId ? `session-${cycleId}` : `session-${fallbackId}`,
    taskId,
    taskTitleSnapshot: clampTaskTitle(taskTitleSnapshot),
    focusModeId,
    startedAt,
    completedAt: normalizedCompletedAt,
    durationSeconds: normalizedDuration,
    completedLocalDate: getLocalDateKey(completionDate),
    timeZoneOffsetMinutes: completionDate.getTimezoneOffset(),
    ...(capturedStartedLocalDate !== undefined
      ? { startedLocalDate: capturedStartedLocalDate }
      : {}),
    ...(capturedLocalStartMinute !== undefined
      ? { localStartMinute: capturedLocalStartMinute }
      : {})
  };
};

export const removeTaskSessionEvents = (
  sessionEvents: SessionEvent[],
  taskId: string
): SessionEvent[] =>
  normalizeSessionEvents(sessionEvents).filter((event) => event.taskId !== taskId);

export const ensureNoTask = (tasks: Task[]): Task[] => {
  const normalized = normalizeTasks(tasks);
  const existing = normalized.find((task) => task.id === NO_TASK_ID);

  if (!existing) {
    return sortTasks([createNoTask(), ...normalized]);
  }

  return sortTasks(
    normalized.map((task) =>
      task.id === NO_TASK_ID
        ? {
            ...task,
            title: '',
            createdAt: 0,
            system: true,
            archived: false,
            archivedAt: null,
            focusModeId: null
          }
        : task
    )
  );
};

export const sortTasksByUse = (a: Task, b: Task): number => {
  if (a.id === NO_TASK_ID && b.id !== NO_TASK_ID) return -1;
  if (b.id === NO_TASK_ID && a.id !== NO_TASK_ID) return 1;
  if ((b.createdAt ?? 0) !== (a.createdAt ?? 0)) return (b.createdAt ?? 0) - (a.createdAt ?? 0);
  if (b.lastUsed !== a.lastUsed) return b.lastUsed - a.lastUsed;
  if (b.usageCount !== a.usageCount) return b.usageCount - a.usageCount;
  return 0;
};

export const sortTasks = (tasks: Task[]): Task[] => [...tasks].sort(sortTasksByUse);

export const getActiveTasks = (tasks: Task[], priorityTaskId?: string | null): Task[] => {
  const normalized = ensureNoTask(tasks);
  const active = normalized.filter((task) => task.id === NO_TASK_ID || !task.archived);

  return active.sort((a, b) => {
    if (a.id === NO_TASK_ID && b.id !== NO_TASK_ID) return -1;
    if (b.id === NO_TASK_ID && a.id !== NO_TASK_ID) return 1;
    if (priorityTaskId && a.id === priorityTaskId && b.id !== priorityTaskId) return -1;
    if (priorityTaskId && b.id === priorityTaskId && a.id !== priorityTaskId) return 1;
    return sortTasksByUse(a, b);
  });
};

export const getArchivedTasks = (tasks: Task[]): Task[] =>
  normalizeTasks(tasks)
    .filter((task) => task.id !== NO_TASK_ID && task.archived)
    .sort((a, b) => {
      if ((b.archivedAt ?? 0) !== (a.archivedAt ?? 0)) {
        return (b.archivedAt ?? 0) - (a.archivedAt ?? 0);
      }
      return (b.createdAt ?? 0) - (a.createdAt ?? 0);
    });

export const hasActiveTaskTitle = (
  tasks: Task[],
  title: string,
  excludeTaskId?: string | null
): boolean => {
  const key = getTaskTitleKey(title);
  if (!key) return false;

  return normalizeTasks(tasks).some(
    (task) =>
      task.id !== NO_TASK_ID &&
      task.id !== excludeTaskId &&
      !task.archived &&
      getTaskTitleKey(task.title) === key
  );
};

export const getTaskSessionCount = (
  statistics: Statistics,
  taskId: string | null
): number => {
  const resolvedTaskId = taskId ?? NO_TASK_ID;

  return Object.values(statistics).reduce((total, day) => {
    const taskStat = day.tasks[resolvedTaskId];
    return total + (taskStat?.sessions ?? 0);
  }, 0);
};

export const removeTaskStatistics = (
  statistics: Statistics,
  taskId: string
): Statistics => {
  const nextStatistics: Statistics = {};

  for (const [date, day] of Object.entries(statistics)) {
    const taskStat = day.tasks[taskId];

    if (!taskStat) {
      nextStatistics[date] = day;
      continue;
    }

    const nextTasks = { ...day.tasks };
    delete nextTasks[taskId];

    const nextSessions = Math.max(0, day.sessions - taskStat.sessions);
    const nextSeconds = Math.max(0, day.seconds - taskStat.seconds);

    if (Object.keys(nextTasks).length === 0 || (nextSessions === 0 && nextSeconds === 0)) {
      continue;
    }

    nextStatistics[date] = {
      ...day,
      tasks: nextTasks,
      sessions: nextSessions,
      seconds: nextSeconds
    };
  }

  return nextStatistics;
};

export const formatCompactCount = (locale: Locale, count: number): string => {
  if (count < 1000) return String(count);

  const value = count / 1000;
  const formatted = value.toLocaleString(locale === 'ru' ? 'ru-RU' : 'en-US', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0
  });

  return locale === 'ru' ? `${formatted} к` : `${formatted}K`;
};

export const getDisplayTaskTitle = (locale: Locale, task: Pick<Task, 'id' | 'title'>): string =>
  getTaskTitle(locale, task.id, task.title);

export const getLocalDateKey = (date = new Date()): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getDateRange = (endDateKey: string, days: number): string[] => {
  const result: string[] = [];
  const end = new Date(`${endDateKey}T12:00:00`);

  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const date = new Date(end);
    date.setDate(end.getDate() - offset);
    result.push(getLocalDateKey(date));
  }

  return result;
};

export const getDateRangeBetween = (startDateKey: string, endDateKey: string): string[] => {
  const start = new Date(`${startDateKey}T12:00:00`);
  const end = new Date(`${endDateKey}T12:00:00`);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start > end) {
    return [];
  }

  const result: string[] = [];
  const cursor = new Date(start);

  while (cursor <= end) {
    result.push(getLocalDateKey(cursor));
    cursor.setDate(cursor.getDate() + 1);
  }

  return result;
};

export const getPresetStatsRange = (
  days: number,
  endDateKey = getLocalDateKey()
): { start: string; end: string } => {
  const range = getDateRange(endDateKey, days);
  return {
    start: range[0] ?? endDateKey,
    end: range[range.length - 1] ?? endDateKey
  };
};

export const addSessionStatistics = (
  statistics: Statistics,
  taskId: string,
  title: string,
  seconds: number,
  now = Date.now()
): Statistics => {
  const date = getLocalDateKey(new Date(now));
  const day: DailyStatistics = statistics[date] ?? {
    date,
    sessions: 0,
    seconds: 0,
    tasks: {}
  };
  const taskStat = day.tasks[taskId] ?? {
    taskId,
    title,
    sessions: 0,
    seconds: 0,
    lastSessionAt: 0
  };

  return {
    ...statistics,
    [date]: {
      ...day,
      sessions: day.sessions + 1,
      seconds: day.seconds + seconds,
      tasks: {
        ...day.tasks,
        [taskId]: {
          ...taskStat,
          title,
          sessions: taskStat.sessions + 1,
          seconds: taskStat.seconds + seconds,
          lastSessionAt: now
        }
      }
    }
  };
};

export const hasChromeStorage = (): boolean =>
  typeof chrome !== 'undefined' && Boolean(chrome.storage?.local);

const getLocal = <T extends Partial<PersistedStorage>>(keys?: string[] | null): Promise<T> =>
  new Promise((resolve, reject) => {
    if (!hasChromeStorage()) {
      resolve({} as T);
      return;
    }

    chrome.storage.local.get(keys ?? null, (value) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(value as T);
    });
  });

const writeLocalUnchecked = async (value: Partial<PersistedStorage>): Promise<void> => {
  if (!hasChromeStorage()) return;
  await new Promise<void>((resolve, reject) => {
    chrome.storage.local.set(value, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
};

export const setLocal = async (value: Partial<PersistedStorage>): Promise<void> => {
  if (!hasChromeStorage()) return;
  assertStorageRuntimeWritable(await getLocal<Partial<PersistedStorage>>());
  await writeLocalUnchecked(value);
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  Boolean(value) && typeof value === 'object' && !Array.isArray(value);

const exactObjectKeys = (value: Record<string, unknown>, keys: readonly string[]): boolean => {
  const actual = Object.keys(value);
  return actual.length === keys.length && keys.every((key) => Object.prototype.hasOwnProperty.call(value, key));
};

const isValidEvidenceTimestamp = (value: unknown, now: number): value is number =>
  Number.isInteger(value) && Number(value) >= 0 && Number(value) <= MAX_JS_DATE_TIMESTAMP &&
  Number(value) <= now;

const getTrustworthyV3MigrationTimestamp = (
  backup: MigrationBackup | null | undefined,
  now: number
): number | null => {
  if (
    !backup ||
    backup.fromVersion >= 3 ||
    backup.toVersion !== 3 ||
    !isValidEvidenceTimestamp(backup.createdAt, now) ||
    !isRecord(backup.data) ||
    'sessionEvents' in backup.data
  ) {
    return null;
  }
  return backup.createdAt;
};

const getSessionEventLogStartedAt = (
  stored: Partial<PersistedStorage>,
  sessionEvents: SessionEvent[],
  now: number
): number => {
  if (
    getStoredVersion(stored.storageVersion) >= SESSION_EVENT_LOG_STARTED_AT_STORAGE_VERSION &&
    isValidEvidenceTimestamp(stored.sessionEventLogStartedAt, now)
  ) {
    return stored.sessionEventLogStartedAt;
  }

  const migrationTimestamp = getTrustworthyV3MigrationTimestamp(
    stored.migrationBackup,
    now
  );
  if (migrationTimestamp !== null) return migrationTimestamp;

  const earliestEvent = sessionEvents.reduce<number | null>((earliest, event) => {
    if (!isValidEvidenceTimestamp(event.completedAt, now)) return earliest;
    return earliest === null ? event.completedAt : Math.min(earliest, event.completedAt);
  }, null);
  return earliestEvent ?? now;
};

export const normalizeStoredData = (
  stored: Partial<PersistedStorage> = {},
  now = Date.now()
): StoredData => {
  const rawSettings = normalizeSettings(stored.settings);
  const manualSettings = normalizeSettings(stored.manualSettings ?? stored.settings);
  const focusModes = normalizeFocusModes(stored.focusModes);
  const validFocusModeIds = new Set(focusModes.map((mode) => mode.id));
  const selectedFocusModeId =
    typeof stored.selectedFocusModeId === 'string' &&
    validFocusModeIds.has(stored.selectedFocusModeId.trim())
      ? stored.selectedFocusModeId.trim()
      : null;
  const selectedMode = selectedFocusModeId
    ? focusModes.find((mode) => mode.id === selectedFocusModeId)
    : undefined;
  const settings = selectedMode
    ? materializeSnapshotSettings(focusModeToSnapshot(selectedMode), rawSettings)
    : manualSettings;
  const timerDefaults = defaultTimerState(settings);
  const storedMode = stored.timerState?.currentMode ?? timerDefaults.currentMode;
  const storedRemainingSeconds =
    Number(stored.timerState?.remainingSeconds) > 0
      ? Number(stored.timerState?.remainingSeconds)
      : timerDefaults.remainingSeconds;
  const storedCompletedSessions = Math.max(
    0,
    Number(stored.timerState?.completedSessions) || 0
  );
  const legacyCycleStarted =
    Boolean(stored.timerState?.isRunning) ||
    storedMode !== 'work' ||
    storedCompletedSessions > 0 ||
    storedRemainingSeconds !== getDurationSeconds(settings, 'work');
  const legacyIsPaused =
    !stored.timerState?.isRunning &&
    stored.timerState?.targetEndTime == null &&
    storedRemainingSeconds > 0 &&
    storedRemainingSeconds < getDurationSeconds(settings, storedMode);
  const isRunning = Boolean(stored.timerState?.isRunning);
  const isPaused =
    typeof stored.timerState?.isPaused === 'boolean'
      ? stored.timerState.isPaused
      : legacyIsPaused;
  const cycleId =
    typeof stored.timerState?.cycleId === 'string' && stored.timerState.cycleId.trim()
      ? stored.timerState.cycleId.trim()
      : null;
  const isReadyNewWork =
    storedMode === 'work' &&
    !isRunning &&
    !isPaused &&
    stored.timerState?.targetEndTime == null &&
    cycleId === null;
  const cycleStarted = isReadyNewWork
    ? false
    :
    typeof stored.timerState?.cycleStarted === 'boolean'
      ? stored.timerState.cycleStarted
      : legacyCycleStarted;
  const timerState: TimerState = {
    ...timerDefaults,
    ...(stored.timerState ?? {}),
    currentMode: storedMode,
    remainingSeconds: storedRemainingSeconds,
    completedSessions: storedCompletedSessions,
    targetEndTime: stored.timerState?.targetEndTime ?? null,
    cycleId,
    cycleStartedAt:
      typeof stored.timerState?.cycleStartedAt === 'number' &&
      Number.isFinite(stored.timerState.cycleStartedAt) &&
      stored.timerState.cycleStartedAt >= 0
        ? Math.floor(stored.timerState.cycleStartedAt)
        : null,
    cycleStartedLocalDate: isReadyNewWork
      ? null
      : isValidLocalDateKey(stored.timerState?.cycleStartedLocalDate)
        ? stored.timerState.cycleStartedLocalDate
        : null,
    cycleLocalStartMinute: isReadyNewWork
      ? null
      : Number.isInteger(stored.timerState?.cycleLocalStartMinute) &&
          Number(stored.timerState?.cycleLocalStartMinute) >= 0 &&
          Number(stored.timerState?.cycleLocalStartMinute) <= 1439
        ? Number(stored.timerState?.cycleLocalStartMinute)
        : null,
    activeCycleSnapshot: isReadyNewWork
      ? null
      : normalizeFocusModeSnapshot(stored.timerState?.activeCycleSnapshot, settings) ??
        (cycleStarted ? settingsToFocusModeSnapshot(settings) : null),
    activeTaskId: stored.timerState?.activeTaskId ?? null,
    isRunning,
    isPaused,
    revision: Math.max(0, Number(stored.timerState?.revision) || 0),
    cycleStarted
  };

  const sessionEvents = normalizeSessionEvents(stored.sessionEvents);
  const planning = normalizePlanningCollections(
    {
      taskTemplates: Array.isArray(stored.taskTemplates) ? stored.taskTemplates : [],
      focusPlans: Array.isArray(stored.focusPlans) ? stored.focusPlans : [],
      focusPlanSchedules: Array.isArray(stored.focusPlanSchedules) ? stored.focusPlanSchedules : [],
      focusPlanRuns: Array.isArray(stored.focusPlanRuns) ? stored.focusPlanRuns : []
    },
    validFocusModeIds
  ).collections;

  return {
    storageVersion: CURRENT_STORAGE_VERSION,
    settings,
    tasks: normalizeTasks(stored.tasks, validFocusModeIds),
    timerState,
    statistics: normalizeStatistics(stored.statistics),
    focusModes,
    selectedFocusModeId,
    manualSettings,
    sessionEvents,
    focusReviewGoals: normalizeFocusReviewGoals(
      stored.focusReviewGoals ?? DEFAULT_FOCUS_REVIEW_GOALS
    ),
    sessionEventLogStartedAt: getSessionEventLogStartedAt(stored, sessionEvents, now),
    theme: stored.theme === 'dark' ? 'dark' : 'light',
    ...planning
  };
};

export const createMigrationBackup = (
  stored: Partial<PersistedStorage>,
  toVersion = CURRENT_STORAGE_VERSION,
  createdAt = Date.now()
): MigrationBackup => ({
  createdAt,
  fromVersion: getStoredVersion(stored.storageVersion),
  toVersion,
  data: stored
});

const withoutV5Evidence = (stored: Partial<PersistedStorage>): Record<string, unknown> => {
  const copy = { ...(stored as unknown as Record<string, unknown>) };
  delete copy.storageV5MigrationBackup;
  delete copy.migrationBackup;
  return copy;
};

export const createStorageV5MigrationBackup = (
  stored: Partial<PersistedStorage>,
  fromVersion: number,
  createdAt: number
): MigrationBackup => ({
  createdAt,
  fromVersion,
  toVersion: CURRENT_STORAGE_VERSION,
  data: fromVersion >= 3 ? { storageVersion: fromVersion } : withoutV5Evidence(stored)
});

const isValidStorageV5MigrationBackup = (
  backup: unknown,
  now: number,
  source?: Partial<PersistedStorage>,
  sourceVersion?: number
): backup is MigrationBackup => {
  if (!isRecord(backup) || !Number.isInteger(backup.fromVersion) || Number(backup.fromVersion) < 0 || Number(backup.fromVersion) > 4 ||
    backup.toVersion !== CURRENT_STORAGE_VERSION || !isValidEvidenceTimestamp(backup.createdAt, now)) {
    return false;
  }
  const fromVersion = Number(backup.fromVersion);
  if (sourceVersion !== undefined && fromVersion !== sourceVersion) return false;
  if (fromVersion >= 3) {
    return isRecord(backup.data) && storageValuesEqual(backup.data, { storageVersion: fromVersion });
  }
  return isRecord(backup.data) &&
    !('migrationBackup' in backup.data) &&
    !('storageV5MigrationBackup' in backup.data) &&
    (source ? storageValuesEqual(backup.data, withoutV5Evidence(source)) : true);
};

export const migrateStoredData = (
  stored: Partial<PersistedStorage> = {},
  now = Date.now()
): { data: StoredData; backup: MigrationBackup | null; migrated: boolean; fromVersion: number } => {
  const fromVersion = getStoredVersion(stored.storageVersion);
  const data = normalizeStoredData(stored, now);
  const migrated = fromVersion < CURRENT_STORAGE_VERSION;
  const backup = !migrated || stored.storageV5MigrationBackup !== undefined
    ? null
    : createStorageV5MigrationBackup(stored, fromVersion, now);

  return {
    data,
    backup,
    migrated,
    fromVersion
  };
};

export const readStoredData = async (): Promise<StoredData> => {
  const stored = await getLocal<Partial<PersistedStorage>>();
  return migrateStoredData(stored).data;
};

const getRawVersion = (stored: Partial<PersistedStorage>): number | null =>
  stored.storageVersion === undefined
    ? 0
    : Number.isInteger(stored.storageVersion) && Number(stored.storageVersion) >= 0
      ? Number(stored.storageVersion)
      : null;

export const getStoredDataReadResult = (
  stored: Partial<PersistedStorage>,
  now = Date.now()
): StoredDataReadResult => {
  const raw = stored as unknown as Record<string, unknown>;
  const version = getRawVersion(stored);
  const data = normalizeStoredData(stored, now);
  const rawPlanningData = {
    taskTemplates: raw.taskTemplates,
    focusPlans: raw.focusPlans,
    focusPlanSchedules: raw.focusPlanSchedules,
    focusPlanRuns: raw.focusPlanRuns
  };
  let storageIntegrity: StorageIntegrityState = { status: 'ok' };
  if (version === null) {
    storageIntegrity = { status: 'blocked', reason: 'VERSION_SCHEMA_CONFLICT', issues: [{ code: 'VERSION_SCHEMA_CONFLICT', path: 'storageVersion' }], rawPlanningData, rawStorage: raw };
  } else if (version !== null && version > CURRENT_STORAGE_VERSION) {
    storageIntegrity = { status: 'blocked', reason: 'FUTURE_STORAGE_VERSION', issues: [{ code: 'FUTURE_STORAGE_VERSION', path: 'storageVersion' }], rawPlanningData, rawStorage: raw };
  } else if (version !== null && version < CURRENT_STORAGE_VERSION && stored.storageV5MigrationBackup !== undefined &&
    !isValidStorageV5MigrationBackup(stored.storageV5MigrationBackup, now, stored, version)) {
    storageIntegrity = {
      status: 'blocked',
      reason: 'V5_MIGRATION_BACKUP_INVALID',
      issues: [{ code: 'V5_MIGRATION_BACKUP_INVALID', path: 'storageV5MigrationBackup' }],
      rawPlanningData,
      rawStorage: raw
    };
  } else if (version < CURRENT_STORAGE_VERSION && Object.values(rawPlanningData).some((value) => value !== undefined)) {
    storageIntegrity = { status: 'blocked', reason: 'VERSION_SCHEMA_CONFLICT', issues: [{ code: 'VERSION_SCHEMA_CONFLICT', path: 'storageVersion' }], rawPlanningData, rawStorage: raw };
  } else if (version === CURRENT_STORAGE_VERSION) {
    storageIntegrity = normalizePlanningCollections(raw, new Set(data.focusModes.map((mode) => mode.id))).integrity;
    if (storageIntegrity.status === 'ok' && !isValidStorageV5MigrationBackup(stored.storageV5MigrationBackup, now)) {
      storageIntegrity = {
        status: 'warning',
        reason: 'V5_MIGRATION_BACKUP_WARNING',
        issues: [{ code: 'V5_MIGRATION_BACKUP_WARNING', path: 'storageV5MigrationBackup' }],
        rawPlanningData,
        rawStorage: raw
      };
    }
  }
  return { data, storageIntegrity };
};

export const readStoredDataResult = async (): Promise<StoredDataReadResult> =>
  getStoredDataReadResult(await getLocal<Partial<PersistedStorage>>());

export const assertStorageRuntimeWritable = (
  stored: Partial<PersistedStorage>,
  now = Date.now()
): void => {
  const integrity = getStoredDataReadResult(stored, now).storageIntegrity;
  if (integrity.status === 'blocked' &&
    (integrity.reason === 'FUTURE_STORAGE_VERSION' || integrity.reason === 'V5_MIGRATION_BACKUP_INVALID')) {
    throw new Error(integrity.reason);
  }
};

export interface StorageInitializationAdapter {
  read(): Promise<Partial<PersistedStorage>>;
  write(value: Partial<PersistedStorage>): Promise<void>;
}

const storedDataKeys = [
  STORAGE_KEYS.storageVersion,
  STORAGE_KEYS.settings,
  STORAGE_KEYS.tasks,
  STORAGE_KEYS.timerState,
  STORAGE_KEYS.statistics,
  STORAGE_KEYS.focusModes,
  STORAGE_KEYS.selectedFocusModeId,
  STORAGE_KEYS.manualSettings,
  STORAGE_KEYS.sessionEvents,
  STORAGE_KEYS.focusReviewGoals,
  STORAGE_KEYS.sessionEventLogStartedAt,
  STORAGE_KEYS.theme,
  STORAGE_KEYS.taskTemplates,
  STORAGE_KEYS.focusPlans,
  STORAGE_KEYS.focusPlanSchedules,
  STORAGE_KEYS.focusPlanRuns
] as const;

const planningStorageKeys = [
  STORAGE_KEYS.taskTemplates,
  STORAGE_KEYS.focusPlans,
  STORAGE_KEYS.focusPlanSchedules,
  STORAGE_KEYS.focusPlanRuns
] as const;

const storageValuesEqual = (left: unknown, right: unknown): boolean => {
  if (Object.is(left, right)) return true;
  if (Array.isArray(left) || Array.isArray(right)) {
    return (
      Array.isArray(left) &&
      Array.isArray(right) &&
      left.length === right.length &&
      left.every((value, index) => storageValuesEqual(value, right[index]))
    );
  }
  if (
    left === null ||
    right === null ||
    typeof left !== 'object' ||
    typeof right !== 'object'
  ) {
    return false;
  }

  const leftRecord = left as Record<string, unknown>;
  const rightRecord = right as Record<string, unknown>;
  const leftKeys = Object.keys(leftRecord);
  const rightKeys = Object.keys(rightRecord);
  return (
    leftKeys.length === rightKeys.length &&
    leftKeys.every(
      (key) =>
        Object.prototype.hasOwnProperty.call(rightRecord, key) &&
        storageValuesEqual(leftRecord[key], rightRecord[key])
    )
  );
};

const storedKeyNeedsRepair = (
  stored: Partial<PersistedStorage>,
  data: StoredData,
  key: (typeof storedDataKeys)[number]
): boolean => {
  if (key === STORAGE_KEYS.sessionEvents) {
    return false;
  }
  if (key !== STORAGE_KEYS.timerState || !isRecord(stored.timerState)) {
    return !storageValuesEqual(stored[key], data[key]);
  }

  const comparableTimerState = { ...data.timerState } as Record<string, unknown>;
  if (!Object.prototype.hasOwnProperty.call(stored.timerState, 'cycleStartedLocalDate')) {
    delete comparableTimerState.cycleStartedLocalDate;
  }
  if (!Object.prototype.hasOwnProperty.call(stored.timerState, 'cycleLocalStartMinute')) {
    delete comparableTimerState.cycleLocalStartMinute;
  }
  return !storageValuesEqual(stored.timerState, comparableTimerState);
};

const createRepairPatch = (
  stored: Partial<PersistedStorage>,
  data: StoredData,
  exclude = new Set<string>()
): Partial<PersistedStorage> =>
  storedDataKeys.reduce<Partial<PersistedStorage>>((result, key) => {
    if (!exclude.has(key) && storedKeyNeedsRepair(stored, data, key)) {
      (result as Record<string, unknown>)[key] = data[key];
    }
    return result;
  }, {});

const canSafelyCompleteV5MigrationWithStaleEvidence = (
  stored: Partial<PersistedStorage>,
  now: number
): boolean => {
  const raw = stored as unknown as Record<string, unknown>;
  const presentPlanningKeys = planningStorageKeys.filter((key) =>
    Object.prototype.hasOwnProperty.call(stored, key)
  );
  if (presentPlanningKeys.length === 0) return true;
  if (presentPlanningKeys.length !== planningStorageKeys.length) return false;

  const normalized = normalizeStoredData(stored, now);
  return normalizePlanningCollections(
    raw,
    new Set(normalized.focusModes.map((mode) => mode.id))
  ).integrity.status === 'ok';
};

export const initializeStorageWithAdapter = async (
  adapter: StorageInitializationAdapter,
  now = Date.now()
): Promise<StoredData> => {
  const stored = await adapter.read();
  const rawVersion = getRawVersion(stored);
  const hasPlanningKey = planningStorageKeys.some((key) =>
    Object.prototype.hasOwnProperty.call(stored, key)
  );
  const hasInvalidPreV5Evidence = rawVersion !== null && rawVersion < CURRENT_STORAGE_VERSION &&
    stored.storageV5MigrationBackup !== undefined &&
    !isValidStorageV5MigrationBackup(stored.storageV5MigrationBackup, now, stored, rawVersion);
  const canRecoverStaleEvidence = hasInvalidPreV5Evidence &&
    canSafelyCompleteV5MigrationWithStaleEvidence(stored, now);
  if (rawVersion === null || rawVersion > CURRENT_STORAGE_VERSION ||
    (rawVersion < CURRENT_STORAGE_VERSION && hasPlanningKey && !canRecoverStaleEvidence) ||
    (hasInvalidPreV5Evidence && !canRecoverStaleEvidence)) {
    return normalizeStoredData(stored, now);
  }
  const { data, backup, migrated, fromVersion } = migrateStoredData(stored, now);
  const planningPatch = {
    taskTemplates: data.taskTemplates,
    focusPlans: data.focusPlans,
    focusPlanSchedules: data.focusPlanSchedules,
    focusPlanRuns: data.focusPlanRuns
  };
  const patch: Partial<PersistedStorage> = migrated && fromVersion === 3
    ? {
        ...createRepairPatch(
          stored,
          data,
          new Set([
            STORAGE_KEYS.storageVersion,
            STORAGE_KEYS.sessionEvents,
            STORAGE_KEYS.focusReviewGoals,
            STORAGE_KEYS.sessionEventLogStartedAt
          ])
        ),
        storageVersion: CURRENT_STORAGE_VERSION,
        focusReviewGoals: data.focusReviewGoals,
        sessionEventLogStartedAt: data.sessionEventLogStartedAt,
        ...planningPatch,
        ...(backup ? { storageV5MigrationBackup: backup } : {})
      }
    : migrated && fromVersion === 4
      ? {
          storageVersion: CURRENT_STORAGE_VERSION,
          ...(storedKeyNeedsRepair(stored, data, STORAGE_KEYS.sessionEventLogStartedAt)
            ? { sessionEventLogStartedAt: data.sessionEventLogStartedAt }
            : {}),
          ...planningPatch,
          ...(backup ? { storageV5MigrationBackup: backup } : {})
        }
    : backup
      ? { ...data, storageV5MigrationBackup: backup }
    : createRepairPatch(
        stored,
        data,
        fromVersion === CURRENT_STORAGE_VERSION
          ? new Set([
              STORAGE_KEYS.taskTemplates,
              STORAGE_KEYS.focusPlans,
              STORAGE_KEYS.focusPlanSchedules,
              STORAGE_KEYS.focusPlanRuns
            ])
          : new Set()
      );

  if (Object.keys(patch).length > 0) {
    await adapter.write(patch);
  }
  return data;
};

export const initializeStorage = async (): Promise<StoredData> =>
  initializeStorageWithAdapter({
    read: () => getLocal<Partial<PersistedStorage>>(),
    write: writeLocalUnchecked
  });

const getSafeImportedTimerState = (data: StoredData): TimerState => ({
  ...defaultTimerState(data.settings),
  activeTaskId: data.timerState.activeTaskId,
  activeCycleSnapshot: null
});

export const createRecoveryExportDocument = (
  result: StoredDataReadResult,
  exportedAt = new Date().toISOString()
): RecoveryExportDocument => {
  if (result.storageIntegrity.status === 'ok') {
    throw new Error('RECOVERY_EXPORT_NOT_REQUIRED');
  }
  return {
    app: 'Pomodoro Cult storage recovery',
    exportedAt,
    importable: false,
    reason: result.storageIntegrity.reason,
    issues: result.storageIntegrity.issues,
    rawPlanningData: result.storageIntegrity.rawPlanningData,
    ...(result.storageIntegrity.rawStorage ? { rawStorage: result.storageIntegrity.rawStorage } : {})
  };
};

export const createExportDocument = async (): Promise<ExportedDataDocument | RecoveryExportDocument> => {
  const result = await readStoredDataResult();
  if (result.storageIntegrity.status === 'blocked') return createRecoveryExportDocument(result);
  const data = result.data;

  return {
    app: 'Pomodoro Cult',
    exportedAt: new Date().toISOString(),
    storageVersion: CURRENT_STORAGE_VERSION,
    data
  };
};

const hasImportableStorageKey = (value: Record<string, unknown>): boolean =>
  'settings' in value ||
  'tasks' in value ||
  'timerState' in value ||
  'statistics' in value ||
  'focusModes' in value ||
  'selectedFocusModeId' in value ||
  'manualSettings' in value ||
  'sessionEvents' in value ||
  'focusReviewGoals' in value ||
  'sessionEventLogStartedAt' in value ||
  'theme' in value ||
  'taskTemplates' in value ||
  'focusPlans' in value ||
  'focusPlanSchedules' in value ||
  'focusPlanRuns' in value;

export const parseExportDocument = (raw: string, now = Date.now()): StoredData => {
  if (raw.length > 32 * 1024 * 1024) throw new Error('Backup exceeds the integrity limit.');
  const parsed = JSON.parse(raw) as unknown;
  if (!isRecord(parsed)) {
    throw new Error('Invalid backup format.');
  }

  const wrapped = 'data' in parsed;
  if (wrapped && (!exactObjectKeys(parsed, ['app', 'exportedAt', 'storageVersion', 'data']) || parsed.app !== 'Pomodoro Cult' || typeof parsed.exportedAt !== 'string')) {
    throw new Error('Invalid backup wrapper.');
  }
  const candidate =
    'data' in parsed &&
    isRecord(parsed.data)
      ? parsed.data
      : parsed;

  if (!isRecord(candidate) || !hasImportableStorageKey(candidate)) {
    throw new Error('Invalid backup format.');
  }

  const outerVersion = 'data' in parsed ? parsed.storageVersion : candidate.storageVersion ?? 0;
  const candidateVersion = candidate.storageVersion ?? 0;
  if (!Number.isInteger(outerVersion) || !Number.isInteger(candidateVersion) || outerVersion !== candidateVersion || Number(candidateVersion) < 0 || Number(candidateVersion) > CURRENT_STORAGE_VERSION) {
    throw new Error('Unsupported backup version.');
  }
  const forbidden = ['accessContext', 'entitlement', 'entitlementStatus', 'simulator', 'licenseKey', 'token', 'provider'];
  if (forbidden.some((key) => key in candidate || key in parsed)) throw new Error('Backup contains forbidden access data.');
  if (Number(candidateVersion) < CURRENT_STORAGE_VERSION && ['taskTemplates', 'focusPlans', 'focusPlanSchedules', 'focusPlanRuns'].some((key) => key in candidate)) {
    throw new Error('Legacy backup contains newer planning data.');
  }
  if (Number(candidateVersion) === CURRENT_STORAGE_VERSION) {
    if (!exactObjectKeys(candidate, [...storedDataKeys])) {
      throw new Error('Invalid v5 backup keys.');
    }
    const focusModes = normalizeFocusModes(candidate.focusModes as never);
    normalizePlanningCollections(candidate, new Set(focusModes.map((mode) => mode.id)), true);
  } else {
    const legacyAllowed = new Set<string>([...storedDataKeys, STORAGE_KEYS.migrationBackup]);
    for (const key of Object.keys(candidate)) {
      if (!legacyAllowed.has(key) || ['taskTemplates', 'focusPlans', 'focusPlanSchedules', 'focusPlanRuns'].includes(key)) {
        throw new Error('Invalid legacy backup keys.');
      }
    }
  }

  const data = normalizeStoredData(candidate as Partial<PersistedStorage>, now);

  return {
    ...data,
    timerState: getSafeImportedTimerState(data)
  };
};

export const importStoredDataWithAdapter = async (
  raw: string,
  adapter: StorageInitializationAdapter,
  now = Date.now()
): Promise<StoredData> => {
  const data = parseExportDocument(raw, now);
  const current = await adapter.read();
  const currentVersion = getRawVersion(current);
  if (currentVersion === null || currentVersion > CURRENT_STORAGE_VERSION ||
    (currentVersion < CURRENT_STORAGE_VERSION && ['taskTemplates', 'focusPlans', 'focusPlanSchedules', 'focusPlanRuns'].some((key) => Object.prototype.hasOwnProperty.call(current, key))) ||
    (currentVersion < CURRENT_STORAGE_VERSION && current.storageV5MigrationBackup !== undefined &&
      !isValidStorageV5MigrationBackup(current.storageV5MigrationBackup, now, current, currentVersion))) {
    throw new Error('STORAGE_INTEGRITY_BLOCKED');
  }
  const backup = createMigrationBackup(current, CURRENT_STORAGE_VERSION, now);
  await adapter.write({ ...data, migrationBackup: backup });
  return data;
};

export const importStoredData = async (raw: string): Promise<StoredData> =>
  importStoredDataWithAdapter(
    raw,
    {
      read: () => getLocal<Partial<PersistedStorage>>(),
      write: setLocal
    }
  );

export const applyThemeClass = (theme: ThemeMode): void => {
  if (typeof document === 'undefined') return;
  document.documentElement.classList.toggle('dark', theme === 'dark');
};
