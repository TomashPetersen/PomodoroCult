import { FocusPlanRecurrence, FocusPlanSchedule } from './types';

export type FocusPlanScheduleStatus = 'upcoming' | 'due' | 'missed' | 'exhausted';

export interface FocusPlanScheduleEvaluation {
  status: FocusPlanScheduleStatus;
  actionableScheduledDate: string | null;
  actionableOccurrenceToken: string | null;
  collapsedOlderOccurrenceCount: number;
  nextScheduledDate: string | null;
}

const MAX_ORDINAL = 3_652_364;

const isValidLocalDateKey = (value: unknown): value is string => {
  if (typeof value !== 'string') return false;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match || match[1] === '0000') return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
};

const toOrdinal = (key: string): number => {
  const [year, month, day] = key.split('-').map(Number);
  const y = year - (month <= 2 ? 1 : 0);
  const era = Math.floor(y / 400);
  const yoe = y - era * 400;
  const mp = month + (month > 2 ? -3 : 9);
  const doy = Math.floor((153 * mp + 2) / 5) + day - 1;
  return era * 146097 + yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
};

const fromOrdinal = (ordinal: number): string | null => {
  if (!Number.isInteger(ordinal) || ordinal < 306 || ordinal > MAX_ORDINAL) return null;
  const era = Math.floor(ordinal / 146097);
  const doe = ordinal - era * 146097;
  const yoe = Math.floor((doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365);
  let year = yoe + era * 400;
  const doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100));
  const mp = Math.floor((5 * doy + 2) / 153);
  const day = doy - Math.floor((153 * mp + 2) / 5) + 1;
  const month = mp + (mp < 10 ? 3 : -9);
  year += month <= 2 ? 1 : 0;
  if (year < 1 || year > 9999) return null;
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
};

const isoWeekdayFromOrdinal = (ordinal: number): number => ((ordinal + 2) % 7 + 7) % 7 + 1;

const isPlainRecord = (value: unknown): value is Record<PropertyKey, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};

const enumerableOwnKeys = (value: object): PropertyKey[] =>
  Reflect.ownKeys(value).filter((key) => Object.getOwnPropertyDescriptor(value, key)?.enumerable);

const hasExactEnumerableKeys = (value: object, expected: readonly string[]): boolean => {
  const actual = enumerableOwnKeys(value);
  return actual.length === expected.length &&
    actual.every((key) => typeof key === 'string' && expected.includes(key)) &&
    expected.every((key) => Object.prototype.hasOwnProperty.call(value, key));
};

const isDenseArray = (value: unknown): value is unknown[] => {
  if (!Array.isArray(value)) return false;
  const keys = enumerableOwnKeys(value);
  if (keys.length !== value.length) return false;
  for (let index = 0; index < value.length; index += 1) {
    if (!Object.prototype.propertyIsEnumerable.call(value, index)) return false;
  }
  return true;
};

export const normalizeRecurrence = (value: unknown): FocusPlanRecurrence => {
  if (!isPlainRecord(value) || !isValidLocalDateKey(value.startsOn)) throw new Error('INVALID_RECURRENCE');
  if (value.type === 'daily' || value.type === 'weekdays') {
    if (!hasExactEnumerableKeys(value, ['type', 'startsOn'])) throw new Error('INVALID_RECURRENCE');
    return { type: value.type, startsOn: value.startsOn };
  }
  if (value.type !== 'selectedWeekdays' ||
    !hasExactEnumerableKeys(value, ['type', 'startsOn', 'weekdays']) ||
    !isDenseArray(value.weekdays) ||
    value.weekdays.some((day) => !Number.isInteger(day) || Number(day) < 1 || Number(day) > 7)) {
    throw new Error('INVALID_RECURRENCE');
  }
  const weekdays = [...new Set(value.weekdays as number[])].sort((a, b) => a - b);
  if (!weekdays.length) throw new Error('INVALID_RECURRENCE');
  return { type: 'selectedWeekdays', startsOn: value.startsOn, weekdays };
};

const weekdaysFor = (recurrence: FocusPlanRecurrence): readonly number[] =>
  recurrence.type === 'daily'
    ? [1, 2, 3, 4, 5, 6, 7]
    : recurrence.type === 'weekdays'
      ? [1, 2, 3, 4, 5]
      : recurrence.weekdays;

export const isScheduledDate = (recurrence: FocusPlanRecurrence, date: string): boolean => {
  if (!isValidLocalDateKey(date) || date < recurrence.startsOn) return false;
  return weekdaysFor(recurrence).includes(isoWeekdayFromOrdinal(toOrdinal(date)));
};

const scheduledOnOrBefore = (recurrence: FocusPlanRecurrence, date: string): string | null => {
  const anchor = toOrdinal(recurrence.startsOn);
  const end = toOrdinal(date);
  if (end < anchor) return null;
  const allowed = weekdaysFor(recurrence);
  let best = -1;
  for (const weekday of allowed) {
    const delta = (isoWeekdayFromOrdinal(end) - weekday + 7) % 7;
    const candidate = end - delta;
    if (candidate >= anchor) best = Math.max(best, candidate);
  }
  return best < 0 ? null : fromOrdinal(best);
};

const scheduledAfter = (recurrence: FocusPlanRecurrence, date: string): string | null => {
  const start = Math.max(toOrdinal(recurrence.startsOn), toOrdinal(date) + 1);
  const allowed = weekdaysFor(recurrence);
  let best = Number.POSITIVE_INFINITY;
  for (const weekday of allowed) {
    const delta = (weekday - isoWeekdayFromOrdinal(start) + 7) % 7;
    best = Math.min(best, start + delta);
  }
  return fromOrdinal(best);
};

const countScheduled = (recurrence: FocusPlanRecurrence, after: string | null, through: string): number => {
  const lower = Math.max(toOrdinal(recurrence.startsOn), after ? toOrdinal(after) + 1 : toOrdinal(recurrence.startsOn));
  const upper = toOrdinal(through);
  if (upper < lower) return 0;
  if (recurrence.type === 'daily') return upper - lower + 1;
  const fullWeeks = Math.floor((upper - lower + 1) / 7);
  const remainder = (upper - lower + 1) % 7;
  let count = fullWeeks * weekdaysFor(recurrence).length;
  for (let offset = 0; offset < remainder; offset += 1) {
    if (weekdaysFor(recurrence).includes(isoWeekdayFromOrdinal(lower + fullWeeks * 7 + offset))) count += 1;
  }
  return count;
};

export const evaluateFocusPlanSchedule = (
  schedule: FocusPlanSchedule,
  today: string
): FocusPlanScheduleEvaluation => {
  if (!isValidLocalDateKey(today)) throw new Error('INVALID_LOCAL_DATE');
  const latest = schedule.enabled ? scheduledOnOrBefore(schedule.recurrence, today) : null;
  const actionable = latest && (!schedule.lastHandledScheduledDate || latest > schedule.lastHandledScheduledDate)
    ? latest
    : null;
  const basis = actionable ?? (schedule.lastHandledScheduledDate && schedule.lastHandledScheduledDate > today
    ? schedule.lastHandledScheduledDate
    : today);
  const next = scheduledAfter(schedule.recurrence, basis);
  const status: FocusPlanScheduleStatus = actionable
    ? actionable === today ? 'due' : 'missed'
    : next ? 'upcoming' : 'exhausted';
  const count = actionable
    ? Math.max(0, countScheduled(schedule.recurrence, schedule.lastHandledScheduledDate, actionable) - 1)
    : 0;
  return {
    status,
    actionableScheduledDate: actionable,
    actionableOccurrenceToken: actionable ? `${schedule.id}:${schedule.generation}:${actionable}` : null,
    collapsedOlderOccurrenceCount: count,
    nextScheduledDate: next
  };
};
