import { requireFeature } from './access';
import { TASK_TITLE_MAX_LENGTH } from './constants';
import { evaluateFocusPlanSchedule, normalizeRecurrence } from './focusPlanRecurrence';
import { PLANNING_INTEGRITY_LIMITS } from './focusPlanStorage';
import { clampTaskTitle, getTaskTitleKey, sortTasks } from './storage';
import {
  AccessContext,
  FocusPlan,
  FocusPlanRecurrence,
  FocusPlanRun,
  FocusPlanSchedule,
  FocusPlanStep,
  RuntimeMessage,
  StoredData,
  Task,
  TaskTemplate
} from './types';

export interface PlanningMutationContext {
  now: number;
  today: string;
  createId(kind: 'template' | 'plan' | 'step' | 'schedule' | 'run' | 'task'): string;
}

export type PlanningMessage = Extract<RuntimeMessage, {
  type:
    | 'CREATE_TASK_TEMPLATE'
    | 'UPDATE_TASK_TEMPLATE'
    | 'DELETE_TASK_TEMPLATE'
    | 'CREATE_FOCUS_PLAN'
    | 'UPDATE_FOCUS_PLAN'
    | 'DELETE_FOCUS_PLAN'
    | 'CREATE_FOCUS_PLAN_SCHEDULE'
    | 'UPDATE_FOCUS_PLAN_SCHEDULE'
    | 'SET_FOCUS_PLAN_SCHEDULE_ENABLED'
    | 'DELETE_FOCUS_PLAN_SCHEDULE'
    | 'START_FOCUS_PLAN'
    | 'SKIP_FOCUS_PLAN_OCCURRENCE';
}>;

export interface PlanningMutationResult {
  patch: Partial<StoredData>;
  run?: FocusPlanRun;
}

const ID_PATTERN = /^[A-Za-z0-9._:-]{1,128}$/;
const PLAN_TITLE_MAX_LENGTH = 80;

const isPlainRecord = (value: unknown): value is Record<PropertyKey, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};

const enumerableOwnKeys = (value: object): PropertyKey[] =>
  Reflect.ownKeys(value).filter((key) => Object.getOwnPropertyDescriptor(value, key)?.enumerable);

const hasExactEnumerableKeys = (value: object, expected: readonly string[]): boolean => {
  const actual = enumerableOwnKeys(value);
  return actual.length === expected.length &&
    actual.every((key) => typeof key === 'string' && expected.includes(key)) &&
    expected.every((key) => Object.prototype.hasOwnProperty.call(value, key));
};

const isDenseArray = (value: unknown): value is unknown[] => {
  if (!Array.isArray(value)) return false;
  const keys = enumerableOwnKeys(value);
  if (keys.length !== value.length) return false;
  for (let index = 0; index < value.length; index += 1) {
    if (!Object.prototype.propertyIsEnumerable.call(value, index)) return false;
  }
  return true;
};

const isPlanningId = (value: unknown): value is string =>
  typeof value === 'string' && ID_PATTERN.test(value);

const isTitleInput = (value: unknown, max: number): value is string => {
  if (typeof value !== 'string') return false;
  const normalized = value.trim().replace(/\s+/g, ' ');
  return normalized.slice(0, max).length > 0;
};

const isTarget = (value: unknown): value is number =>
  Number.isInteger(value) && Number(value) >= 1 && Number(value) <= 99;

const isNullablePlanningId = (value: unknown): value is string | null =>
  value === null || isPlanningId(value);

const isOccurrenceToken = (value: unknown, nullable: boolean): boolean =>
  (nullable && value === null) || (typeof value === 'string' && value.length > 0 && value.length <= 512);

const isValidStepPayload = (value: unknown): boolean =>
  isPlainRecord(value) &&
  hasExactEnumerableKeys(value, ['id', 'sourceTemplateId', 'titleSnapshot', 'focusModeIdSnapshot', 'targetWorkSessions']) &&
  isPlanningId(value.id) &&
  isNullablePlanningId(value.sourceTemplateId) &&
  isTitleInput(value.titleSnapshot, TASK_TITLE_MAX_LENGTH) &&
  isNullablePlanningId(value.focusModeIdSnapshot) &&
  isTarget(value.targetWorkSessions);

const isValidRecurrencePayload = (value: unknown): boolean => {
  try {
    normalizeRecurrence(value);
    return true;
  } catch {
    return false;
  }
};

const planningMessageTypes = [
  'CREATE_TASK_TEMPLATE',
  'UPDATE_TASK_TEMPLATE',
  'DELETE_TASK_TEMPLATE',
  'CREATE_FOCUS_PLAN',
  'UPDATE_FOCUS_PLAN',
  'DELETE_FOCUS_PLAN',
  'CREATE_FOCUS_PLAN_SCHEDULE',
  'UPDATE_FOCUS_PLAN_SCHEDULE',
  'SET_FOCUS_PLAN_SCHEDULE_ENABLED',
  'DELETE_FOCUS_PLAN_SCHEDULE',
  'START_FOCUS_PLAN',
  'SKIP_FOCUS_PLAN_OCCURRENCE'
] as const satisfies readonly PlanningMessage['type'][];

const isPlanningMessageType = (value: unknown): value is PlanningMessage['type'] =>
  typeof value === 'string' && (planningMessageTypes as readonly string[]).includes(value);

const hasValidPlanningPayload = (type: PlanningMessage['type'], payload: unknown): boolean => {
  if (!isPlainRecord(payload)) return false;
  switch (type) {
    case 'CREATE_TASK_TEMPLATE':
      return hasExactEnumerableKeys(payload, ['title', 'focusModeId', 'targetWorkSessions']) &&
        isTitleInput(payload.title, TASK_TITLE_MAX_LENGTH) &&
        isNullablePlanningId(payload.focusModeId) &&
        isTarget(payload.targetWorkSessions);
    case 'UPDATE_TASK_TEMPLATE':
      return hasExactEnumerableKeys(payload, ['templateId', 'title', 'focusModeId', 'targetWorkSessions']) &&
        isPlanningId(payload.templateId) &&
        isTitleInput(payload.title, TASK_TITLE_MAX_LENGTH) &&
        isNullablePlanningId(payload.focusModeId) &&
        isTarget(payload.targetWorkSessions);
    case 'DELETE_TASK_TEMPLATE':
      return hasExactEnumerableKeys(payload, ['templateId']) && isPlanningId(payload.templateId);
    case 'CREATE_FOCUS_PLAN':
      return hasExactEnumerableKeys(payload, ['title', 'steps']) &&
        isTitleInput(payload.title, PLAN_TITLE_MAX_LENGTH) &&
        isDenseArray(payload.steps) &&
        payload.steps.length >= 1 &&
        payload.steps.length <= PLANNING_INTEGRITY_LIMITS.stepsPerPlan &&
        payload.steps.every(isValidStepPayload);
    case 'UPDATE_FOCUS_PLAN':
      return hasExactEnumerableKeys(payload, ['planId', 'title', 'steps']) &&
        isPlanningId(payload.planId) &&
        isTitleInput(payload.title, PLAN_TITLE_MAX_LENGTH) &&
        isDenseArray(payload.steps) &&
        payload.steps.length >= 1 &&
        payload.steps.length <= PLANNING_INTEGRITY_LIMITS.stepsPerPlan &&
        payload.steps.every(isValidStepPayload);
    case 'DELETE_FOCUS_PLAN':
      return hasExactEnumerableKeys(payload, ['planId']) && isPlanningId(payload.planId);
    case 'CREATE_FOCUS_PLAN_SCHEDULE':
      return hasExactEnumerableKeys(payload, ['planId', 'recurrence']) &&
        isPlanningId(payload.planId) && isValidRecurrencePayload(payload.recurrence);
    case 'UPDATE_FOCUS_PLAN_SCHEDULE':
      return hasExactEnumerableKeys(payload, ['scheduleId', 'recurrence']) &&
        isPlanningId(payload.scheduleId) && isValidRecurrencePayload(payload.recurrence);
    case 'SET_FOCUS_PLAN_SCHEDULE_ENABLED':
      return hasExactEnumerableKeys(payload, ['scheduleId', 'enabled']) &&
        isPlanningId(payload.scheduleId) && typeof payload.enabled === 'boolean';
    case 'DELETE_FOCUS_PLAN_SCHEDULE':
      return hasExactEnumerableKeys(payload, ['scheduleId']) && isPlanningId(payload.scheduleId);
    case 'START_FOCUS_PLAN':
      return hasExactEnumerableKeys(payload, ['planId', 'requestId', 'occurrenceToken']) &&
        isPlanningId(payload.planId) && isPlanningId(payload.requestId) &&
        isOccurrenceToken(payload.occurrenceToken, true);
    case 'SKIP_FOCUS_PLAN_OCCURRENCE':
      return hasExactEnumerableKeys(payload, ['planId', 'scheduleId', 'occurrenceToken']) &&
        isPlanningId(payload.planId) && isPlanningId(payload.scheduleId) &&
        isOccurrenceToken(payload.occurrenceToken, false);
  }
};

export const parsePlanningMessage = (value: unknown): PlanningMessage => {
  if (!isPlainRecord(value) ||
    !hasExactEnumerableKeys(value, ['type', 'payload']) ||
    !isPlanningMessageType(value.type) ||
    !hasValidPlanningPayload(value.type, value.payload)) {
    throw new Error('INVALID_PLANNING_PAYLOAD');
  }
  return value as unknown as PlanningMessage;
};

const title = (value: unknown, max: number): string => {
  if (typeof value !== 'string') throw new Error('INVALID_TITLE');
  const normalized = value.trim().replace(/\s+/g, ' ').slice(0, max);
  if (!normalized) throw new Error('INVALID_TITLE');
  return normalized;
};

const target = (value: unknown): number => {
  const numeric = Number(value);
  if (!Number.isInteger(value) || numeric < 1 || numeric > 99) throw new Error('INVALID_TARGET');
  return numeric;
};

const monotonic = (createdAt: number, updatedAt: number, now: number): number =>
  Math.max(createdAt, updatedAt, now);

const ensureFocusMode = (data: StoredData, id: unknown): string | null => {
  if (id === null) return null;
  if (!isPlanningId(id)) throw new Error('FOCUS_MODE_NOT_FOUND');
  if (!data.focusModes.some((mode) => mode.id === id)) throw new Error('FOCUS_MODE_NOT_FOUND');
  return id;
};

const reservedIds = (data: StoredData, kind: Parameters<PlanningMutationContext['createId']>[0]): Set<string> => {
  if (kind === 'template') return new Set([
    ...data.taskTemplates.map((item) => item.id),
    ...data.focusPlans.flatMap((plan) => plan.steps.map((step) => step.sourceTemplateId).filter((id): id is string => Boolean(id)))
  ]);
  if (kind === 'plan') return new Set([...data.focusPlans.map((item) => item.id), ...data.focusPlanRuns.map((run) => run.planId)]);
  if (kind === 'step') return new Set(data.focusPlans.flatMap((plan) => plan.steps.map((step) => step.id)));
  if (kind === 'schedule') return new Set([
    ...data.focusPlanSchedules.map((item) => item.id),
    ...data.focusPlanRuns.flatMap((run) => run.occurrenceKey ? [run.occurrenceKey.split(':').slice(0, -2).join(':')] : [])
  ]);
  if (kind === 'run') return new Set(data.focusPlanRuns.map((item) => item.id));
  return new Set([
    ...data.tasks.map((item) => item.id),
    ...data.focusPlanRuns.flatMap((run) => run.items.map((item) => item.taskId)),
    ...data.sessionEvents.map((event) => event.taskId),
    ...Object.values(data.statistics).flatMap((day) => Object.keys(day.tasks))
  ]);
};

const nextId = (
  data: StoredData,
  context: PlanningMutationContext,
  kind: Parameters<PlanningMutationContext['createId']>[0],
  generated: Set<string>
): string => {
  const id = context.createId(kind);
  if (!isPlanningId(id) || reservedIds(data, kind).has(id) || generated.has(id)) {
    throw new Error('ID_COLLISION');
  }
  generated.add(id);
  return id;
};

const normalizeSteps = (
  data: StoredData,
  steps: FocusPlanStep[],
  context: PlanningMutationContext,
  generated: Set<string>,
  existing?: FocusPlan
): FocusPlanStep[] => {
  if (!Array.isArray(steps) || steps.length < 1 || steps.length > PLANNING_INTEGRITY_LIMITS.stepsPerPlan) {
    throw new Error('INVALID_PLAN_STEPS');
  }
  const existingIds = new Set(existing?.steps.map((step) => step.id) ?? []);
  const ids = new Set<string>();
  const titles = new Set<string>();
  return steps.map((step) => {
    const existingStep = existing?.steps.find((item) => item.id === step.id);
    const sourceTemplate = step.sourceTemplateId === null
      ? undefined
      : data.taskTemplates.find((item) => item.id === step.sourceTemplateId);
    if (step.sourceTemplateId !== null && !sourceTemplate && existingStep?.sourceTemplateId !== step.sourceTemplateId) {
      throw new Error('TEMPLATE_NOT_FOUND');
    }
    const snapshot = sourceTemplate && existingStep?.sourceTemplateId !== sourceTemplate.id
      ? {
          titleSnapshot: sourceTemplate.title,
          focusModeIdSnapshot: sourceTemplate.focusModeId,
          targetWorkSessions: sourceTemplate.targetWorkSessions
        }
      : step;
    const normalizedTitle = title(snapshot.titleSnapshot, TASK_TITLE_MAX_LENGTH);
    const titleKey = getTaskTitleKey(normalizedTitle);
    if (titles.has(titleKey)) throw new Error('DUPLICATE_PLAN_TITLE');
    titles.add(titleKey);
    const id = existingIds.has(step.id) ? step.id : nextId(data, context, 'step', generated);
    if (ids.has(id)) throw new Error('DUPLICATE_STEP_ID');
    ids.add(id);
    return {
      id,
      sourceTemplateId: step.sourceTemplateId,
      titleSnapshot: normalizedTitle,
      focusModeIdSnapshot: ensureFocusMode(data, snapshot.focusModeIdSnapshot),
      targetWorkSessions: target(snapshot.targetWorkSessions)
    };
  });
};

const validatePlanForStart = (data: StoredData, plan: FocusPlan): void => {
  if (!Array.isArray(plan.steps) || plan.steps.length < 1 || plan.steps.length > PLANNING_INTEGRITY_LIMITS.stepsPerPlan) {
    throw new Error('INVALID_PLAN_STEPS');
  }
  const titles = new Set<string>();
  const stepIds = new Set<string>();
  for (const step of plan.steps) {
    const normalizedTitle = title(step.titleSnapshot, TASK_TITLE_MAX_LENGTH);
    if (normalizedTitle !== step.titleSnapshot || !ID_PATTERN.test(step.id) || stepIds.has(step.id)) {
      throw new Error('INVALID_PLAN_STEPS');
    }
    stepIds.add(step.id);
    const titleKey = getTaskTitleKey(normalizedTitle);
    if (titles.has(titleKey)) throw new Error('DUPLICATE_PLAN_TITLE');
    titles.add(titleKey);
    ensureFocusMode(data, step.focusModeIdSnapshot);
    target(step.targetWorkSessions);
  }
};

export const applyFocusPlanMutation = (
  data: StoredData,
  message: PlanningMessage,
  access: AccessContext,
  context: PlanningMutationContext
): PlanningMutationResult => {
  parsePlanningMessage(message);
  const generated = new Set<string>();
  const requirePlanning = (): void => requireFeature('focusPlans', access);
  const requireTemplates = (): void => requireFeature('taskTemplates', access);
  const requireRecurrence = (): void => requireFeature('recurringPlans', access);

  switch (message.type) {
    case 'CREATE_TASK_TEMPLATE': {
      requireTemplates();
      if (data.taskTemplates.length >= PLANNING_INTEGRITY_LIMITS.taskTemplates) {
        throw new Error('COLLECTION_LIMIT');
      }
      const item: TaskTemplate = {
        id: nextId(data, context, 'template', generated),
        title: title(message.payload.title, TASK_TITLE_MAX_LENGTH),
        focusModeId: ensureFocusMode(data, message.payload.focusModeId),
        targetWorkSessions: target(message.payload.targetWorkSessions),
        createdAt: context.now,
        updatedAt: context.now
      };
      return { patch: { taskTemplates: [...data.taskTemplates, item] } };
    }
    case 'UPDATE_TASK_TEMPLATE': {
      requireTemplates();
      const existing = data.taskTemplates.find((item) => item.id === message.payload.templateId);
      if (!existing) throw new Error('TEMPLATE_NOT_FOUND');
      return { patch: { taskTemplates: data.taskTemplates.map((item) => item.id === existing.id ? {
        ...item,
        title: title(message.payload.title, TASK_TITLE_MAX_LENGTH),
        focusModeId: ensureFocusMode(data, message.payload.focusModeId),
        targetWorkSessions: target(message.payload.targetWorkSessions),
        updatedAt: monotonic(item.createdAt, item.updatedAt, context.now)
      } : item) } };
    }
    case 'DELETE_TASK_TEMPLATE':
      if (!data.taskTemplates.some((item) => item.id === message.payload.templateId)) {
        throw new Error('TEMPLATE_NOT_FOUND');
      }
      return { patch: { taskTemplates: data.taskTemplates.filter((item) => item.id !== message.payload.templateId) } };
    case 'CREATE_FOCUS_PLAN': {
      requirePlanning();
      if (data.focusPlans.length >= PLANNING_INTEGRITY_LIMITS.focusPlans) {
        throw new Error('COLLECTION_LIMIT');
      }
      if (Array.isArray(message.payload.steps) &&
        data.focusPlans.reduce((sum, item) => sum + item.steps.length, 0) + message.payload.steps.length > PLANNING_INTEGRITY_LIMITS.totalSteps) {
        throw new Error('TOTAL_STEP_LIMIT');
      }
      const plan: FocusPlan = {
        id: nextId(data, context, 'plan', generated),
        title: title(message.payload.title, PLAN_TITLE_MAX_LENGTH),
        steps: normalizeSteps(data, message.payload.steps, context, generated),
        createdAt: context.now,
        updatedAt: context.now
      };
      return { patch: { focusPlans: [...data.focusPlans, plan] } };
    }
    case 'UPDATE_FOCUS_PLAN': {
      requirePlanning();
      const existing = data.focusPlans.find((item) => item.id === message.payload.planId);
      if (!existing) throw new Error('PLAN_NOT_FOUND');
      if (Array.isArray(message.payload.steps) &&
        data.focusPlans.reduce((sum, item) => sum + item.steps.length, 0) - existing.steps.length + message.payload.steps.length > PLANNING_INTEGRITY_LIMITS.totalSteps) {
        throw new Error('TOTAL_STEP_LIMIT');
      }
      const plan: FocusPlan = {
        ...existing,
        title: title(message.payload.title, PLAN_TITLE_MAX_LENGTH),
        steps: normalizeSteps(data, message.payload.steps, context, generated, existing),
        updatedAt: monotonic(existing.createdAt, existing.updatedAt, context.now)
      };
      return { patch: { focusPlans: data.focusPlans.map((item) => item.id === plan.id ? plan : item) } };
    }
    case 'DELETE_FOCUS_PLAN':
      if (!data.focusPlans.some((item) => item.id === message.payload.planId)) {
        throw new Error('PLAN_NOT_FOUND');
      }
      return { patch: {
        focusPlans: data.focusPlans.filter((item) => item.id !== message.payload.planId),
        focusPlanSchedules: data.focusPlanSchedules.filter((item) => item.focusPlanId !== message.payload.planId)
      } };
    case 'CREATE_FOCUS_PLAN_SCHEDULE': {
      requireRecurrence();
      if (data.focusPlanSchedules.length >= PLANNING_INTEGRITY_LIMITS.focusPlanSchedules) {
        throw new Error('COLLECTION_LIMIT');
      }
      if (!data.focusPlans.some((plan) => plan.id === message.payload.planId)) throw new Error('PLAN_NOT_FOUND');
      if (data.focusPlanSchedules.some((item) => item.focusPlanId === message.payload.planId)) throw new Error('SCHEDULE_EXISTS');
      const recurrence = normalizeRecurrence(message.payload.recurrence);
      if (recurrence.startsOn < context.today) throw new Error('PAST_SCHEDULE_ANCHOR');
      const schedule: FocusPlanSchedule = {
        id: nextId(data, context, 'schedule', generated),
        focusPlanId: message.payload.planId,
        generation: 1,
        enabled: true,
        recurrence,
        lastHandledScheduledDate: null,
        createdAt: context.now,
        updatedAt: context.now
      };
      return { patch: { focusPlanSchedules: [...data.focusPlanSchedules, schedule] } };
    }
    case 'UPDATE_FOCUS_PLAN_SCHEDULE': {
      requireRecurrence();
      const existing = data.focusPlanSchedules.find((item) => item.id === message.payload.scheduleId);
      if (!existing) throw new Error('SCHEDULE_NOT_FOUND');
      const recurrence = normalizeRecurrence(message.payload.recurrence);
      const same = JSON.stringify(recurrence) === JSON.stringify(existing.recurrence);
      if (!same && recurrence.startsOn < context.today) throw new Error('PAST_SCHEDULE_ANCHOR');
      if (!same && existing.generation === Number.MAX_SAFE_INTEGER) throw new Error('SCHEDULE_GENERATION_EXHAUSTED');
      const schedule = {
        ...existing,
        recurrence,
        generation: same ? existing.generation : existing.generation + 1,
        lastHandledScheduledDate: same ? existing.lastHandledScheduledDate : null,
        updatedAt: monotonic(existing.createdAt, existing.updatedAt, context.now)
      };
      return { patch: { focusPlanSchedules: data.focusPlanSchedules.map((item) => item.id === schedule.id ? schedule : item) } };
    }
    case 'SET_FOCUS_PLAN_SCHEDULE_ENABLED': {
      const existing = data.focusPlanSchedules.find((item) => item.id === message.payload.scheduleId);
      if (!existing) throw new Error('SCHEDULE_NOT_FOUND');
      if (message.payload.enabled) requireRecurrence();
      return { patch: { focusPlanSchedules: data.focusPlanSchedules.map((item) => item.id === existing.id ? {
        ...item,
        enabled: message.payload.enabled,
        updatedAt: monotonic(item.createdAt, item.updatedAt, context.now)
      } : item) } };
    }
    case 'DELETE_FOCUS_PLAN_SCHEDULE':
      if (!data.focusPlanSchedules.some((item) => item.id === message.payload.scheduleId)) {
        throw new Error('SCHEDULE_NOT_FOUND');
      }
      return { patch: { focusPlanSchedules: data.focusPlanSchedules.filter((item) => item.id !== message.payload.scheduleId) } };
    case 'SKIP_FOCUS_PLAN_OCCURRENCE': {
      requireRecurrence();
      const schedule = data.focusPlanSchedules.find((item) => item.id === message.payload.scheduleId);
      if (!schedule || schedule.focusPlanId !== message.payload.planId || !schedule.enabled) {
        throw new Error('SCHEDULE_NOT_FOUND');
      }
      const evaluation = evaluateFocusPlanSchedule(schedule, context.today);
      if (evaluation.actionableOccurrenceToken !== message.payload.occurrenceToken || !evaluation.actionableScheduledDate) {
        throw new Error('STALE_OCCURRENCE');
      }
      return { patch: { focusPlanSchedules: data.focusPlanSchedules.map((item) => item.id === schedule.id ? {
        ...item,
        lastHandledScheduledDate: evaluation.actionableScheduledDate,
        updatedAt: monotonic(item.createdAt, item.updatedAt, context.now)
      } : item) } };
    }
    case 'START_FOCUS_PLAN': {
      if (!ID_PATTERN.test(message.payload.requestId)) throw new Error('INVALID_REQUEST_ID');
      const requestRun = data.focusPlanRuns.find((run) => run.requestId === message.payload.requestId);
      if (requestRun) {
        if (requestRun.planId !== message.payload.planId || requestRun.occurrenceKey !== message.payload.occurrenceToken) {
          throw new Error('REQUEST_ID_CONFLICT');
        }
        return { patch: {}, run: requestRun };
      }
      requirePlanning();
      const plan = data.focusPlans.find((item) => item.id === message.payload.planId);
      if (!plan) throw new Error('PLAN_NOT_FOUND');
      validatePlanForStart(data, plan);
      const occurrenceRun = message.payload.occurrenceToken
        ? data.focusPlanRuns.find((run) => run.occurrenceKey === message.payload.occurrenceToken)
        : undefined;
      if (occurrenceRun) {
        if (occurrenceRun.planId !== plan.id) throw new Error('OCCURRENCE_PLAN_CONFLICT');
        return { patch: {}, run: occurrenceRun };
      }
      if (data.focusPlanRuns.length >= PLANNING_INTEGRITY_LIMITS.focusPlanRuns) {
        throw new Error('COLLECTION_LIMIT');
      }
      if (data.focusPlanRuns.reduce((sum, run) => sum + run.items.length, 0) + plan.steps.length > PLANNING_INTEGRITY_LIMITS.totalRunItems) {
        throw new Error('TOTAL_RUN_ITEM_LIMIT');
      }
      const schedule = data.focusPlanSchedules.find((item) => item.focusPlanId === plan.id && item.enabled);
      let scheduledForLocalDate: string | null = null;
      if (schedule) {
        requireRecurrence();
        const evaluation = evaluateFocusPlanSchedule(schedule, context.today);
        if (message.payload.occurrenceToken !== evaluation.actionableOccurrenceToken || !evaluation.actionableScheduledDate) {
          throw new Error('STALE_OCCURRENCE');
        }
        scheduledForLocalDate = evaluation.actionableScheduledDate;
      } else if (message.payload.occurrenceToken !== null) {
        throw new Error('STALE_OCCURRENCE');
      }
      const activeByTitle = new Map<string, Task[]>();
      for (const taskItem of data.tasks) {
        if (taskItem.system || taskItem.archived) continue;
        const key = getTaskTitleKey(taskItem.title);
        activeByTitle.set(key, [...(activeByTitle.get(key) ?? []), taskItem]);
      }
      const tasks = [...data.tasks];
      const items = plan.steps.map((step) => {
        const matches = activeByTitle.get(getTaskTitleKey(step.titleSnapshot)) ?? [];
        if (matches.length > 1) throw new Error('AMBIGUOUS_ACTIVE_TASK_TITLE');
        let taskItem = matches[0];
        let materialization: 'created' | 'reused' = 'reused';
        if (!taskItem) {
          materialization = 'created';
          taskItem = {
            id: nextId(data, context, 'task', generated),
            title: clampTaskTitle(step.titleSnapshot),
            createdAt: context.now,
            usageCount: 0,
            lastUsed: 0,
            system: false,
            archived: false,
            archivedAt: null,
            focusModeId: step.focusModeIdSnapshot
          };
          tasks.push(taskItem);
          activeByTitle.set(getTaskTitleKey(taskItem.title), [taskItem]);
        }
        return {
          taskId: taskItem.id,
          materialization,
          titleSnapshot: step.titleSnapshot,
          focusModeIdSnapshot: step.focusModeIdSnapshot,
          targetWorkSessions: step.targetWorkSessions
        };
      });
      const run: FocusPlanRun = {
        id: nextId(data, context, 'run', generated),
        requestId: message.payload.requestId,
        planId: plan.id,
        planTitleSnapshot: plan.title,
        occurrenceKey: message.payload.occurrenceToken,
        scheduledForLocalDate,
        startedLocalDate: context.today,
        startedAt: context.now,
        items
      };
      const patch: Partial<StoredData> = { tasks: sortTasks(tasks), focusPlanRuns: [...data.focusPlanRuns, run] };
      if (schedule && scheduledForLocalDate) {
        patch.focusPlanSchedules = data.focusPlanSchedules.map((item) => item.id === schedule.id ? {
          ...item,
          lastHandledScheduledDate: scheduledForLocalDate,
          updatedAt: monotonic(item.createdAt, item.updatedAt, context.now)
        } : item);
      }
      return { patch, run };
    }
  }
  const exhaustive: never = message;
  throw new Error(`UNSUPPORTED_PLANNING_MESSAGE:${String(exhaustive)}`);
};

export const createRuntimePlanningContext = (now = Date.now()): PlanningMutationContext => ({
  now,
  today: (() => {
    const date = new Date(now);
    return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  })(),
  createId: (kind) => `${kind}-${typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${now}-${Math.random().toString(16).slice(2)}`}`
});
