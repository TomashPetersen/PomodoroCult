export const supportsFocusMusic = (): boolean => {
  const background = chrome.runtime.getManifest().background;
  return Boolean(background && (
    ('service_worker' in background && background.service_worker) ||
    ('page' in background && background.page) ||
    ('scripts' in background && background.scripts?.length)
  ));
};
