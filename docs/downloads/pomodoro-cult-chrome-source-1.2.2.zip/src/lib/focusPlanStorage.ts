import { normalizeRecurrence, isScheduledDate } from './focusPlanRecurrence';
import { TASK_TITLE_MAX_LENGTH } from './constants';
import {
  FocusPlan,
  FocusPlanRun,
  FocusPlanSchedule,
  PlanningStorageKey,
  StorageIntegrityState,
  StoredData,
  TaskTemplate
} from './types';

const ID_PATTERN = /^[A-Za-z0-9._:-]{1,128}$/;
const MAX_JS_DATE_TIMESTAMP = 8.64e15;
const KEYS: PlanningStorageKey[] = ['taskTemplates', 'focusPlans', 'focusPlanSchedules', 'focusPlanRuns'];
export const PLANNING_INTEGRITY_LIMITS = {
  taskTemplates: 5000,
  focusPlans: 2000,
  focusPlanSchedules: 2000,
  focusPlanRuns: 50000,
  stepsPerPlan: 100,
  totalSteps: 50000,
  runItemsPerRun: 100,
  totalRunItems: 250000
} as const;

const record = (value: unknown): value is Record<string, unknown> =>
  Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const enumerableOwnKeys = (value: object): PropertyKey[] =>
  Reflect.ownKeys(value).filter((key) => Object.getOwnPropertyDescriptor(value, key)?.enumerable);
const denseArray = (value: unknown): value is unknown[] => {
  if (!Array.isArray(value)) return false;
  const keys = enumerableOwnKeys(value);
  if (keys.length !== value.length) return false;
  for (let index = 0; index < value.length; index += 1) {
    if (!Object.prototype.propertyIsEnumerable.call(value, index)) return false;
  }
  return true;
};
const timestamp = (value: unknown): value is number =>
  Number.isInteger(value) && Number(value) >= 0 && Number(value) <= MAX_JS_DATE_TIMESTAMP;
const id = (value: unknown): value is string => typeof value === 'string' && ID_PATTERN.test(value);
const target = (value: unknown): value is number => Number.isInteger(value) && Number(value) >= 1 && Number(value) <= 99;
const exactKeys = (value: Record<string, unknown>, keys: string[]): boolean =>
  Object.keys(value).length === keys.length && keys.every((key) => Object.prototype.hasOwnProperty.call(value, key));
const clampTaskTitle = (value: string): string =>
  value.trim().replace(/\s+/g, ' ').slice(0, TASK_TITLE_MAX_LENGTH);
const getTaskTitleKey = (value: string): string => clampTaskTitle(value).toLocaleLowerCase('en');
const isValidLocalDateKey = (value: unknown): value is string => {
  if (typeof value !== 'string') return false;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match || match[1] === '0000') return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
};

export interface PlanningNormalizationResult {
  collections: Pick<StoredData, PlanningStorageKey>;
  integrity: StorageIntegrityState;
}

export const normalizePlanningCollections = (
  raw: Record<string, unknown>,
  focusModeIds: Set<string>,
  strict = false
): PlanningNormalizationResult => {
  const issues: Array<{ code: string; path: string }> = [];
  const fail = (code: string, path: string): void => {
    issues.push({ code, path });
    if (strict) throw new Error(`${code}:${path}`);
  };
  const arrays: Record<PlanningStorageKey, unknown[]> = {
    taskTemplates: [], focusPlans: [], focusPlanSchedules: [], focusPlanRuns: []
  };
  for (const key of KEYS) {
    const value = raw[key];
    if (!denseArray(value)) {
      fail('INVALID_COLLECTION', key);
      continue;
    }
    if (value.length > PLANNING_INTEGRITY_LIMITS[key]) {
      fail('COLLECTION_LIMIT', key);
      continue;
    }
    arrays[key] = value;
  }

  const mutableCandidates = (values: unknown[]) => values
    .map((value, index) => ({ value, index }))
    .sort((left, right) => {
      const leftRecord = record(left.value) ? left.value : {};
      const rightRecord = record(right.value) ? right.value : {};
      const leftUpdated = timestamp(leftRecord.updatedAt) ? leftRecord.updatedAt : -1;
      const rightUpdated = timestamp(rightRecord.updatedAt) ? rightRecord.updatedAt : -1;
      const leftCreated = timestamp(leftRecord.createdAt) ? leftRecord.createdAt : -1;
      const rightCreated = timestamp(rightRecord.createdAt) ? rightRecord.createdAt : -1;
      const leftId = id(leftRecord.id) ? leftRecord.id : '';
      const rightId = id(rightRecord.id) ? rightRecord.id : '';
      return rightUpdated - leftUpdated || rightCreated - leftCreated ||
        (leftId < rightId ? -1 : leftId > rightId ? 1 : 0) || left.index - right.index;
    });
  const runCandidates = (values: unknown[]) => values
    .map((value, index) => ({ value, index }))
    .sort((left, right) => {
      const leftRecord = record(left.value) ? left.value : {};
      const rightRecord = record(right.value) ? right.value : {};
      const leftStarted = timestamp(leftRecord.startedAt) ? leftRecord.startedAt : Number.POSITIVE_INFINITY;
      const rightStarted = timestamp(rightRecord.startedAt) ? rightRecord.startedAt : Number.POSITIVE_INFINITY;
      const leftId = id(leftRecord.id) ? leftRecord.id : '';
      const rightId = id(rightRecord.id) ? rightRecord.id : '';
      return leftStarted - rightStarted || (leftId < rightId ? -1 : leftId > rightId ? 1 : 0) || left.index - right.index;
    });

  const templates: TaskTemplate[] = [];
  const templateIds = new Set<string>();
  mutableCandidates(arrays.taskTemplates).forEach(({ value, index }) => {
    const path = `taskTemplates[${index}]`;
    if (!record(value) || !exactKeys(value, ['id', 'title', 'focusModeId', 'targetWorkSessions', 'createdAt', 'updatedAt']) ||
      !id(value.id) || typeof value.title !== 'string' || clampTaskTitle(value.title) !== value.title || !value.title ||
      !(value.focusModeId === null || id(value.focusModeId)) || !target(value.targetWorkSessions) ||
      !timestamp(value.createdAt) || !timestamp(value.updatedAt) || value.updatedAt < value.createdAt) {
      fail('INVALID_TEMPLATE', path); return;
    }
    if (templateIds.has(value.id)) { fail('DUPLICATE_TEMPLATE_ID', path); return; }
    const focusModeId = value.focusModeId !== null && !focusModeIds.has(value.focusModeId)
      ? (fail('DANGLING_FOCUS_MODE', `${path}.focusModeId`), null)
      : value.focusModeId;
    templateIds.add(value.id);
    templates.push({ ...(value as unknown as TaskTemplate), focusModeId });
  });

  const plans: FocusPlan[] = [];
  const planIds = new Set<string>();
  const stepIds = new Set<string>();
  let totalSteps = 0;
  mutableCandidates(arrays.focusPlans).forEach(({ value, index }) => {
    const path = `focusPlans[${index}]`;
    if (!record(value) || !exactKeys(value, ['id', 'title', 'steps', 'createdAt', 'updatedAt']) || !id(value.id) ||
      typeof value.title !== 'string' || value.title.trim().replace(/\s+/g, ' ') !== value.title || !value.title || value.title.length > 80 ||
      !timestamp(value.createdAt) || !timestamp(value.updatedAt) || value.updatedAt < value.createdAt || !denseArray(value.steps) || !value.steps.length || value.steps.length > PLANNING_INTEGRITY_LIMITS.stepsPerPlan) {
      fail('INVALID_PLAN', path); return;
    }
    if (planIds.has(value.id)) { fail('DUPLICATE_PLAN_ID', path); return; }
    const titleKeys = new Set<string>();
    const candidateStepIds = new Set<string>();
    const normalizedSteps: FocusPlan['steps'] = [];
    const steps = value.steps.every((step, stepIndex) => {
      const stepPath = `${path}.steps[${stepIndex}]`;
      if (!record(step) || !exactKeys(step, ['id', 'sourceTemplateId', 'titleSnapshot', 'focusModeIdSnapshot', 'targetWorkSessions']) ||
        !id(step.id) || stepIds.has(step.id) || candidateStepIds.has(step.id) || !(step.sourceTemplateId === null || id(step.sourceTemplateId)) ||
        typeof step.titleSnapshot !== 'string' || clampTaskTitle(step.titleSnapshot) !== step.titleSnapshot || !step.titleSnapshot ||
        !(step.focusModeIdSnapshot === null || id(step.focusModeIdSnapshot)) || !target(step.targetWorkSessions) ||
        titleKeys.has(getTaskTitleKey(step.titleSnapshot))) {
        fail('INVALID_PLAN_STEP', stepPath); return false;
      }
      const focusModeIdSnapshot = step.focusModeIdSnapshot !== null && !focusModeIds.has(step.focusModeIdSnapshot)
        ? (fail('DANGLING_FOCUS_MODE', `${stepPath}.focusModeIdSnapshot`), null)
        : step.focusModeIdSnapshot;
      titleKeys.add(getTaskTitleKey(step.titleSnapshot));
      candidateStepIds.add(step.id);
      normalizedSteps.push({ ...(step as unknown as FocusPlan['steps'][number]), focusModeIdSnapshot });
      return true;
    });
    if (!steps || totalSteps + value.steps.length > PLANNING_INTEGRITY_LIMITS.totalSteps) {
      if (totalSteps + value.steps.length > PLANNING_INTEGRITY_LIMITS.totalSteps) fail('TOTAL_STEP_LIMIT', path);
      return;
    }
    totalSteps += value.steps.length;
    candidateStepIds.forEach((stepId) => stepIds.add(stepId));
    planIds.add(value.id);
    plans.push({ ...(value as unknown as FocusPlan), steps: normalizedSteps });
  });

  const schedules: FocusPlanSchedule[] = [];
  const scheduleIds = new Set<string>();
  const scheduledPlans = new Set<string>();
  mutableCandidates(arrays.focusPlanSchedules).forEach(({ value, index }) => {
    const path = `focusPlanSchedules[${index}]`;
    if (!record(value) || !exactKeys(value, ['id', 'focusPlanId', 'generation', 'enabled', 'recurrence', 'lastHandledScheduledDate', 'createdAt', 'updatedAt']) ||
      !id(value.id) || !id(value.focusPlanId) || !planIds.has(value.focusPlanId) ||
      !Number.isSafeInteger(value.generation) || Number(value.generation) < 1 || typeof value.enabled !== 'boolean' ||
      !timestamp(value.createdAt) || !timestamp(value.updatedAt) || value.updatedAt < value.createdAt) {
      fail('INVALID_SCHEDULE', path); return;
    }
    if (scheduleIds.has(value.id) || scheduledPlans.has(value.focusPlanId)) { fail('DUPLICATE_SCHEDULE', path); return; }
    let recurrence;
    try { recurrence = normalizeRecurrence(value.recurrence as never); } catch { fail('INVALID_RECURRENCE', `${path}.recurrence`); return; }
    if (!(value.lastHandledScheduledDate === null || (isValidLocalDateKey(value.lastHandledScheduledDate) && value.lastHandledScheduledDate >= recurrence.startsOn && isScheduledDate(recurrence, value.lastHandledScheduledDate)))) {
      fail('INVALID_SCHEDULE_STATE', path); return;
    }
    scheduleIds.add(value.id); scheduledPlans.add(value.focusPlanId);
    schedules.push({ ...(value as unknown as FocusPlanSchedule), recurrence });
  });

  const runs: FocusPlanRun[] = [];
  const runIds = new Set<string>();
  const requestIds = new Set<string>();
  const occurrenceKeys = new Set<string>();
  let totalItems = 0;
  runCandidates(arrays.focusPlanRuns).forEach(({ value, index }) => {
    const path = `focusPlanRuns[${index}]`;
    if (!record(value) || !exactKeys(value, ['id', 'requestId', 'planId', 'planTitleSnapshot', 'occurrenceKey', 'scheduledForLocalDate', 'startedLocalDate', 'startedAt', 'items']) ||
      !id(value.id) || !id(value.requestId) || !id(value.planId) ||
      typeof value.planTitleSnapshot !== 'string' || value.planTitleSnapshot.trim().replace(/\s+/g, ' ') !== value.planTitleSnapshot || !value.planTitleSnapshot || value.planTitleSnapshot.length > 80 ||
      !isValidLocalDateKey(value.startedLocalDate) || !timestamp(value.startedAt) || !denseArray(value.items) || !value.items.length || value.items.length > PLANNING_INTEGRITY_LIMITS.runItemsPerRun) {
      fail('INVALID_RUN', path); return;
    }
    if (runIds.has(value.id) || requestIds.has(value.requestId)) { fail('DUPLICATE_RUN_RECEIPT', path); return; }
    const manual = value.occurrenceKey === null && value.scheduledForLocalDate === null;
    const scheduled = typeof value.occurrenceKey === 'string' && isValidLocalDateKey(value.scheduledForLocalDate) && value.scheduledForLocalDate <= value.startedLocalDate;
    if (!manual && !scheduled) { fail('INVALID_RUN_OCCURRENCE', path); return; }
    if (scheduled) {
      const parts = (value.occurrenceKey as string).split(':');
      const date = parts.pop(); const generation = Number(parts.pop()); const scheduleId = parts.join(':');
      if (!id(scheduleId) || !Number.isSafeInteger(generation) || generation < 1 || date !== value.scheduledForLocalDate ||
        `${scheduleId}:${generation}:${date}` !== value.occurrenceKey) {
        fail('INVALID_RUN_OCCURRENCE', path); return;
      }
      if (occurrenceKeys.has(value.occurrenceKey as string)) { fail('DUPLICATE_OCCURRENCE_KEY', path); return; }
    }
    const taskIds = new Set<string>();
    const validItems = value.items.every((item, itemIndex) => {
      if (!record(item) || !exactKeys(item, ['taskId', 'materialization', 'titleSnapshot', 'focusModeIdSnapshot', 'targetWorkSessions']) ||
        !id(item.taskId) || taskIds.has(item.taskId) || (item.materialization !== 'created' && item.materialization !== 'reused') ||
        typeof item.titleSnapshot !== 'string' || clampTaskTitle(item.titleSnapshot) !== item.titleSnapshot || !item.titleSnapshot ||
        !(item.focusModeIdSnapshot === null || id(item.focusModeIdSnapshot)) || !target(item.targetWorkSessions)) {
        fail('INVALID_RUN_ITEM', `${path}.items[${itemIndex}]`); return false;
      }
      taskIds.add(item.taskId); return true;
    });
    if (!validItems || totalItems + value.items.length > PLANNING_INTEGRITY_LIMITS.totalRunItems) {
      if (totalItems + value.items.length > PLANNING_INTEGRITY_LIMITS.totalRunItems) fail('TOTAL_RUN_ITEM_LIMIT', path);
      return;
    }
    totalItems += value.items.length;
    if (scheduled) occurrenceKeys.add(value.occurrenceKey as string);
    runIds.add(value.id); requestIds.add(value.requestId);
    runs.push(value as unknown as FocusPlanRun);
  });

  const collections = {
    taskTemplates: templates.sort((a, b) => a.createdAt - b.createdAt || (a.id < b.id ? -1 : 1)),
    focusPlans: plans.sort((a, b) => a.createdAt - b.createdAt || (a.id < b.id ? -1 : 1)),
    focusPlanSchedules: schedules.sort((a, b) => a.createdAt - b.createdAt || (a.id < b.id ? -1 : 1)),
    focusPlanRuns: runs.sort((a, b) => a.startedAt - b.startedAt || (a.id < b.id ? -1 : 1))
  };
  const rawPlanningData = Object.fromEntries(KEYS.map((key) => [key, raw[key]])) as Partial<Record<PlanningStorageKey, unknown>>;
  return {
    collections,
    integrity: issues.length
      ? { status: 'blocked', reason: 'PLANNING_DATA_INTEGRITY', issues, rawPlanningData }
      : { status: 'ok' }
  };
};
