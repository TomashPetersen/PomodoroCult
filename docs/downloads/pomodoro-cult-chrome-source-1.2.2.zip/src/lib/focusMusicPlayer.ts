import { FOCUS_MUSIC_TRACKS } from './constants';
import type { Settings, TimerState } from './types';

const FOCUS_MUSIC_PLAY_TIMEOUT_MS = 2000;
const FOCUS_MUSIC_RECONCILE_WAIT_MS = FOCUS_MUSIC_PLAY_TIMEOUT_MS + 250;
const MAX_TIMEOUT_MS = 2_147_483_647;

interface FocusMusicPlaybackState {
  settings: Settings;
  timerState: TimerState;
}

export const getFocusMusicDeadline = (settings: Settings, timerState: TimerState): number | null => {
  const { currentMode, isRunning, isPaused, targetEndTime } = timerState;
  if (
    !settings.focusMusicEnabled ||
    currentMode !== 'work' ||
    !isRunning ||
    isPaused ||
    targetEndTime === null ||
    !Number.isFinite(targetEndTime) ||
    targetEndTime <= Date.now()
  ) return null;
  return targetEndTime;
};

export const createFocusMusicPlayer = (
  readPlaybackState: () => Promise<FocusMusicPlaybackState | null>
) => {
  const STREAM_CROSSFADE_SECONDS = 1.4;
  const STREAM_FADE_STEP_MS = 80;
  let focusMusicAudios: HTMLAudioElement[] = [];
  let focusMusicTrackId: Settings['focusMusicTrack'] | null = null;
  let focusMusicActiveAudioIndex = 0;
  let focusMusicScheduleId: number | null = null;
  let focusMusicFadeId: number | null = null;
  let focusMusicDeadlineId: number | null = null;
  let focusMusicVolume = 0.45;
  let focusMusicReconcileGeneration = 0;
  let focusMusicReconcileRequested = false;
  let focusMusicReconcileInFlight: Promise<void> | null = null;
  const focusMusicAudioOwners = new WeakMap<HTMLAudioElement, number>();

  const clampFocusMusicVolume = (volume: number): number => Math.min(1, Math.max(0, volume));

  const clearFocusMusicTimers = (): void => {
    if (focusMusicScheduleId !== null) {
      window.clearTimeout(focusMusicScheduleId);
      focusMusicScheduleId = null;
    }

    if (focusMusicFadeId !== null) {
      window.clearInterval(focusMusicFadeId);
      focusMusicFadeId = null;
    }
  };

  const clearFocusMusicDeadline = (): void => {
    if (focusMusicDeadlineId !== null) {
      window.clearTimeout(focusMusicDeadlineId);
      focusMusicDeadlineId = null;
    }
  };

  const pauseFocusMusic = (): void => {
    clearFocusMusicTimers();
    clearFocusMusicDeadline();
    focusMusicAudios.forEach((audio) => {
      audio.pause();
      audio.volume = clampFocusMusicVolume(focusMusicVolume);
    });
  };

  const stopAndResetFocusMusic = (): void => {
    pauseFocusMusic();
    focusMusicAudios.forEach((audio) => {
      audio.currentTime = 0;
    });
  };

  const disposeFocusMusicAudios = (): void => {
    pauseFocusMusic();
    focusMusicAudios.forEach((audio) => {
      audio.removeAttribute('src');
      audio.load();
      focusMusicAudioOwners.delete(audio);
    });
    focusMusicAudios = [];
    focusMusicActiveAudioIndex = 0;
    focusMusicTrackId = null;
  };

  const disposeFocusMusicAudio = (audio: HTMLAudioElement): void => {
    const index = focusMusicAudios.indexOf(audio);
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    focusMusicAudioOwners.delete(audio);

    if (index < 0) return;

    focusMusicAudios.splice(index, 1);
    if (focusMusicAudios.length === 0) {
      focusMusicActiveAudioIndex = 0;
    } else if (index < focusMusicActiveAudioIndex) {
      focusMusicActiveAudioIndex -= 1;
    } else if (focusMusicActiveAudioIndex >= focusMusicAudios.length) {
      focusMusicActiveAudioIndex = 0;
    }
  };

  const normalizeFocusMusicOverlap = (): void => {
    const playingIndexes = focusMusicAudios
      .map((audio, index) => ({ audio, index }))
      .filter(({ audio }) => !audio.paused);

    if (playingIndexes.length === 0) return;

    const active = playingIndexes.reduce((loudest, candidate) =>
      candidate.audio.volume > loudest.audio.volume ? candidate : loudest
    );

    focusMusicActiveAudioIndex = active.index;
    focusMusicAudioOwners.set(active.audio, focusMusicReconcileGeneration);
    focusMusicAudios.forEach((audio, index) => {
      if (index === active.index) {
        audio.volume = clampFocusMusicVolume(focusMusicVolume);
        return;
      }

      audio.pause();
      audio.currentTime = 0;
      audio.volume = clampFocusMusicVolume(focusMusicVolume);
    });
  };

  const invalidateFocusMusicPlayback = (stopImmediately: boolean): void => {
    focusMusicReconcileGeneration += 1;
    clearFocusMusicTimers();
    clearFocusMusicDeadline();

    if (stopImmediately) {
      stopAndResetFocusMusic();
    } else {
      normalizeFocusMusicOverlap();
    }
  };

  const ensureFocusMusicAudios = (settings: Settings): HTMLAudioElement[] => {
    const track =
      FOCUS_MUSIC_TRACKS.find((candidate) => candidate.id === settings.focusMusicTrack) ??
      FOCUS_MUSIC_TRACKS[0];

    focusMusicVolume = clampFocusMusicVolume(settings.focusMusicVolume);
    const audioUrl = chrome.runtime.getURL(track.src);
    const audioCount = track.id === 'stream' ? 2 : 1;
    const createAudio = (): HTMLAudioElement => {
      const audio = new Audio(audioUrl);
      audio.loop = track.id !== 'stream';
      audio.preload = 'auto';
      audio.volume = focusMusicVolume;
      return audio;
    };

    if (focusMusicTrackId !== track.id) {
      disposeFocusMusicAudios();
      focusMusicTrackId = track.id;
      focusMusicAudios = Array.from({ length: audioCount }, createAudio);
    } else {
      while (focusMusicAudios.length < audioCount) {
        focusMusicAudios.push(createAudio());
      }
      while (focusMusicAudios.length > audioCount) {
        const extraAudio = focusMusicAudios[focusMusicAudios.length - 1];
        disposeFocusMusicAudio(extraAudio);
      }
      focusMusicAudios.forEach((audio) => {
        audio.volume = focusMusicVolume;
      });
    }

    return focusMusicAudios;
  };

  type FocusMusicPlayResult = 'played' | 'failed' | 'stale' | 'timeout';

  const playFocusMusicAudio = async (
    audio: HTMLAudioElement,
    generation: number,
    context: string
  ): Promise<FocusMusicPlayResult> => {
    let timedOut = false;
    let timeoutId: number | null = null;
    let playPromise: Promise<void>;

    try {
      focusMusicAudioOwners.set(audio, generation);
      playPromise = audio.play();
    } catch (error) {
      console.warn(`Focus music ${context} failed:`, error);
      return 'failed';
    }

    void playPromise.then(() => {
      if (!focusMusicAudios.includes(audio)) {
        audio.pause();
        audio.currentTime = 0;
        return;
      }

      if (
        (timedOut || generation !== focusMusicReconcileGeneration) &&
        focusMusicAudioOwners.get(audio) === generation
      ) {
        audio.pause();
        audio.currentTime = 0;
      }
    }).catch(() => {
      // The awaited branch below records the playback failure once.
    });

    const result = await Promise.race<FocusMusicPlayResult>([
      playPromise.then(() => 'played' as const).catch((error) => {
        console.warn(`Focus music ${context} failed:`, error);
        return 'failed' as const;
      }),
      new Promise<FocusMusicPlayResult>((resolve) => {
        timeoutId = window.setTimeout(() => {
          timedOut = true;
          resolve('timeout');
        }, FOCUS_MUSIC_PLAY_TIMEOUT_MS);
      })
    ]);

    if (timeoutId !== null) {
      window.clearTimeout(timeoutId);
    }

    if (result === 'timeout') {
      console.warn(`Focus music ${context} timed out.`);
      if (
        focusMusicAudios.includes(audio) &&
        focusMusicAudioOwners.get(audio) === generation
      ) {
        disposeFocusMusicAudio(audio);
      }
      return result;
    }

    if (result === 'played' && generation !== focusMusicReconcileGeneration) {
      if (focusMusicAudioOwners.get(audio) === generation) {
        audio.pause();
        audio.currentTime = 0;
      }
      return 'stale';
    }

    return result;
  };

  const scheduleStreamCrossfade = (generation: number): void => {
    clearFocusMusicTimers();
    if (generation !== focusMusicReconcileGeneration) return;

    const activeAudio = focusMusicAudios[focusMusicActiveAudioIndex];
    if (!activeAudio || activeAudio.paused) return;

    const duration = Number.isFinite(activeAudio.duration) ? activeAudio.duration : 0;
    if (duration <= 0) {
      focusMusicScheduleId = window.setTimeout(() => {
        scheduleStreamCrossfade(generation);
      }, 350);
      return;
    }

    const delayMs = Math.max(
      250,
      (duration - activeAudio.currentTime - STREAM_CROSSFADE_SECONDS) * 1000
    );

    focusMusicScheduleId = window.setTimeout(() => {
      if (generation !== focusMusicReconcileGeneration) return;

      const nextIndex = focusMusicActiveAudioIndex === 0 ? 1 : 0;
      const current = focusMusicAudios[focusMusicActiveAudioIndex];
      const next = focusMusicAudios[nextIndex];
      if (!current || !next || current.paused) return;

      next.pause();
      next.currentTime = 0;
      next.volume = 0;

      void playFocusMusicAudio(next, generation, 'crossfade').then((playResult) => {
        if (playResult !== 'played' || generation !== focusMusicReconcileGeneration) {
          if (focusMusicAudioOwners.get(next) === generation) {
            next.pause();
            next.currentTime = 0;
          }
          return;
        }

        const startedAt = performance.now();
        const fadeId = window.setInterval(() => {
          if (generation !== focusMusicReconcileGeneration) {
            window.clearInterval(fadeId);
            if (focusMusicFadeId === fadeId) {
              focusMusicFadeId = null;
            }
            if (focusMusicAudioOwners.get(next) === generation) {
              next.pause();
              next.currentTime = 0;
            }
            return;
          }

          const progress = Math.min(
            1,
            (performance.now() - startedAt) / (STREAM_CROSSFADE_SECONDS * 1000)
          );
          current.volume = focusMusicVolume * (1 - progress);
          next.volume = focusMusicVolume * progress;

          if (progress < 1) return;
          if (focusMusicFadeId !== null) {
            window.clearInterval(focusMusicFadeId);
            focusMusicFadeId = null;
          }
          current.pause();
          current.currentTime = 0;
          current.volume = focusMusicVolume;
          focusMusicActiveAudioIndex = nextIndex;
          scheduleStreamCrossfade(generation);
        }, STREAM_FADE_STEP_MS);
        focusMusicFadeId = fadeId;
      });
    }, delayMs);
  };

  // Audio must end at the saved deadline even if the background timer wakes late.
  const scheduleFocusMusicDeadline = (targetEndTime: number, generation: number): void => {
    focusMusicDeadlineId = window.setTimeout(() => {
      if (generation !== focusMusicReconcileGeneration) return;
      focusMusicDeadlineId = null;

      if (Date.now() < targetEndTime) {
        scheduleFocusMusicDeadline(targetEndTime, generation);
        return;
      }

      invalidateFocusMusicPlayback(true);
    }, Math.min(targetEndTime - Date.now(), MAX_TIMEOUT_MS));
  };

  const syncFocusMusic = async (
    settings: Settings,
    timerState: TimerState,
    generation: number
  ): Promise<void> => {
    if (generation !== focusMusicReconcileGeneration) return;

    const targetEndTime = getFocusMusicDeadline(settings, timerState);
    if (targetEndTime === null) {
      pauseFocusMusic();
      return;
    }

    const audios = ensureFocusMusicAudios(settings);
    if (generation !== focusMusicReconcileGeneration) return;

    const activeAudio = audios[focusMusicActiveAudioIndex] ?? audios[0];
    if (!activeAudio) return;

    scheduleFocusMusicDeadline(targetEndTime, generation);

    if (!activeAudio.paused) {
      focusMusicAudioOwners.set(activeAudio, generation);
      activeAudio.volume = clampFocusMusicVolume(focusMusicVolume);
      if (settings.focusMusicTrack === 'stream') {
        scheduleStreamCrossfade(generation);
      }
      return;
    }

    const playResult = await playFocusMusicAudio(activeAudio, generation, 'playback');
    if (generation !== focusMusicReconcileGeneration) {
      return;
    }
    if (playResult !== 'played') {
      pauseFocusMusic();
      return;
    }

    if (settings.focusMusicTrack === 'stream') {
      scheduleStreamCrossfade(generation);
    }
  };

  const runFocusMusicReconcileWorker = async (): Promise<void> => {
    while (focusMusicReconcileRequested) {
      focusMusicReconcileRequested = false;
      const generation = focusMusicReconcileGeneration;

      try {
        const state = await readPlaybackState();

        if (generation !== focusMusicReconcileGeneration) {
          focusMusicReconcileRequested = true;
          continue;
        }

        if (state) await syncFocusMusic(state.settings, state.timerState, generation);
      } catch (error) {
        console.warn('Focus music reconciliation failed:', error);
        if (generation === focusMusicReconcileGeneration) {
          pauseFocusMusic();
        }
      }
    }
  };

  const ensureFocusMusicReconcileWorker = (): Promise<void> => {
    if (!focusMusicReconcileInFlight) {
      focusMusicReconcileInFlight = runFocusMusicReconcileWorker().finally(() => {
        focusMusicReconcileInFlight = null;
        if (focusMusicReconcileRequested) {
          void ensureFocusMusicReconcileWorker();
        }
      });
    }

    return focusMusicReconcileInFlight;
  };

  const requestFocusMusicReconcile = (stopImmediately = false): Promise<void> => {
    invalidateFocusMusicPlayback(stopImmediately);
    focusMusicReconcileRequested = true;
    return ensureFocusMusicReconcileWorker();
  };

  const requestFocusMusicReconcileBounded = async (stopImmediately = false): Promise<void> => {
    const reconcile = requestFocusMusicReconcile(stopImmediately);
    let timeoutId: number | null = null;

    try {
      await Promise.race([
        reconcile,
        new Promise<void>((resolve) => {
          timeoutId = window.setTimeout(resolve, FOCUS_MUSIC_RECONCILE_WAIT_MS);
        })
      ]);
    } finally {
      if (timeoutId !== null) {
        window.clearTimeout(timeoutId);
      }
    }
  };

  return {
    invalidateFocusMusicPlayback,
    requestFocusMusicReconcile,
    requestFocusMusicReconcileBounded
  };
};
