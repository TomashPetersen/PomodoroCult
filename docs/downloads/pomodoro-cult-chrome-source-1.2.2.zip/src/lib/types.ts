export type TimerMode = 'work' | 'shortBreak' | 'longBreak';
export type TimerLifecycleState = 'idle' | 'running' | 'paused' | 'ready';
export type ThemeMode = 'light' | 'dark';
export type AppScreen = 'timer' | 'tasks' | 'stats' | 'plans';
export type StatsView = 'list' | 'chart' | 'review';
export type StatsPeriod = '1d' | '7d' | '30d' | 'custom';
export type Locale = 'ru' | 'en';
export type LanguagePreference = 'auto' | Locale;
export type FocusMusicTrack = 'stream' | 'birds' | 'clock';
export type PlanTier = 'free' | 'pro';
export type FocusNotificationMode = 'normal' | 'soft' | 'sound-only';

export const CURRENT_STORAGE_VERSION = 5;

export type ProFeature = 'focusPlans' | 'taskTemplates' | 'recurringPlans';
export type EntitlementStatus = 'none' | 'valid' | 'grace' | 'expired' | 'revoked';

export interface AccessContext {
  tier: PlanTier;
  entitlementStatus: EntitlementStatus;
}

export interface TaskTemplate {
  id: string;
  title: string;
  focusModeId: string | null;
  targetWorkSessions: number;
  createdAt: number;
  updatedAt: number;
}

export interface FocusPlanStep {
  id: string;
  sourceTemplateId: string | null;
  titleSnapshot: string;
  focusModeIdSnapshot: string | null;
  targetWorkSessions: number;
}

export interface FocusPlan {
  id: string;
  title: string;
  steps: FocusPlanStep[];
  createdAt: number;
  updatedAt: number;
}

export type FocusPlanRecurrence =
  | { type: 'daily'; startsOn: string }
  | { type: 'weekdays'; startsOn: string }
  | { type: 'selectedWeekdays'; startsOn: string; weekdays: number[] };

export interface FocusPlanSchedule {
  id: string;
  focusPlanId: string;
  generation: number;
  enabled: boolean;
  recurrence: FocusPlanRecurrence;
  lastHandledScheduledDate: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface FocusPlanRunItem {
  taskId: string;
  materialization: 'created' | 'reused';
  titleSnapshot: string;
  focusModeIdSnapshot: string | null;
  targetWorkSessions: number;
}

export interface FocusPlanRun {
  id: string;
  requestId: string;
  planId: string;
  planTitleSnapshot: string;
  occurrenceKey: string | null;
  scheduledForLocalDate: string | null;
  startedLocalDate: string;
  startedAt: number;
  items: FocusPlanRunItem[];
}

export interface FocusReviewGoals {
  dailySessions: number | null;
  weeklySessions: number | null;
}

export interface Settings {
  workTime: number;
  shortBreak: number;
  longBreak: number;
  longBreakInterval: number;
  languagePreference: LanguagePreference;
  autoStartBreaks: boolean;
  autoStartWork: boolean;
  focusMusicEnabled: boolean;
  focusMusicVolume: number;
  focusMusicTrack: FocusMusicTrack;
}

export type FocusMusicControlCommand =
  | { type: 'toggle' }
  | { type: 'set-enabled'; enabled: boolean }
  | { type: 'set-track'; track: FocusMusicTrack }
  | { type: 'set-volume'; volume: number };

export interface Task {
  id: string;
  title: string;
  createdAt?: number;
  usageCount: number;
  lastUsed: number;
  system?: boolean;
  archived?: boolean;
  archivedAt?: number | null;
  focusModeId?: string | null;
}

export interface TimerState {
  isRunning: boolean;
  isPaused: boolean;
  cycleStarted: boolean;
  revision: number;
  currentMode: TimerMode;
  remainingSeconds: number;
  targetEndTime: number | null;
  cycleId: string | null;
  cycleStartedAt: number | null;
  cycleStartedLocalDate: string | null;
  cycleLocalStartMinute: number | null;
  activeCycleSnapshot: FocusModeSnapshot | null;
  activeTaskId: string | null;
  completedSessions: number;
}

export interface FocusModeSnapshot {
  appliedFocusModeId: string | null;
  workMinutes: number;
  shortBreakMinutes: number;
  longRestMinutes: number;
  cyclesBeforeRest: number;
  autoStartBreaks: boolean;
  autoStartWork: boolean;
  soundTrack: FocusMusicTrack | 'none';
  soundVolume: number;
  notificationMode: FocusNotificationMode;
}

export interface FocusModeEditableValues {
  title: string;
  workMinutes: number;
  shortBreakMinutes: number;
  longRestMinutes: number;
  cyclesBeforeRest: number;
  autoStartBreaks: boolean;
  autoStartWork: boolean;
  soundTrack: FocusMusicTrack | 'none';
  soundVolume: number;
}

export interface FocusMode {
  id: string;
  title: string;
  workMinutes: number;
  shortBreakMinutes: number;
  longRestMinutes: number;
  cyclesBeforeRest: number;
  autoStartBreaks: boolean;
  autoStartWork: boolean;
  soundTrack: FocusMusicTrack | 'none';
  soundVolume: number;
  sessionGoal: number | null;
  notificationMode: FocusNotificationMode;
  accent: string | null;
  builtIn: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface SessionEvent {
  id: string;
  taskId: string;
  taskTitleSnapshot: string;
  focusModeId: string | null;
  startedAt: number;
  completedAt: number;
  durationSeconds: number;
  completedLocalDate?: string;
  startedLocalDate?: string;
  localStartMinute?: number;
  timeZoneOffsetMinutes?: number;
}

export interface TaskStatistics {
  taskId: string;
  title: string;
  sessions: number;
  seconds: number;
  lastSessionAt: number;
}

export interface DailyStatistics {
  date: string;
  sessions: number;
  seconds: number;
  tasks: Record<string, TaskStatistics>;
}

export type Statistics = Record<string, DailyStatistics>;

export interface StoredData {
  storageVersion: number;
  settings: Settings;
  tasks: Task[];
  timerState: TimerState;
  statistics: Statistics;
  focusModes: FocusMode[];
  selectedFocusModeId: string | null;
  manualSettings: Settings;
  sessionEvents: SessionEvent[];
  focusReviewGoals: FocusReviewGoals;
  sessionEventLogStartedAt: number;
  theme: ThemeMode;
  taskTemplates: TaskTemplate[];
  focusPlans: FocusPlan[];
  focusPlanSchedules: FocusPlanSchedule[];
  focusPlanRuns: FocusPlanRun[];
}

export interface MigrationBackup {
  createdAt: number;
  fromVersion: number;
  toVersion: number;
  data: unknown;
}

export interface PersistedStorage extends StoredData {
  migrationBackup?: MigrationBackup | null;
  storageV5MigrationBackup?: MigrationBackup | null;
}

export type PlanningStorageKey =
  | 'taskTemplates'
  | 'focusPlans'
  | 'focusPlanSchedules'
  | 'focusPlanRuns';

export type StorageIntegrityState =
  | { status: 'ok' }
  | {
      status: 'warning';
      reason: 'V5_MIGRATION_BACKUP_WARNING';
      issues: Array<{ code: string; path: string }>;
      rawPlanningData: Partial<Record<PlanningStorageKey, unknown>>;
      rawStorage: Record<string, unknown>;
    }
  | {
      status: 'blocked';
      reason:
        | 'PLANNING_DATA_INTEGRITY'
        | 'VERSION_SCHEMA_CONFLICT'
        | 'FUTURE_STORAGE_VERSION'
        | 'V5_MIGRATION_BACKUP_INVALID';
      issues: Array<{ code: string; path: string }>;
      rawPlanningData: Partial<Record<PlanningStorageKey, unknown>>;
      rawStorage?: Record<string, unknown>;
    };

export interface StoredDataReadResult {
  data: StoredData;
  storageIntegrity: StorageIntegrityState;
}

export interface ExportedDataDocument {
  app: 'Pomodoro Cult';
  exportedAt: string;
  storageVersion: number;
  data: StoredData;
}

export interface RecoveryExportDocument {
  app: 'Pomodoro Cult storage recovery';
  exportedAt: string;
  importable: false;
  reason: string;
  issues: Array<{ code: string; path: string }>;
  rawPlanningData: Partial<Record<PlanningStorageKey, unknown>>;
  rawStorage?: Record<string, unknown>;
}

export type RuntimeMessage =
  | { type: 'POPUP_START_TIMER'; payload: { mode: TimerMode; startedAt: number } }
  | { type: 'POPUP_PAUSE_TIMER' }
  | { type: 'POPUP_RESET_TIMER' }
  | { type: 'POPUP_SKIP_SHORT_BREAK' }
  | { type: 'POPUP_SKIP_BREAK' }
  | { type: 'POPUP_ENSURE_READY' }
  | { type: 'DELETE_TASK_STATISTICS'; payload: { taskId: string } }
  | { type: 'SELECT_FOCUS_MODE'; payload: { focusModeId: string | null } }
  | { type: 'CREATE_FOCUS_MODE'; payload: { values: FocusModeEditableValues } }
  | {
      type: 'UPDATE_FOCUS_MODE';
      payload: { focusModeId: string; values: FocusModeEditableValues };
    }
  | { type: 'DELETE_FOCUS_MODE'; payload: { focusModeId: string } }
  | {
      type: 'SET_TASK_FOCUS_MODE';
      payload: { taskId: string; focusModeId: string | null };
    }
  | {
      type: 'SAVE_MANUAL_SETTINGS';
      payload: { settings: Settings; changedKeys?: Array<keyof Settings> };
    }
  | { type: 'SAVE_FOCUS_MUSIC_SETTINGS'; payload: FocusMusicControlCommand }
  | { type: 'SAVE_FOCUS_REVIEW_GOALS'; payload: FocusReviewGoals }
  | { type: 'IMPORT_USER_DATA'; payload: { raw: string } }
  | { type: 'SELECT_TASK'; payload: { taskId: string | null } }
  | { type: 'ADD_TASK'; payload: { title: string; select: boolean } }
  | { type: 'UPDATE_TASK'; payload: { taskId: string; title: string } }
  | { type: 'DELETE_TASK'; payload: { taskId: string } }
  | { type: 'ARCHIVE_TASK'; payload: { taskId: string } }
  | { type: 'RESTORE_TASK'; payload: { taskId: string } }
  | { type: 'GET_ACCESS_CONTEXT' }
  | { type: 'ACCESS_CONTEXT_CHANGED'; payload: { accessContext: AccessContext } }
  | { type: 'GET_PLANNING_STATE' }
  | { type: 'CREATE_TASK_TEMPLATE'; payload: { title: string; focusModeId: string | null; targetWorkSessions: number } }
  | { type: 'UPDATE_TASK_TEMPLATE'; payload: { templateId: string; title: string; focusModeId: string | null; targetWorkSessions: number } }
  | { type: 'DELETE_TASK_TEMPLATE'; payload: { templateId: string } }
  | { type: 'CREATE_FOCUS_PLAN'; payload: { title: string; steps: FocusPlanStep[] } }
  | { type: 'UPDATE_FOCUS_PLAN'; payload: { planId: string; title: string; steps: FocusPlanStep[] } }
  | { type: 'DELETE_FOCUS_PLAN'; payload: { planId: string } }
  | { type: 'CREATE_FOCUS_PLAN_SCHEDULE'; payload: { planId: string; recurrence: FocusPlanRecurrence } }
  | { type: 'UPDATE_FOCUS_PLAN_SCHEDULE'; payload: { scheduleId: string; recurrence: FocusPlanRecurrence } }
  | { type: 'SET_FOCUS_PLAN_SCHEDULE_ENABLED'; payload: { scheduleId: string; enabled: boolean } }
  | { type: 'DELETE_FOCUS_PLAN_SCHEDULE'; payload: { scheduleId: string } }
  | { type: 'START_FOCUS_PLAN'; payload: { planId: string; requestId: string; occurrenceToken: string | null } }
  | { type: 'SKIP_FOCUS_PLAN_OCCURRENCE'; payload: { planId: string; scheduleId: string; occurrenceToken: string } }
  | {
      type: 'OPEN_APP_WINDOW';
      payload?: { screen?: AppScreen; statsView?: StatsView };
    }
  | { type: 'APP_WINDOW_NAVIGATE'; payload: { screen?: AppScreen; statsView?: StatsView } }
  | { type: 'APP_WINDOW_READY'; payload: { windowId: number } }
  | { type: 'TOGGLE_APP_WINDOW_MAXIMIZED' }
  | { type: 'APP_WINDOW_CLOSED' }
  | { type: 'OFFSCREEN_SYNC_FOCUS_MUSIC'; payload: { settings: Settings; timerState: TimerState } }
  | { type: 'OFFSCREEN_PLAY_COMPLETION_CHIME' };

export const DEFAULT_SETTINGS: Settings = {
  workTime: 25,
  shortBreak: 5,
  longBreak: 15,
  longBreakInterval: 5,
  languagePreference: 'auto',
  autoStartBreaks: false,
  autoStartWork: false,
  focusMusicEnabled: false,
  focusMusicVolume: 0.45,
  focusMusicTrack: 'stream'
};

export const DEFAULT_FOCUS_REVIEW_GOALS: FocusReviewGoals = {
  dailySessions: null,
  weeklySessions: null
};

export const STORAGE_KEYS = {
  storageVersion: 'storageVersion',
  settings: 'settings',
  tasks: 'tasks',
  timerState: 'timerState',
  statistics: 'statistics',
  focusModes: 'focusModes',
  selectedFocusModeId: 'selectedFocusModeId',
  manualSettings: 'manualSettings',
  sessionEvents: 'sessionEvents',
  focusReviewGoals: 'focusReviewGoals',
  sessionEventLogStartedAt: 'sessionEventLogStartedAt',
  theme: 'theme',
  migrationBackup: 'migrationBackup',
  storageV5MigrationBackup: 'storageV5MigrationBackup',
  taskTemplates: 'taskTemplates',
  focusPlans: 'focusPlans',
  focusPlanSchedules: 'focusPlanSchedules',
  focusPlanRuns: 'focusPlanRuns'
} as const;
