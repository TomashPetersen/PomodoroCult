import { AccessContext } from './types';

export interface AccessContextRefreshController {
  refresh(apply: (context: AccessContext) => void): Promise<AccessContext | null>;
}

export const createAccessContextRefreshController = (
  request: () => Promise<AccessContext | null>
): AccessContextRefreshController => {
  let generation = 0;

  return {
    refresh: async (apply) => {
      const requestGeneration = ++generation;
      const context = await request();
      if (!context || requestGeneration !== generation) return null;
      apply(context);
      return context;
    }
  };
};
