import { AccessContext } from '../lib/types';

export const DEV_ACCESS_SIMULATOR_COMMAND = 'PHASE4_DEV_ACCESS_SIMULATOR_SET_V1';
export const DEV_ACCESS_SIMULATOR_MARKER = 'PHASE4_DEV_ACCESS_SIMULATOR_MARKER_V1';

export interface DevelopmentAccessSimulatorMessage {
  type: typeof DEV_ACCESS_SIMULATOR_COMMAND;
  payload: { accessContext: AccessContext };
}
