import { DEFAULT_ACCESS_CONTEXT } from '../lib/access';
import {
  RuntimeAccessDiagnosticsBridge,
  RuntimeAccessDiagnosticsDependencies
} from '../lib/accessDiagnostics';
import { AccessContext } from '../lib/types';
import {
  DEV_ACCESS_SIMULATOR_COMMAND,
  DevelopmentAccessSimulatorMessage
} from './accessSimulatorProtocol';

const isAccessContext = (value: unknown): value is AccessContext => {
  if (!value || typeof value !== 'object') return false;
  const context = value as Partial<AccessContext>;
  return (context.tier === 'free' || context.tier === 'pro') &&
    (context.entitlementStatus === 'none' || context.entitlementStatus === 'valid' ||
      context.entitlementStatus === 'grace' || context.entitlementStatus === 'expired' ||
      context.entitlementStatus === 'revoked');
};

export const registerRuntimeAccessDiagnostics = (
  dependencies: RuntimeAccessDiagnosticsDependencies
): RuntimeAccessDiagnosticsBridge => {
  let accessContext: AccessContext = { ...DEFAULT_ACCESS_CONTEXT };

  return {
    getAccessContext: () => ({ ...accessContext }),
    handleMessage: async (message) => {
      if (!message || typeof message !== 'object' ||
        (message as Partial<DevelopmentAccessSimulatorMessage>).type !== DEV_ACCESS_SIMULATOR_COMMAND) {
        return null;
      }
      const next = (message as DevelopmentAccessSimulatorMessage).payload?.accessContext;
      if (!isAccessContext(next)) return { ok: false, error: 'INVALID_DEVELOPMENT_ACCESS_CONTEXT' };
      return dependencies.enqueue(async () => {
        accessContext = { ...next };
        await dependencies.broadcast({
          type: 'ACCESS_CONTEXT_CHANGED',
          payload: { accessContext: { ...accessContext } }
        });
        return { ok: true, accessContext: { ...accessContext } };
      });
    }
  };
};
