import { ChangeEvent } from 'react';
import { DEV_ACCESS_SIMULATOR_COMMAND, DEV_ACCESS_SIMULATOR_MARKER } from './accessSimulatorProtocol';
import { AccessContext } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

const choices: Array<{ value: string; label: string; context: AccessContext }> = [
  { value: 'free:none', label: 'Free', context: { tier: 'free', entitlementStatus: 'none' } },
  { value: 'pro:valid', label: 'Pro valid', context: { tier: 'pro', entitlementStatus: 'valid' } },
  { value: 'pro:grace', label: 'Pro grace', context: { tier: 'pro', entitlementStatus: 'grace' } },
  { value: 'pro:none', label: 'Pro none', context: { tier: 'pro', entitlementStatus: 'none' } },
  { value: 'pro:expired', label: 'Pro expired', context: { tier: 'pro', entitlementStatus: 'expired' } },
  { value: 'pro:revoked', label: 'Pro revoked', context: { tier: 'pro', entitlementStatus: 'revoked' } }
];

export default function RuntimeAccessDiagnosticsPanel() {
  const accessContext = useAppStore((state) => state.accessContext);
  const value = `${accessContext.tier}:${accessContext.entitlementStatus}`;

  const changeAccess = async (event: ChangeEvent<HTMLSelectElement>) => {
    const choice = choices.find((item) => item.value === event.target.value);
    if (!choice) return;
    await chrome.runtime.sendMessage({
      type: DEV_ACCESS_SIMULATOR_COMMAND,
      payload: { accessContext: choice.context }
    });
  };

  return (
    <aside
      data-development-marker={DEV_ACCESS_SIMULATOR_MARKER}
      className="absolute bottom-3 right-4 z-50 flex items-center gap-2 rounded-xl border border-dashed border-fuchsia-400 bg-white/95 px-3 py-2 text-xs shadow-lg dark:bg-zinc-900/95"
    >
      <label htmlFor="development-access-simulator" className="font-semibold text-fuchsia-700 dark:text-fuchsia-300">
        Development access simulator
      </label>
      <select
        id="development-access-simulator"
        value={value}
        onChange={(event) => void changeAccess(event)}
        className="rounded border border-zinc-300 bg-white px-2 py-1 text-zinc-900 dark:border-zinc-600 dark:bg-zinc-800 dark:text-white"
      >
        {choices.map((choice) => <option key={choice.value} value={choice.value}>{choice.label}</option>)}
      </select>
      <span className="text-zinc-500 dark:text-zinc-400">Resets when the extension runtime restarts.</span>
    </aside>
  );
}
