import { ArrowUpRight, HeartHandshake } from 'lucide-react';
import { DONATION_URL } from '../lib/constants';
import { t } from '../lib/i18n';
import { Locale } from '../lib/types';

export const DonationLink = ({ locale }: { locale: Locale }) => {
  if (!DONATION_URL) {
    return null;
  }

  return (
    <a
      href={DONATION_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t(locale, 'donationLinkLabel')}
      className="inline-flex h-11 w-fit shrink-0 items-center gap-2 rounded-xl border border-amber-400 bg-gradient-to-br from-amber-200 to-amber-400 px-2.5 text-amber-950 shadow-sm transition hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700 focus-visible:ring-offset-2 motion-reduce:transition-none dark:focus-visible:ring-amber-300 dark:focus-visible:ring-offset-[#0d1117]"
    >
      <HeartHandshake className="h-4 w-4 shrink-0" aria-hidden="true" />
      <span className="whitespace-nowrap">
        <span className="block text-xs font-bold leading-4">{t(locale, 'donate')}</span>
        <span className="flex items-center gap-0.5 text-[10px] font-semibold leading-3">
          Boosty <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
        </span>
      </span>
    </a>
  );
};
