import { BarChart3, ListTodo, Timer } from 'lucide-react';
import { DONATION_URL } from '../lib/constants';
import { t } from '../lib/i18n';
import { cn } from '../lib/ui';
import { AppScreen } from '../lib/types';
import { useAppStore } from '../store/useAppStore';
import { ActionIconButton } from './ActionIconButton';
import { AppVersionBadge } from './AppVersionBadge';
import { DonationLink } from './DonationLink';

const items: Array<{ screen: AppScreen; icon: typeof Timer; labelKey: 'screenTimer' | 'screenTasks' | 'screenStats' }> = [
  { screen: 'timer', icon: Timer, labelKey: 'screenTimer' },
  { screen: 'tasks', icon: ListTodo, labelKey: 'screenTasks' },
  { screen: 'stats', icon: BarChart3, labelKey: 'screenStats' }
];

export const FooterNav = () => {
  const locale = useAppStore((state) => state.locale);
  const selectedScreen = useAppStore((state) => state.selectedScreen);
  const setScreen = useAppStore((state) => state.setScreen);

  return (
    <footer className={cn(
      'relative grid h-16 shrink-0 border-t border-zinc-200 bg-[#f6f8fa]/96 dark:border-zinc-800 dark:bg-[#0d1117]/96',
      DONATION_URL ? 'grid-cols-[repeat(3,minmax(44px,1fr))_auto] gap-1 px-3 pb-3 pt-1' : 'grid-cols-3 px-6 py-2'
    )}>
      {items.map((item) => {
        const Icon = item.icon;
        const active = selectedScreen === item.screen;
        const label = t(locale, item.labelKey);

        return (
          <ActionIconButton
            key={item.screen}
            type="button"
            onClick={() => setScreen(item.screen)}
            label={label}
            aria-current={active ? 'page' : undefined}
            tooltipAlign="center"
            className={cn(
              'mx-auto grid h-11 w-11 place-items-center rounded-xl transition',
              active
                ? 'bg-[#24292f] text-[#f6f8fa] dark:bg-[#f0f3f6] dark:text-[#161b22]'
                : 'text-zinc-500 hover:bg-[#eef2f6] hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-[#21262d] dark:hover:text-[#f0f3f6]'
            )}
          >
            <Icon className="h-5 w-5" />
          </ActionIconButton>
        );
      })}
      <DonationLink locale={locale} />
      <AppVersionBadge className={DONATION_URL ? 'absolute bottom-0 right-3 leading-none' : 'absolute bottom-1 right-2'} />
    </footer>
  );
};
