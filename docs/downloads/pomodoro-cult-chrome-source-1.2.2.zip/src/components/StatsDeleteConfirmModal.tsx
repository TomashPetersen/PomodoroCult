import { AlertTriangle } from 'lucide-react';
import { getTaskTitle, t } from '../lib/i18n';
import { useAppStore } from '../store/useAppStore';
import { useModalFocus } from '../lib/useModalFocus';

export const StatsDeleteConfirmModal = () => {
  const locale = useAppStore((state) => state.locale);
  const tasks = useAppStore((state) => state.tasks);
  const statsDeleteConfirmTaskId = useAppStore((state) => state.statsDeleteConfirmTaskId);
  const closeStatsDeleteConfirm = useAppStore((state) => state.closeStatsDeleteConfirm);
  const confirmStatsDelete = useAppStore((state) => state.confirmStatsDelete);
  const dialogRef = useModalFocus(Boolean(statsDeleteConfirmTaskId), closeStatsDeleteConfirm);

  if (!statsDeleteConfirmTaskId) return null;

  const task = tasks.find((item) => item.id === statsDeleteConfirmTaskId);
  const title = getTaskTitle(locale, statsDeleteConfirmTaskId, task?.title ?? '');

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-zinc-950/55 p-4 backdrop-blur-sm">
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="delete-stats-title" tabIndex={-1} className="w-full max-w-[24rem] rounded-2xl border border-zinc-200 bg-[#fcfcfb] p-4 shadow-soft dark:border-zinc-800 dark:bg-[#161b22]">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-rose-100 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
            <AlertTriangle className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <h2 id="delete-stats-title" className="text-base font-semibold text-zinc-950 dark:text-white">
              {t(locale, 'confirmDeleteStats')}
            </h2>
            <p className="mt-1 text-sm leading-5 text-zinc-600 dark:text-zinc-300">
              {t(locale, 'deleteStatsDescription', { title })}
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <button
            type="button"
            onClick={closeStatsDeleteConfirm}
            className="h-10 rounded-xl border border-zinc-200 text-sm font-medium text-zinc-700 transition hover:bg-[#eef2f6] hover:text-zinc-950 dark:border-zinc-800 dark:text-zinc-200 dark:hover:bg-[#21262d] dark:hover:text-[#f0f3f6]"
          >
            {t(locale, 'cancel')}
          </button>
          <button
            type="button"
            onClick={() => void confirmStatsDelete()}
            className="h-10 rounded-xl bg-rose-600 px-4 text-sm font-semibold text-white transition hover:bg-rose-500"
          >
            {t(locale, 'deleteForever')}
          </button>
        </div>
      </div>
    </div>
  );
};
