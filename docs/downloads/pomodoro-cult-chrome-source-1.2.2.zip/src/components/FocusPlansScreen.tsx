import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  CalendarClock,
  CheckCircle2,
  Clock3,
  Layers3,
  LockKeyhole,
  Maximize2,
  Minimize2,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  SkipForward,
  Trash2,
  X
} from 'lucide-react';
import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { canUseFeature } from '../lib/access';
import { TASK_TITLE_MAX_LENGTH } from '../lib/constants';
import {
  canSelectFocusPlan,
  isFocusPlanEditorActive,
  isFocusPlanEditSelectionValid
} from '../lib/focusPlanEditor';
import { t } from '../lib/i18n';
import { getLocalDateKey, getTaskTitleKey } from '../lib/storage';
import { cn } from '../lib/ui';
import { FocusPlanRecurrence, FocusPlanStep, TaskTemplate } from '../lib/types';
import { useAppStore } from '../store/useAppStore';
import { ActionIconButton } from './ActionIconButton';

interface FocusPlansScreenProps {
  maximized: boolean;
  onBack: () => void;
  onToggleMaximized: () => void;
}

const createDraftStep = (overrides: Partial<FocusPlanStep> = {}): FocusPlanStep => ({
  id: `draft-${Date.now()}-${Math.random().toString(16).slice(2)}`,
  sourceTemplateId: null,
  titleSnapshot: '',
  focusModeIdSnapshot: null,
  targetWorkSessions: 1,
  ...overrides
});

const createRequestId = (): string =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? `plan-request-${crypto.randomUUID()}`
    : `plan-request-${Date.now()}-${Math.random().toString(16).slice(2)}`;

const inputClass = 'h-9 w-full rounded-lg border border-zinc-200 bg-white px-2.5 text-sm text-zinc-950 outline-none focus-visible:border-rose-400 focus-visible:ring-2 focus-visible:ring-rose-200 disabled:cursor-not-allowed disabled:opacity-55 dark:border-zinc-700 dark:bg-[#0d1117] dark:text-zinc-100 dark:focus-visible:border-rose-500 dark:focus-visible:ring-rose-500/20';
const panelClass = 'flex min-h-0 flex-col rounded-2xl border border-zinc-200 bg-[#fcfcfb] shadow-sm dark:border-zinc-800 dark:bg-[#0b1016]';

export const FocusPlansScreen = ({ maximized, onBack, onToggleMaximized }: FocusPlansScreenProps) => {
  const locale = useAppStore((state) => state.locale);
  const accessContext = useAppStore((state) => state.accessContext);
  const focusModes = useAppStore((state) => state.focusModes);
  const taskTemplates = useAppStore((state) => state.taskTemplates);
  const focusPlans = useAppStore((state) => state.focusPlans);
  const schedules = useAppStore((state) => state.focusPlanSchedules);
  const runs = useAppStore((state) => state.focusPlanRuns);
  const scheduleEvaluations = useAppStore((state) => state.scheduleEvaluations);
  const storageIntegrity = useAppStore((state) => state.storageIntegrity);
  const planningBusy = useAppStore((state) => state.planningBusy);
  const planningError = useAppStore((state) => state.planningError);
  const mutatePlanning = useAppStore((state) => state.mutatePlanning);
  const refreshPlanning = useAppStore((state) => state.refreshPlanning);
  const clearPlanningError = useAppStore((state) => state.clearPlanningError);
  const exportRecoveryData = useAppStore((state) => state.exportRecoveryData);

  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(focusPlans[0]?.id ?? null);
  const [editingTemplateId, setEditingTemplateId] = useState<string | null>(null);
  const [templateTitle, setTemplateTitle] = useState('');
  const [templateFocusModeId, setTemplateFocusModeId] = useState<string | null>(null);
  const [templateTarget, setTemplateTarget] = useState(1);
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [planTitle, setPlanTitle] = useState('');
  const [planSteps, setPlanSteps] = useState<FocusPlanStep[]>([]);
  const [templateToAdd, setTemplateToAdd] = useState('');
  const [recurrenceType, setRecurrenceType] = useState<FocusPlanRecurrence['type']>('daily');
  const [startsOn, setStartsOn] = useState(getLocalDateKey());
  const [selectedWeekdays, setSelectedWeekdays] = useState<number[]>([1]);
  const [readyPlanId, setReadyPlanId] = useState<string | null>(null);
  const templateTitleRef = useRef<HTMLInputElement>(null);
  const planTitleRef = useRef<HTMLInputElement>(null);
  const planEditorActive = isFocusPlanEditorActive(editingPlanId, planTitle, planSteps.length);
  const stepTitleKeys = planSteps.map((item) => getTaskTitleKey(item.titleSnapshot));
  const planStepError = stepTitleKeys.some((title) => !title)
    ? t(locale, 'plansStepTitleRequired')
    : new Set(stepTitleKeys).size !== stepTitleKeys.length
      ? t(locale, 'plansStepDuplicateError')
      : null;

  const resetTemplateEditor = () => {
    setEditingTemplateId(null);
    setTemplateTitle('');
    setTemplateFocusModeId(null);
    setTemplateTarget(1);
  };

  const resetPlanEditor = () => {
    setEditingPlanId(null);
    setPlanTitle('');
    setPlanSteps([]);
    setTemplateToAdd('');
  };

  const selectedPlan = focusPlans.find((plan) => plan.id === selectedPlanId) ?? null;
  const selectedSchedule = schedules.find((schedule) => schedule.focusPlanId === selectedPlanId) ?? null;
  const selectedEvaluation = selectedSchedule
    ? scheduleEvaluations.find((item) => item.scheduleId === selectedSchedule.id)?.evaluation ?? null
    : null;
  const selectedRuns = useMemo(
    () => runs.slice().reverse(),
    [runs]
  );
  const plansAllowed = canUseFeature('focusPlans', accessContext);
  const templatesAllowed = canUseFeature('taskTemplates', accessContext);
  const recurrenceAllowed = canUseFeature('recurringPlans', accessContext);
  const integrityBlocked = storageIntegrity.status === 'blocked';
  const locked = !plansAllowed || !templatesAllowed || !recurrenceAllowed;

  useEffect(() => {
    if (editingPlanId) {
      if (focusPlans.some((plan) => plan.id === editingPlanId)) {
        if (selectedPlanId !== editingPlanId) setSelectedPlanId(editingPlanId);
        return;
      }
      resetPlanEditor();
      window.setTimeout(() => planTitleRef.current?.focus(), 0);
    }
    if (selectedPlanId && focusPlans.some((plan) => plan.id === selectedPlanId)) return;
    setSelectedPlanId(focusPlans[0]?.id ?? null);
  }, [editingPlanId, focusPlans, selectedPlanId]);

  useEffect(() => {
    setReadyPlanId(null);
  }, [selectedPlanId]);

  useEffect(() => {
    if (!selectedSchedule) {
      setRecurrenceType('daily');
      setStartsOn(getLocalDateKey());
      setSelectedWeekdays([1]);
      return;
    }
    setRecurrenceType(selectedSchedule.recurrence.type);
    setStartsOn(selectedSchedule.recurrence.startsOn);
    setSelectedWeekdays(
      selectedSchedule.recurrence.type === 'selectedWeekdays'
        ? selectedSchedule.recurrence.weekdays
        : [1]
    );
  }, [selectedSchedule]);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      if (editingPlanId || planTitle || planSteps.length) {
        resetPlanEditor();
        planTitleRef.current?.focus();
      } else if (editingTemplateId || templateTitle) {
        resetTemplateEditor();
        templateTitleRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  });

  const errorText = useMemo(() => {
    if (!planningError) return null;
    if (planningError.includes('FEATURE_ACCESS_DENIED')) return t(locale, 'plansErrorAccess');
    if (planningError.includes('STALE_OCCURRENCE')) return t(locale, 'plansErrorStale');
    if (planningError.includes('CONFLICT') || planningError.includes('AMBIGUOUS')) return t(locale, 'plansErrorConflict');
    if (planningError.includes('INVALID') || planningError.includes('LIMIT') || planningError.includes('NOT_FOUND')) {
      return t(locale, 'plansErrorValidation');
    }
    return planningError;
  }, [locale, planningError]);

  const submitTemplate = async (event: FormEvent) => {
    event.preventDefault();
    if (!templateTitle.trim() || !templatesAllowed || integrityBlocked) return;
    const payload = {
      title: templateTitle,
      focusModeId: templateFocusModeId,
      targetWorkSessions: templateTarget
    };
    const ok = await mutatePlanning(editingTemplateId
      ? { type: 'UPDATE_TASK_TEMPLATE', payload: { templateId: editingTemplateId, ...payload } }
      : { type: 'CREATE_TASK_TEMPLATE', payload });
    if (ok) resetTemplateEditor();
  };

  const editTemplate = (template: TaskTemplate) => {
    clearPlanningError();
    setEditingTemplateId(template.id);
    setTemplateTitle(template.title);
    setTemplateFocusModeId(template.focusModeId);
    setTemplateTarget(template.targetWorkSessions);
    window.setTimeout(() => templateTitleRef.current?.focus(), 0);
  };

  const submitPlan = async (event: FormEvent) => {
    event.preventDefault();
    if (!isFocusPlanEditSelectionValid(editingPlanId, selectedPlanId)) return;
    const valid = planTitle.trim() && planSteps.length > 0 && !planStepError;
    if (!valid || !plansAllowed || integrityBlocked) return;
    const ok = await mutatePlanning(editingPlanId
      ? { type: 'UPDATE_FOCUS_PLAN', payload: { planId: editingPlanId, title: planTitle, steps: planSteps } }
      : { type: 'CREATE_FOCUS_PLAN', payload: { title: planTitle, steps: planSteps } });
    if (ok) resetPlanEditor();
  };

  const editPlan = () => {
    if (!selectedPlan) return;
    clearPlanningError();
    setSelectedPlanId(selectedPlan.id);
    setEditingPlanId(selectedPlan.id);
    setPlanTitle(selectedPlan.title);
    setPlanSteps(selectedPlan.steps.map((item) => ({ ...item })));
    window.setTimeout(() => planTitleRef.current?.focus(), 0);
  };

  const addTemplateStep = () => {
    const template = taskTemplates.find((item) => item.id === templateToAdd);
    if (!template) return;
    setPlanSteps((items) => [...items, createDraftStep({
      sourceTemplateId: template.id,
      titleSnapshot: template.title,
      focusModeIdSnapshot: template.focusModeId,
      targetWorkSessions: template.targetWorkSessions
    })]);
    setTemplateToAdd('');
  };

  const saveSchedule = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedPlan || !recurrenceAllowed || integrityBlocked || !startsOn) return;
    const recurrence: FocusPlanRecurrence = recurrenceType === 'selectedWeekdays'
      ? { type: recurrenceType, startsOn, weekdays: selectedWeekdays }
      : { type: recurrenceType, startsOn };
    await mutatePlanning(selectedSchedule
      ? { type: 'UPDATE_FOCUS_PLAN_SCHEDULE', payload: { scheduleId: selectedSchedule.id, recurrence } }
      : { type: 'CREATE_FOCUS_PLAN_SCHEDULE', payload: { planId: selectedPlan.id, recurrence } });
  };

  const runPlan = async () => {
    if (!selectedPlan) return;
    const occurrenceToken = selectedSchedule?.enabled
      ? selectedEvaluation?.actionableOccurrenceToken ?? null
      : null;
    if (selectedSchedule?.enabled && !occurrenceToken) return;
    setReadyPlanId(null);
    const ok = await mutatePlanning({
      type: 'START_FOCUS_PLAN',
      payload: { planId: selectedPlan.id, requestId: createRequestId(), occurrenceToken }
    });
    if (ok) setReadyPlanId(selectedPlan.id);
  };

  const statusLabel = selectedEvaluation
    ? t(locale, selectedEvaluation.status === 'due'
      ? 'plansDue'
      : selectedEvaluation.status === 'missed'
        ? 'plansMissed'
        : selectedEvaluation.status === 'exhausted'
          ? 'plansExhausted'
          : 'plansUpcoming')
    : null;
  const weekdayLabels = locale === 'ru'
    ? ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const getFocusModeLabel = (focusModeId: string | null): string =>
    focusModeId
      ? focusModes.find((mode) => mode.id === focusModeId)?.title ?? focusModeId
      : t(locale, 'plansNoFocusMode');

  return (
    <main className="flex h-full w-full flex-col gap-3 overflow-hidden p-4">
      <header className="flex min-h-12 items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <ActionIconButton
            type="button"
            onClick={onBack}
            label={locale === 'ru' ? 'Назад' : 'Back'}
            tooltipSide="bottom"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-zinc-200 bg-[#fcfcfb] text-zinc-600 shadow-sm hover:bg-zinc-100 dark:border-zinc-700 dark:bg-[#161b22] dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            <ArrowLeft className="h-4 w-4" />
          </ActionIconButton>
          <div className="min-w-0">
            <h1 className="truncate text-xl font-semibold text-zinc-950 dark:text-white">{t(locale, 'plansTitle')}</h1>
            <p className="truncate text-sm text-zinc-500 dark:text-zinc-400">{t(locale, 'plansSubtitle')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ActionIconButton
            type="button"
            onClick={() => void refreshPlanning()}
            label={t(locale, 'plansRefresh')}
            tooltipSide="bottom"
            disabled={planningBusy}
            className="grid h-10 w-10 place-items-center rounded-xl border border-zinc-200 bg-[#fcfcfb] text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-[#161b22] dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            <RefreshCw className={cn('h-4 w-4', planningBusy && 'animate-spin motion-reduce:animate-none')} />
          </ActionIconButton>
          <ActionIconButton
            type="button"
            onClick={onToggleMaximized}
            label={maximized ? t(locale, 'exitFullscreen') : t(locale, 'fullscreen')}
            tooltipSide="bottom"
            className="grid h-10 w-10 place-items-center rounded-xl border border-zinc-200 bg-[#fcfcfb] text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-[#161b22] dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            {maximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </ActionIconButton>
        </div>
      </header>

      {(locked || accessContext.entitlementStatus === 'grace' || storageIntegrity.status !== 'ok' || errorText) && (
        <div className="space-y-2" aria-live="polite">
          {locked && (
            <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-100">
              <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0" />
              <div><strong>{t(locale, 'plansLockedTitle')}</strong><p className="text-xs opacity-85">{t(locale, 'plansLockedDescription')}</p></div>
            </div>
          )}
          {accessContext.entitlementStatus === 'grace' && (
            <div className="rounded-xl border border-sky-200 bg-sky-50 px-3 py-2 text-xs text-sky-800 dark:border-sky-500/25 dark:bg-sky-500/10 dark:text-sky-100">{t(locale, 'plansGraceDescription')}</div>
          )}
          {storageIntegrity.status !== 'ok' && (
            <div className={cn('flex items-start justify-between gap-3 rounded-xl border px-3 py-2 text-xs', storageIntegrity.status === 'blocked' ? 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-100' : 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-100')}>
              <div>
                <strong>{storageIntegrity.status === 'blocked' ? t(locale, 'plansIntegrityBlocked') : t(locale, 'plansIntegrityWarning')}</strong>
                <p className="mt-1 break-all opacity-80">{storageIntegrity.issues.map((issue) => `${issue.code}: ${issue.path}`).join(' · ')}</p>
              </div>
              <button type="button" onClick={() => void exportRecoveryData()} className="shrink-0 rounded-lg border border-current px-2 py-1 font-semibold hover:bg-white/40">{t(locale, 'plansRecoveryExport')}</button>
            </div>
          )}
          {errorText && <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-100">{errorText}</div>}
        </div>
      )}

      {readyPlanId !== null && readyPlanId === selectedPlanId && <p role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-100">{t(locale, 'plansRunReady')}</p>}
      <div className="grid min-h-0 flex-1 auto-rows-[minmax(28rem,auto)] grid-cols-[minmax(220px,0.72fr)_minmax(0,1.25fr)] gap-3 overflow-y-auto min-[1100px]:auto-rows-auto min-[1100px]:grid-cols-[minmax(220px,0.72fr)_minmax(350px,1.25fr)_minmax(250px,0.9fr)] min-[1100px]:overflow-hidden">
        <section className={panelClass} aria-labelledby="plan-templates-title">
          <div className="border-b border-zinc-200 p-3 dark:border-zinc-800">
            <h2 id="plan-templates-title" className="flex items-center gap-2 text-sm font-semibold"><Layers3 className="h-4 w-4" />{t(locale, 'plansTemplates')}</h2>
          </div>
          <form onSubmit={submitTemplate} className="space-y-2 border-b border-zinc-200 p-3 dark:border-zinc-800">
            <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansTemplateTitle')}
              <input ref={templateTitleRef} value={templateTitle} maxLength={TASK_TITLE_MAX_LENGTH} disabled={!templatesAllowed || integrityBlocked || planningBusy} onFocus={clearPlanningError} onChange={(event) => setTemplateTitle(event.target.value)} className={cn(inputClass, 'mt-1')} />
            </label>
            <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansFocusMode')}
              <select value={templateFocusModeId ?? ''} disabled={!templatesAllowed || integrityBlocked || planningBusy} onChange={(event) => setTemplateFocusModeId(event.target.value || null)} className={cn(inputClass, 'mt-1')}>
                <option value="">{t(locale, 'plansNoFocusMode')}</option>
                {focusModes.map((mode) => <option key={mode.id} value={mode.id}>{mode.title}</option>)}
              </select>
            </label>
            <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansTargetSessions')}
              <input type="number" min={1} max={99} value={templateTarget} disabled={!templatesAllowed || integrityBlocked || planningBusy} onChange={(event) => setTemplateTarget(Number(event.target.value))} className={cn(inputClass, 'mt-1')} />
            </label>
            <div className="flex gap-2">
              <button type="submit" disabled={!templateTitle.trim() || !templatesAllowed || integrityBlocked || planningBusy} className="h-9 flex-1 rounded-lg bg-zinc-900 px-3 text-xs font-semibold text-white disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-900">{editingTemplateId ? t(locale, 'save') : t(locale, 'plansCreateTemplate')}</button>
              {editingTemplateId && <ActionIconButton type="button" onClick={resetTemplateEditor} label={t(locale, 'cancel')} className="grid h-9 w-9 place-items-center rounded-lg border border-zinc-200 dark:border-zinc-700"><X className="h-4 w-4" /></ActionIconButton>}
            </div>
          </form>
          <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
            {!taskTemplates.length ? <p className="rounded-lg border border-dashed border-zinc-200 p-4 text-center text-xs text-zinc-500 dark:border-zinc-700">{t(locale, 'plansTemplatesEmpty')}</p> : taskTemplates.map((template) => (
              <article key={template.id} className="rounded-xl border border-zinc-200 p-2.5 text-xs dark:border-zinc-800">
                <div className="flex items-start gap-2"><div className="min-w-0 flex-1"><strong className="block break-words text-sm">{template.title}</strong><span className="text-zinc-500 dark:text-zinc-400">{t(locale, 'plansTargetSessions')}: {template.targetWorkSessions}</span></div>
                  <ActionIconButton type="button" onClick={() => editTemplate(template)} label={t(locale, 'edit')} disabled={!templatesAllowed || integrityBlocked} className="grid h-7 w-7 place-items-center rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800"><Pencil className="h-3.5 w-3.5" /></ActionIconButton>
                  <ActionIconButton type="button" onClick={() => { if (window.confirm(`${t(locale, 'delete')} “${template.title}”?`)) void mutatePlanning({ type: 'DELETE_TASK_TEMPLATE', payload: { templateId: template.id } }); }} label={t(locale, 'delete')} disabled={integrityBlocked} className="grid h-7 w-7 place-items-center rounded-md text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10"><Trash2 className="h-3.5 w-3.5" /></ActionIconButton>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={panelClass} aria-labelledby="plans-list-title">
          <div className="flex items-center justify-between border-b border-zinc-200 p-3 dark:border-zinc-800"><h2 id="plans-list-title" className="text-sm font-semibold">{t(locale, 'plansList')}</h2>{planningBusy && <span className="text-xs text-zinc-500">{t(locale, 'plansBusy')}</span>}</div>
          <div className="grid min-h-0 flex-1 grid-rows-[minmax(8rem,0.7fr)_minmax(15rem,1.3fr)]">
            <div className="min-h-0 space-y-2 overflow-y-auto border-b border-zinc-200 p-3 dark:border-zinc-800">
              {!focusPlans.length ? <p className="rounded-lg border border-dashed border-zinc-200 p-4 text-center text-xs text-zinc-500 dark:border-zinc-700">{t(locale, 'plansEmpty')}</p> : focusPlans.map((item) => {
                const selectable = canSelectFocusPlan(selectedPlanId, item.id, planEditorActive);
                return (
                  <button key={item.id} type="button" disabled={!selectable} onClick={() => { if (!selectable) return; setSelectedPlanId(item.id); clearPlanningError(); }} className={cn('flex w-full items-center gap-2 rounded-xl border p-2.5 text-left motion-reduce:transition-none disabled:cursor-not-allowed disabled:opacity-50', selectedPlanId === item.id ? 'border-rose-300 bg-rose-50 dark:border-rose-500/40 dark:bg-rose-500/10' : selectable ? 'border-zinc-200 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-900' : 'border-zinc-200 dark:border-zinc-800')}>
                    <CheckCircle2 className={cn('h-4 w-4 shrink-0', selectedPlanId === item.id ? 'text-rose-500' : 'text-zinc-400')} /><span className="min-w-0 flex-1"><strong className="block break-words text-sm">{item.title}</strong><span className="text-xs text-zinc-500">{t(locale, 'plansStepsCount', { count: item.steps.length })}</span></span>
                  </button>
                );
              })}
            </div>
            <form onSubmit={submitPlan} className="min-h-0 space-y-2 overflow-y-auto p-3">
              {selectedPlan && !editingPlanId && (
                <section aria-labelledby="selected-plan-steps-title" className="rounded-xl border border-zinc-200 bg-zinc-50/70 p-2.5 dark:border-zinc-800 dark:bg-zinc-900/40">
                  <h3 id="selected-plan-steps-title" className="text-xs font-semibold">{t(locale, 'plansSteps')}</h3>
                  <ol className="mt-2 space-y-1.5">
                    {selectedPlan.steps.map((step, index) => (
                      <li key={step.id} className="rounded-lg border border-zinc-200 bg-white px-2 py-1.5 text-xs dark:border-zinc-800 dark:bg-[#0d1117]">
                        <strong className="block break-words">{index + 1}. {step.titleSnapshot}</strong>
                        <span className="break-all text-zinc-500 dark:text-zinc-400">
                          {t(locale, 'plansFocusMode')}: {getFocusModeLabel(step.focusModeIdSnapshot)} · {t(locale, 'plansTargetSessions')}: {step.targetWorkSessions}
                        </span>
                      </li>
                    ))}
                  </ol>
                </section>
              )}
              <div className="flex items-end gap-2"><label className="min-w-0 flex-1 text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansPlanTitle')}<input ref={planTitleRef} value={planTitle} maxLength={80} disabled={!plansAllowed || integrityBlocked || planningBusy} onFocus={clearPlanningError} onChange={(event) => setPlanTitle(event.target.value)} className={cn(inputClass, 'mt-1')} /></label>{selectedPlan && !editingPlanId && <ActionIconButton type="button" onClick={editPlan} label={t(locale, 'edit')} disabled={!plansAllowed || integrityBlocked} className="grid h-9 w-9 place-items-center rounded-lg border border-zinc-200 dark:border-zinc-700"><Pencil className="h-4 w-4" /></ActionIconButton>}</div>
              <div className="flex gap-2"><select aria-label={t(locale, 'plansAddTemplateStep')} value={templateToAdd} disabled={!plansAllowed || integrityBlocked || planningBusy || !taskTemplates.length} onChange={(event) => setTemplateToAdd(event.target.value)} className={cn(inputClass, 'min-w-0 flex-1')}><option value="">{t(locale, 'plansAddTemplateStep')}</option>{taskTemplates.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select><ActionIconButton type="button" onClick={addTemplateStep} disabled={!templateToAdd || !plansAllowed || integrityBlocked} label={t(locale, 'add')} className="grid h-9 w-9 place-items-center rounded-lg border border-zinc-200 dark:border-zinc-700"><Plus className="h-4 w-4" /></ActionIconButton><button type="button" onClick={() => setPlanSteps((items) => [...items, createDraftStep()])} disabled={!plansAllowed || integrityBlocked || planningBusy} className="h-9 rounded-lg border border-zinc-200 px-2 text-xs font-semibold disabled:opacity-40 dark:border-zinc-700">{t(locale, 'plansAddManualStep')}</button></div>
              <div className="space-y-2">
                {planSteps.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-[minmax(0,1fr)_5rem_auto] gap-2 rounded-xl border border-zinc-200 p-2 dark:border-zinc-800">
                    <label className="col-span-3 text-[10px] text-zinc-500">{t(locale, 'plansStepTitle')}<input value={item.titleSnapshot} maxLength={TASK_TITLE_MAX_LENGTH} disabled={!plansAllowed || integrityBlocked || planningBusy} onChange={(event) => setPlanSteps((items) => items.map((stepItem) => stepItem.id === item.id ? { ...stepItem, sourceTemplateId: null, titleSnapshot: event.target.value } : stepItem))} className={cn(inputClass, 'mt-0.5 h-8')} /></label>
                    <label className="text-[10px] text-zinc-500">{t(locale, 'plansFocusMode')}<select value={item.focusModeIdSnapshot ?? ''} disabled={!plansAllowed || integrityBlocked || planningBusy} onChange={(event) => setPlanSteps((items) => items.map((stepItem) => stepItem.id === item.id ? { ...stepItem, sourceTemplateId: null, focusModeIdSnapshot: event.target.value || null } : stepItem))} className={cn(inputClass, 'mt-0.5 h-8 px-1 text-[11px]')}><option value="">—</option>{focusModes.map((mode) => <option key={mode.id} value={mode.id}>{mode.title}</option>)}</select></label>
                    <label className="text-[10px] text-zinc-500">{t(locale, 'plansTargetSessions')}<input type="number" min={1} max={99} value={item.targetWorkSessions} disabled={!plansAllowed || integrityBlocked || planningBusy} onChange={(event) => setPlanSteps((items) => items.map((stepItem) => stepItem.id === item.id ? { ...stepItem, sourceTemplateId: null, targetWorkSessions: Number(event.target.value) } : stepItem))} className={cn(inputClass, 'mt-0.5 h-8 px-1 text-center')} /></label>
                    <div className="flex items-end"><ActionIconButton type="button" onClick={() => setPlanSteps((items) => { const copy = [...items]; [copy[index - 1], copy[index]] = [copy[index], copy[index - 1]]; return copy; })} disabled={index === 0} label={t(locale, 'plansMoveStepUp')} className="grid h-8 w-7 place-items-center disabled:opacity-30"><ArrowUp className="h-3.5 w-3.5" /></ActionIconButton><ActionIconButton type="button" onClick={() => setPlanSteps((items) => { const copy = [...items]; [copy[index], copy[index + 1]] = [copy[index + 1], copy[index]]; return copy; })} disabled={index === planSteps.length - 1} label={t(locale, 'plansMoveStepDown')} className="grid h-8 w-7 place-items-center disabled:opacity-30"><ArrowDown className="h-3.5 w-3.5" /></ActionIconButton><ActionIconButton type="button" onClick={() => setPlanSteps((items) => items.filter((stepItem) => stepItem.id !== item.id))} label={t(locale, 'plansRemoveStep')} className="grid h-8 w-7 place-items-center text-rose-600"><X className="h-3.5 w-3.5" /></ActionIconButton></div>
                  </div>
                ))}
              </div>
              {planStepError && <p role="status" className="text-xs text-rose-600 dark:text-rose-300">{planStepError}</p>}
              <div className="flex gap-2"><button type="submit" disabled={!planTitle.trim() || !planSteps.length || Boolean(planStepError) || !plansAllowed || integrityBlocked || planningBusy || !isFocusPlanEditSelectionValid(editingPlanId, selectedPlanId)} className="h-9 flex-1 rounded-lg bg-zinc-900 px-3 text-xs font-semibold text-white disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-900">{editingPlanId ? t(locale, 'plansUpdatePlan') : t(locale, 'plansCreatePlan')}</button>{(editingPlanId || planTitle || planSteps.length > 0) && <button type="button" onClick={resetPlanEditor} className="h-9 rounded-lg border border-zinc-200 px-3 text-xs font-semibold dark:border-zinc-700">{t(locale, 'cancel')}</button>}</div>
              {selectedPlan && <div className="flex gap-2 border-t border-zinc-200 pt-2 dark:border-zinc-800"><button type="button" onClick={() => void runPlan()} disabled={!plansAllowed || integrityBlocked || planningBusy || Boolean(selectedSchedule?.enabled && !selectedEvaluation?.actionableOccurrenceToken)} className="flex h-9 flex-1 items-center justify-center gap-2 rounded-lg bg-emerald-600 px-3 text-xs font-semibold text-white disabled:opacity-40"><Play className="h-3.5 w-3.5" />{selectedSchedule?.enabled ? t(locale, 'plansStartOccurrence') : t(locale, 'plansStartManual')}</button><ActionIconButton type="button" onClick={() => { if (window.confirm(`${t(locale, 'delete')} “${selectedPlan.title}”?`)) void mutatePlanning({ type: 'DELETE_FOCUS_PLAN', payload: { planId: selectedPlan.id } }); }} label={t(locale, 'delete')} disabled={integrityBlocked} className="grid h-9 w-9 place-items-center rounded-lg border border-rose-200 text-rose-600 dark:border-rose-500/30"><Trash2 className="h-4 w-4" /></ActionIconButton></div>}
            </form>
          </div>
        </section>

        <aside className="col-span-2 grid min-h-0 grid-cols-2 gap-3 min-[1100px]:col-span-1 min-[1100px]:grid-cols-1 min-[1100px]:grid-rows-[minmax(18rem,1fr)_minmax(12rem,0.8fr)] min-[1100px]:overflow-y-auto">
          <section className={panelClass} aria-labelledby="schedule-title">
            <div className="border-b border-zinc-200 p-3 dark:border-zinc-800"><h2 id="schedule-title" className="flex items-center gap-2 text-sm font-semibold"><CalendarClock className="h-4 w-4" />{t(locale, 'plansSchedule')}</h2></div>
            {!selectedPlan ? <p className="p-4 text-center text-xs text-zinc-500">{t(locale, 'plansEmpty')}</p> : <form onSubmit={saveSchedule} className="min-h-0 space-y-2 overflow-y-auto p-3">
              {selectedSchedule && <div className="rounded-xl border border-zinc-200 p-2 text-xs dark:border-zinc-800"><div className="flex items-center justify-between"><strong className="flex items-center gap-1"><Clock3 className="h-3.5 w-3.5" />{statusLabel}</strong><span>{selectedSchedule.enabled ? t(locale, 'plansEnabled') : t(locale, 'plansDisabled')}</span></div>{selectedEvaluation?.nextScheduledDate && <p className="mt-1 text-zinc-500">{t(locale, 'plansNext', { date: selectedEvaluation.nextScheduledDate })}</p>}{Boolean(selectedEvaluation?.collapsedOlderOccurrenceCount) && <p className="mt-1 text-amber-700 dark:text-amber-300">{t(locale, 'plansCollapsed', { count: selectedEvaluation!.collapsedOlderOccurrenceCount })}</p>}</div>}
              <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansRecurrence')}<select value={recurrenceType} disabled={!recurrenceAllowed || integrityBlocked || planningBusy} onChange={(event) => setRecurrenceType(event.target.value as FocusPlanRecurrence['type'])} className={cn(inputClass, 'mt-1')}><option value="daily">{t(locale, 'plansDaily')}</option><option value="weekdays">{t(locale, 'plansWeekdays')}</option><option value="selectedWeekdays">{t(locale, 'plansSelectedWeekdays')}</option></select></label>
              <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">{t(locale, 'plansStartsOn')}<input type="date" min={selectedSchedule ? undefined : getLocalDateKey()} value={startsOn} disabled={!recurrenceAllowed || integrityBlocked || planningBusy} onChange={(event) => setStartsOn(event.target.value)} className={cn(inputClass, 'mt-1')} /></label>
              {recurrenceType === 'selectedWeekdays' && <fieldset disabled={!recurrenceAllowed || integrityBlocked || planningBusy}><legend className="sr-only">{t(locale, 'plansSelectedWeekdays')}</legend><div className="grid grid-cols-7 gap-1">{weekdayLabels.map((label, index) => { const weekday = index + 1; const active = selectedWeekdays.includes(weekday); return <button key={weekday} type="button" aria-pressed={active} onClick={() => setSelectedWeekdays((days) => active ? days.filter((day) => day !== weekday) : [...days, weekday].sort())} className={cn('h-8 rounded-md border text-[10px] font-semibold', active ? 'border-rose-400 bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-200' : 'border-zinc-200 text-zinc-500 dark:border-zinc-700')}>{label}</button>; })}</div></fieldset>}
              <button type="submit" disabled={!recurrenceAllowed || integrityBlocked || planningBusy || !startsOn || (recurrenceType === 'selectedWeekdays' && !selectedWeekdays.length)} className="h-9 w-full rounded-lg bg-zinc-900 text-xs font-semibold text-white disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-900">{selectedSchedule ? t(locale, 'plansSaveSchedule') : t(locale, 'plansCreateSchedule')}</button>
              {selectedSchedule && <div className="grid grid-cols-2 gap-2"><button type="button" onClick={() => void mutatePlanning({ type: 'SET_FOCUS_PLAN_SCHEDULE_ENABLED', payload: { scheduleId: selectedSchedule.id, enabled: !selectedSchedule.enabled } })} disabled={integrityBlocked || planningBusy || (!selectedSchedule.enabled && !recurrenceAllowed)} className="h-9 rounded-lg border border-zinc-200 text-xs font-semibold disabled:opacity-40 dark:border-zinc-700">{selectedSchedule.enabled ? t(locale, 'plansDisable') : t(locale, 'plansEnable')}</button><button type="button" onClick={() => void mutatePlanning({ type: 'DELETE_FOCUS_PLAN_SCHEDULE', payload: { scheduleId: selectedSchedule.id } })} disabled={integrityBlocked || planningBusy} className="h-9 rounded-lg border border-rose-200 text-xs font-semibold text-rose-600 disabled:opacity-40 dark:border-rose-500/30">{t(locale, 'plansDeleteSchedule')}</button></div>}
              {selectedSchedule?.enabled && selectedEvaluation?.actionableOccurrenceToken && <button type="button" onClick={() => void mutatePlanning({ type: 'SKIP_FOCUS_PLAN_OCCURRENCE', payload: { planId: selectedPlan.id, scheduleId: selectedSchedule.id, occurrenceToken: selectedEvaluation.actionableOccurrenceToken! } })} disabled={!recurrenceAllowed || integrityBlocked || planningBusy} className="flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-amber-300 text-xs font-semibold text-amber-700 disabled:opacity-40 dark:border-amber-500/30 dark:text-amber-200"><SkipForward className="h-3.5 w-3.5" />{t(locale, 'plansSkipOccurrence')}</button>}
            </form>}
          </section>

          <section className={panelClass} aria-labelledby="runs-title"><div className="border-b border-zinc-200 p-3 dark:border-zinc-800"><h2 id="runs-title" className="text-sm font-semibold">{t(locale, 'plansRuns')}</h2></div><div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">{!selectedRuns.length ? <p className="rounded-lg border border-dashed border-zinc-200 p-4 text-center text-xs text-zinc-500 dark:border-zinc-700">{t(locale, 'plansRunsEmpty')}</p> : selectedRuns.map((run) => { const created = run.items.filter((item) => item.materialization === 'created').length; return <article key={run.id} className="rounded-xl border border-zinc-200 p-2 text-xs dark:border-zinc-800"><strong className="block break-words">{run.planTitleSnapshot}</strong><span className="text-zinc-500">{run.startedLocalDate} · {t(locale, 'plansRunSummary', { created, reused: run.items.length - created })}</span></article>; })}</div></section>
        </aside>
      </div>
    </main>
  );
};
