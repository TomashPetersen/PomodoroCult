import { Download, Minus, Plus, Save, Upload, X } from 'lucide-react';
import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import { useModalFocus } from '../lib/useModalFocus';
import { SETTINGS_FIELDS } from '../lib/constants';
import { getLanguagePreferenceLabel, getSettingLabel, t } from '../lib/i18n';
import { areTimerDurationsLocked } from '../lib/storage';
import { cn } from '../lib/ui';
import { LanguagePreference, Settings } from '../lib/types';
import { useAppStore } from '../store/useAppStore';
import { ActionIconButton } from './ActionIconButton';

type SettingKey = (typeof SETTINGS_FIELDS)[number]['key'];
type DraftValues = Record<SettingKey, string>;

const toDraftValues = (settings: Settings): DraftValues => ({
  workTime: String(settings.workTime),
  shortBreak: String(settings.shortBreak),
  longBreak: String(settings.longBreak),
  longBreakInterval: String(settings.longBreakInterval)
});

const getFieldConfig = (key: SettingKey) => SETTINGS_FIELDS.find((field) => field.key === key)!;
const editableSettingKeys: Array<keyof Settings> = [
  ...SETTINGS_FIELDS.map((field) => field.key),
  'languagePreference', 'autoStartBreaks', 'autoStartWork'
];

const parseDraftValue = (value: string): number | null => {
  if (!/^\d+$/.test(value.trim())) return null;
  return Number(value);
};

const clampFieldValue = (key: SettingKey, value: number): number => {
  const field = getFieldConfig(key);
  return Math.max(field.min, Math.min(field.max, Math.round(value)));
};

export const SettingsModal = () => {
  const open = useAppStore((state) => state.settingsOpen);
  const locale = useAppStore((state) => state.locale);
  const settings = useAppStore((state) => state.settings);
  const timerState = useAppStore((state) => state.timerState);
  const closeSettings = useAppStore((state) => state.closeSettings);
  const saveSettings = useAppStore((state) => state.saveSettings);
  const exportUserData = useAppStore((state) => state.exportUserData);
  const importUserData = useAppStore((state) => state.importUserData);
  const clearDataTransferStatus = useAppStore((state) => state.clearDataTransferStatus);
  const dataTransferMessage = useAppStore((state) => state.dataTransferMessage);
  const dataTransferError = useAppStore((state) => state.dataTransferError);
  const [draftValues, setDraftValues] = useState<DraftValues>(() => toDraftValues(settings));
  const [draftLanguage, setDraftLanguage] = useState<LanguagePreference>(settings.languagePreference);
  const [draftAutoStartWork, setDraftAutoStartWork] = useState(settings.autoStartWork);
  const [draftAutoStartBreaks, setDraftAutoStartBreaks] = useState(settings.autoStartBreaks);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [externalSettingsChanged, setExternalSettingsChanged] = useState(false);
  const wasOpenRef = useRef(false);
  const baselineRef = useRef(settings);
  const draftRef = useRef({ draftValues, draftLanguage, draftAutoStartBreaks, draftAutoStartWork });
  draftRef.current = { draftValues, draftLanguage, draftAutoStartBreaks, draftAutoStartWork };
  const dialogRef = useModalFocus(open, closeSettings);
  const dataDialogRef = useModalFocus(open && exportMenuOpen, () => setExportMenuOpen(false));
  const importInputRef = useRef<HTMLInputElement | null>(null);
  const timerDurationsLocked = areTimerDurationsLocked(settings, timerState);
  const timerDurationsLockedMessage = t(locale, 'settingDurationLocked');
  const languageOptions: LanguagePreference[] = ['auto', 'ru', 'en'];

  useEffect(() => {
    if (!open) {
      wasOpenRef.current = false;
      return;
    }
    if (!wasOpenRef.current) {
      wasOpenRef.current = true;
      baselineRef.current = settings;
      setDraftValues(toDraftValues(settings));
      setDraftLanguage(settings.languagePreference);
      setDraftAutoStartBreaks(settings.autoStartBreaks);
      setDraftAutoStartWork(settings.autoStartWork);
      setExportMenuOpen(false);
      setSaveError(false);
      setExternalSettingsChanged(false);
      return;
    }
    const previous = baselineRef.current;
    if ((Object.keys(settings) as Array<keyof Settings>).every((key) => settings[key] === previous[key])) return;
    const draft = draftRef.current;
    const hasUserEdits = SETTINGS_FIELDS.some((field) => draft.draftValues[field.key] !== String(previous[field.key])) ||
      draft.draftLanguage !== previous.languagePreference ||
      draft.draftAutoStartBreaks !== previous.autoStartBreaks || draft.draftAutoStartWork !== previous.autoStartWork;
    if (hasUserEdits) setExternalSettingsChanged(true);
    setDraftValues((current) => Object.fromEntries(SETTINGS_FIELDS.map((field) => [
      field.key, current[field.key] === String(previous[field.key]) ? String(settings[field.key]) : current[field.key]
    ])) as DraftValues);
    setDraftLanguage((current) => current === previous.languagePreference ? settings.languagePreference : current);
    setDraftAutoStartBreaks((current) => current === previous.autoStartBreaks ? settings.autoStartBreaks : current);
    setDraftAutoStartWork((current) => current === previous.autoStartWork ? settings.autoStartWork : current);
    baselineRef.current = settings;
  }, [open, settings]);

  useEffect(() => {
    if (!open) return;
    clearDataTransferStatus();
  }, [clearDataTransferStatus, open]);

  const validation = useMemo(() => {
    const result = new Map<SettingKey, { value: number | null; valid: boolean }>();

    for (const field of SETTINGS_FIELDS) {
      const value = parseDraftValue(draftValues[field.key]);
      result.set(field.key, {
        value,
        valid: value !== null && value >= field.min && value <= field.max
      });
    }

    return result;
  }, [draftValues]);

  const shortBreakValue = validation.get('shortBreak')?.value ?? null;
  const longBreakValue = validation.get('longBreak')?.value ?? null;
  const breakRelationInvalid =
    shortBreakValue !== null && longBreakValue !== null && shortBreakValue > longBreakValue;

  if (!open) return null;

  const setValue = (key: SettingKey, value: string) => {
    if (key !== 'longBreakInterval' && timerDurationsLocked) return;
    setDraftValues((current) => ({ ...current, [key]: value.replace(/[^\d]/g, '') }));
  };

  const clampDraft = (key: SettingKey) => {
    const parsed = parseDraftValue(draftValues[key]);
    const fallback = settings[key];
    let nextValue = clampFieldValue(key, parsed ?? fallback);

    if (key === 'shortBreak') {
      const pairedLongBreak = clampFieldValue(
        'longBreak',
        parseDraftValue(draftValues.longBreak) ?? settings.longBreak
      );
      nextValue = Math.min(nextValue, pairedLongBreak);
    }

    if (key === 'longBreak') {
      const pairedShortBreak = clampFieldValue(
        'shortBreak',
        parseDraftValue(draftValues.shortBreak) ?? settings.shortBreak
      );
      nextValue = Math.max(nextValue, pairedShortBreak);
    }

    setDraftValues((current) => ({
      ...current,
      [key]: String(nextValue)
    }));
  };

  const stepValue = (key: SettingKey, delta: number) => {
    if (key !== 'longBreakInterval' && timerDurationsLocked) return;
    const parsed = parseDraftValue(draftValues[key]) ?? settings[key];
    let nextValue = clampFieldValue(key, parsed + delta);

    if (key === 'shortBreak') {
      const pairedLongBreak = clampFieldValue(
        'longBreak',
        parseDraftValue(draftValues.longBreak) ?? settings.longBreak
      );
      nextValue = Math.min(nextValue, pairedLongBreak);
    }

    if (key === 'longBreak') {
      const pairedShortBreak = clampFieldValue(
        'shortBreak',
        parseDraftValue(draftValues.shortBreak) ?? settings.shortBreak
      );
      nextValue = Math.max(nextValue, pairedShortBreak);
    }

    setDraftValues((current) => ({
      ...current,
      [key]: String(nextValue)
    }));
  };

  const hasInvalidValues =
    SETTINGS_FIELDS.some((field) => !validation.get(field.key)?.valid) || breakRelationInvalid;
  const nextSettings: Settings | null = hasInvalidValues
    ? null
    : {
        workTime: validation.get('workTime')!.value!,
        shortBreak: validation.get('shortBreak')!.value!,
        longBreak: validation.get('longBreak')!.value!,
        longBreakInterval: validation.get('longBreakInterval')!.value!,
        languagePreference: draftLanguage,
        autoStartBreaks: draftAutoStartBreaks,
        autoStartWork: draftAutoStartWork,
        focusMusicEnabled: settings.focusMusicEnabled,
        focusMusicVolume: settings.focusMusicVolume,
        focusMusicTrack: settings.focusMusicTrack
      };
  const changedKeys = nextSettings
    ? editableSettingKeys.filter((key) => nextSettings[key] !== baselineRef.current[key])
    : [];
  const canSave = Boolean(nextSettings) && changedKeys.length > 0;

  const handleImportFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') return;
      void importUserData(reader.result);
    };
    reader.onerror = () => {
      void importUserData('');
    };
    reader.readAsText(file);
  };

  const handleExportBackup = async () => {
    await exportUserData();
    setExportMenuOpen(false);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#f6f8fa]/82 p-4 backdrop-blur-md dark:bg-[#0f141a]/82">
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="settings-title" tabIndex={-1} className="flex max-h-[calc(100%-2rem)] w-full max-w-[32rem] flex-col rounded-2xl border border-zinc-200 bg-[#fcfcfb] p-4 shadow-soft dark:border-zinc-800 dark:bg-[#161b22]">
        <div className="mb-3 flex items-center justify-between">
          <h2 id="settings-title" className="text-lg font-semibold text-zinc-950 dark:text-white">{t(locale, 'settings')}</h2>
          <div className="flex items-center gap-1">
            <ActionIconButton
              type="button"
              onClick={() => setExportMenuOpen(true)}
              label={t(locale, 'openDataMenu')}
              tooltipAlign="right"
              tooltipSide="bottom"
              className="grid h-9 w-9 place-items-center rounded-lg text-zinc-500 transition hover:bg-[#eef2f6] hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-[#21262d] dark:hover:text-[#f0f3f6]"
            >
              <Upload className="h-5 w-5" />
            </ActionIconButton>
            <ActionIconButton
              type="button"
              onClick={closeSettings}
              label={t(locale, 'close')}
              tooltipAlign="right"
              tooltipSide="bottom"
              className="grid h-9 w-9 place-items-center rounded-lg text-zinc-500 transition hover:bg-[#eef2f6] hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-[#21262d] dark:hover:text-[#f0f3f6]"
            >
              <X className="h-5 w-5" />
            </ActionIconButton>
          </div>
        </div>

        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
          {externalSettingsChanged && (
            <p role="status" className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
              {t(locale, 'settingsChangedElsewhere')}
            </p>
          )}
          <input
            ref={importInputRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={handleImportFile}
          />

          {SETTINGS_FIELDS.map((field) => {
            const locked = field.key !== 'longBreakInterval' && timerDurationsLocked;
            const invalid =
              !validation.get(field.key)?.valid ||
              (field.key === 'shortBreak' && breakRelationInvalid) ||
              (field.key === 'longBreak' && breakRelationInvalid);

            return (
              <label
                key={field.key}
                className={cn(
                  'block rounded-xl border border-zinc-200 bg-[#f0f3f6] px-3 py-2.5 dark:border-zinc-800 dark:bg-[#21262d]',
                  locked && 'opacity-60'
                )}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="min-w-0 text-sm font-medium text-zinc-700 dark:text-zinc-200">
                    {getSettingLabel(locale, field.key)}
                  </span>

                  <div className={cn('flex h-8 shrink-0 items-center rounded-lg border bg-[#fcfcfb] dark:bg-[#0d1117]', invalid ? 'border-rose-300 dark:border-rose-500/60' : 'border-zinc-200 dark:border-zinc-700')}>
                    <button
                      type="button"
                      disabled={locked}
                      onClick={() => stepValue(field.key, -1)}
                      className={cn(
                        'grid h-8 w-9 place-items-center text-zinc-500 transition hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white',
                        locked && 'cursor-not-allowed opacity-50'
                      )}
                      aria-label={t(locale, 'decrease')}
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <input
                      type="text"
                      inputMode="numeric"
                      disabled={locked}
                      value={draftValues[field.key]}
                      onBlur={() => clampDraft(field.key)}
                      onChange={(event) => setValue(field.key, event.target.value)}
                      className="h-8 w-16 bg-transparent text-center text-sm font-semibold text-zinc-950 outline-none disabled:cursor-not-allowed dark:text-white"
                    />
                    <button
                      type="button"
                      disabled={locked}
                      onClick={() => stepValue(field.key, 1)}
                      className={cn(
                        'grid h-8 w-9 place-items-center text-zinc-500 transition hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white',
                        locked && 'cursor-not-allowed opacity-50'
                      )}
                      aria-label={t(locale, 'increase')}
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                {invalid && (
                  <p className="mt-1 text-xs text-rose-600 dark:text-rose-300">
                    {field.key === 'shortBreak' && breakRelationInvalid
                      ? t(locale, 'settingShortBreakNotLongerThanRest')
                      : field.key === 'longBreak' && breakRelationInvalid
                        ? t(locale, 'settingLongRestNotShorterThanBreak')
                        : t(locale, 'settingInvalidValue', { min: field.min, max: field.max })}
                  </p>
                )}
                {field.key === 'longBreakInterval' && timerDurationsLocked && (
                  <p className="mt-0.5 text-[11px] leading-4 text-zinc-500 dark:text-zinc-400">
                    {t(locale, 'settingIntervalAppliesAfterCurrentTimer')}
                  </p>
                )}
              </label>
            );
          })}

          {timerDurationsLocked && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
              {timerDurationsLockedMessage}
            </div>
          )}

          <button
            type="button"
            onClick={() => setDraftAutoStartBreaks((current) => !current)}
            className="flex w-full items-center justify-between gap-3 rounded-xl border border-zinc-200 bg-[#f0f3f6] px-3 py-2.5 text-left transition hover:border-zinc-300 hover:bg-[#eef2f6] dark:border-zinc-800 dark:bg-[#21262d] dark:hover:bg-[#30363d]"
            aria-pressed={draftAutoStartBreaks}
          >
            <span className="min-w-0">
              <span className="block text-sm font-medium text-zinc-700 dark:text-zinc-200">
                {t(locale, 'settingAutoStartBreaks')}
              </span>
              <span className="mt-0.5 block text-[11px] leading-4 text-zinc-500 dark:text-zinc-400">
                {t(locale, 'settingAutoStartBreaksDescription')}
              </span>
            </span>
            <span
              className={cn(
                'relative h-6 w-11 shrink-0 rounded-full transition',
                draftAutoStartBreaks ? 'bg-rose-500' : 'bg-zinc-300 dark:bg-zinc-700'
              )}
              aria-hidden="true"
            >
              <span
                className={cn(
                  'absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition',
                  draftAutoStartBreaks ? 'left-6' : 'left-1'
                )}
              />
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDraftAutoStartWork((current) => !current)}
            className="flex w-full items-center justify-between gap-3 rounded-xl border border-zinc-200 bg-[#f0f3f6] px-3 py-2.5 text-left transition hover:border-zinc-300 hover:bg-[#eef2f6] dark:border-zinc-800 dark:bg-[#21262d] dark:hover:bg-[#30363d]"
            aria-pressed={draftAutoStartWork}
          >
            <span className="min-w-0">
              <span className="block text-sm font-medium text-zinc-700 dark:text-zinc-200">
                {t(locale, 'settingAutoStartWork')}
              </span>
              <span className="mt-0.5 block text-[11px] leading-4 text-zinc-500 dark:text-zinc-400">
                {t(locale, 'settingAutoStartWorkDescription')}
              </span>
            </span>
            <span
              className={cn(
                'relative h-6 w-11 shrink-0 rounded-full transition',
                draftAutoStartWork ? 'bg-rose-500' : 'bg-zinc-300 dark:bg-zinc-700'
              )}
              aria-hidden="true"
            >
              <span
                className={cn(
                  'absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition',
                  draftAutoStartWork ? 'left-6' : 'left-1'
                )}
              />
            </span>
          </button>

          <div className="rounded-xl border border-zinc-200 bg-[#f0f3f6] px-3 py-2 dark:border-zinc-800 dark:bg-[#21262d]">
            <p className="mb-1.5 text-sm font-medium text-zinc-700 dark:text-zinc-200">
              {t(locale, 'settingLanguage')}
            </p>
            <div className="grid grid-cols-3 rounded-lg bg-[#fcfcfb] p-1 dark:bg-[#0d1117]">
              {languageOptions.map((option) => {
                const active = draftLanguage === option;

                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setDraftLanguage(option)}
                    className={cn(
                      'h-8 rounded-md px-2 text-xs font-medium transition',
                      active
                        ? 'bg-[#24292f] text-[#f6f8fa] dark:bg-[#f0f3f6] dark:text-[#161b22]'
                        : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-300 dark:hover:text-[#f0f3f6]'
                    )}
                  >
                    {getLanguagePreferenceLabel(locale, option)}
                  </button>
                );
              })}
            </div>
          </div>

          {(dataTransferMessage || dataTransferError) && (
            <p
              className={cn(
                'rounded-xl px-3 py-2 text-xs leading-4',
                dataTransferError
                  ? 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-200'
                  : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-200'
              )}
            >
              {dataTransferError ?? dataTransferMessage}
            </p>
          )}
        </div>

        {saveError && <p role="alert" className="mt-2 text-xs text-rose-600 dark:text-rose-300">{t(locale, 'settingsSaveError')}</p>}
        <button
          type="button"
          disabled={!canSave || saving}
          onClick={async () => {
            if (!nextSettings || saving) return;
            setSaving(true);
            setSaveError(false);
            try {
              await saveSettings(nextSettings, changedKeys);
            } catch {
              setSaveError(true);
            } finally {
              setSaving(false);
            }
          }}
          className={cn(
            'mt-3 flex h-10 w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-[#24292f] text-sm font-semibold text-[#f6f8fa] transition hover:bg-[#32383f]',
            'disabled:cursor-not-allowed disabled:opacity-40 dark:bg-[#f0f3f6] dark:text-[#161b22] dark:hover:bg-[#d8dee4]'
          )}
        >
          <Save className="h-4 w-4" />
          {t(locale, 'save')}
        </button>
      </div>

      {exportMenuOpen && (
        <div
          className="absolute inset-0 z-10 flex items-center justify-center bg-[#f6f8fa]/65 p-6 backdrop-blur-sm dark:bg-[#0d1117]/65"
          onPointerDown={() => setExportMenuOpen(false)}
        >
          <div
            ref={dataDialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="data-menu-title"
            tabIndex={-1}
            className="w-full max-w-[19rem] rounded-2xl border border-zinc-200 bg-[#fcfcfb] p-4 shadow-soft dark:border-zinc-800 dark:bg-[#161b22]"
            onPointerDown={(event) => event.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between gap-3">
              <h3 id="data-menu-title" className="text-base font-semibold text-zinc-950 dark:text-white">
                {t(locale, 'dataMenuTitle')}
              </h3>
              <ActionIconButton
                type="button"
                onClick={() => setExportMenuOpen(false)}
                label={t(locale, 'close')}
                tooltipAlign="right"
                className="grid h-8 w-8 place-items-center rounded-lg text-zinc-500 transition hover:bg-[#eef2f6] hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-[#21262d] dark:hover:text-[#f0f3f6]"
              >
                <X className="h-4 w-4" />
              </ActionIconButton>
            </div>

            <button
              type="button"
              onClick={() => void handleExportBackup()}
              className="flex w-full items-start gap-3 rounded-xl border border-zinc-200 bg-[#f0f3f6] p-3 text-left transition hover:border-zinc-300 hover:bg-[#eef2f6] dark:border-zinc-800 dark:bg-[#21262d] dark:hover:bg-[#30363d]"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#fcfcfb] text-zinc-800 dark:bg-[#0d1117] dark:text-[#f0f3f6]">
                <Download className="h-4 w-4" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-zinc-900 dark:text-white">
                  {t(locale, 'exportFullBackup')}
                </span>
                <span className="mt-1 block text-xs leading-4 text-zinc-500 dark:text-zinc-400">
                  {t(locale, 'exportFullBackupDescription')}
                </span>
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setExportMenuOpen(false);
                importInputRef.current?.click();
              }}
              className="mt-2 flex w-full items-start gap-3 rounded-xl border border-zinc-200 bg-[#f0f3f6] p-3 text-left transition hover:border-zinc-300 hover:bg-[#eef2f6] dark:border-zinc-800 dark:bg-[#21262d] dark:hover:bg-[#30363d]"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#fcfcfb] text-zinc-800 dark:bg-[#0d1117] dark:text-[#f0f3f6]">
                <Upload className="h-4 w-4" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-zinc-900 dark:text-white">
                  {t(locale, 'importBackup')}
                </span>
                <span className="mt-1 block text-xs leading-4 text-zinc-500 dark:text-zinc-400">
                  {t(locale, 'importBackupDescription')}
                </span>
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
