import { playSynthesizedCompletionChime } from './lib/completionChime';
import { createFocusMusicPlayer, getFocusMusicDeadline } from './lib/focusMusicPlayer';
import type { RuntimeMessage, Settings, TimerState } from './lib/types';

let playbackState: { settings: Settings; timerState: TimerState } | null = null;
const player = createFocusMusicPlayer(async () => playbackState);

chrome.runtime.onMessage.addListener((message: RuntimeMessage, _sender, sendResponse) => {
  if (
    message?.type !== 'OFFSCREEN_SYNC_FOCUS_MUSIC' &&
    message?.type !== 'OFFSCREEN_PLAY_COMPLETION_CHIME'
  ) return;

  const respond = async (): Promise<void> => {
    if (message.type === 'OFFSCREEN_SYNC_FOCUS_MUSIC') {
      playbackState = message.payload;
      const { settings, timerState } = playbackState;
      await player.requestFocusMusicReconcileBounded(getFocusMusicDeadline(settings, timerState) === null);
    } else {
      playbackState = null;
      player.invalidateFocusMusicPlayback(true);
      await playSynthesizedCompletionChime();
    }
    sendResponse({ ok: true });
  };

  respond().catch((error) => {
    sendResponse({
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    });
  });

  return true;
});
