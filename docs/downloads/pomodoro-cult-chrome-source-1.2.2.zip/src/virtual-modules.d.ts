declare module 'virtual:pomodoro-runtime-access' {
  import type {
    RuntimeAccessDiagnosticsBridge,
    RuntimeAccessDiagnosticsDependencies
  } from './lib/accessDiagnostics';

  export function registerRuntimeAccessDiagnostics(
    dependencies: RuntimeAccessDiagnosticsDependencies
  ): RuntimeAccessDiagnosticsBridge | null;
}

declare module 'virtual:pomodoro-access-ui' {
  import type { ComponentType } from 'react';
  const RuntimeAccessDiagnosticsSlot: ComponentType;
  export default RuntimeAccessDiagnosticsSlot;
}

interface ImportMetaEnv {
  readonly DEV: boolean;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
