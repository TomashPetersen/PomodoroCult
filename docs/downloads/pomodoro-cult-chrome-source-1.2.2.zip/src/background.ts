import { prepareWorkAfterBreak } from './lib/timerTransitions';
import { NO_TASK_ID } from './lib/constants';
import {
  APP_WINDOW_SESSION_KEY,
  getNextAppWindowState,
  normalizeAppWindowId
} from './lib/appWindow';
import {
  getSnapshotDurationSeconds,
  resolveActiveWorkFocusMusicSettings,
  resolveNextWorkSnapshot
} from './lib/focusModes';
import { applyFocusModeMutation, FocusModeMutationMessage } from './lib/focusModeMutations';
import {
  applyFocusPlanMutation,
  createRuntimePlanningContext,
  parsePlanningMessage,
  PlanningMessage
} from './lib/focusPlanMutations';
import { evaluateFocusPlanSchedule } from './lib/focusPlanRecurrence';
import { getFocusMusicDeadline } from './lib/focusMusicPlayer';
import { applyTaskMutation, TaskMutationMessage } from './lib/taskMutations';
import {
  isFocusReviewGoalsPayload,
  normalizeFocusReviewGoals
} from './lib/focusReviewGoals';
import { getTimerModeLabel, resolveLocale, t } from './lib/i18n';
import { createSerializedOperationQueue } from './lib/operationQueue';
import { DEFAULT_ACCESS_CONTEXT } from './lib/access';
import { RuntimeAccessDiagnosticsBridge } from './lib/accessDiagnostics';
import { registerRuntimeAccessDiagnostics } from 'virtual:pomodoro-runtime-access';
import {
  addSessionStatistics,
  createCycleId,
  createSessionEvent,
  ensureNoTask,
  getLocalDateKey,
  getLocalStartMinute,
  getNextTimerRevision,
  getRunningDisplaySeconds,
  initializeStorage,
  importStoredData,
  readStoredData,
  readStoredDataResult,
  removeTaskSessionEvents,
  removeTaskStatistics,
  setLocal,
  sortTasks
} from './lib/storage';
import {
  FocusModeSnapshot,
  RuntimeMessage,
  Settings,
  StoredData,
  TimerMode,
  TimerState
} from './lib/types';

const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const COMPLETION_ALARM_PREFIX = 'pomodoro-completion:';
const COMPLETION_NOTIFICATION_PREFIX = 'pomodoro-completed:';
const APP_WINDOW_URL = 'app.html';
const APP_WINDOW_WIDTH = 1040;
const APP_WINDOW_HEIGHT = 760;

interface TimerCompletionResult {
  timerState: TimerState;
  completion?: {
    cycleId: string;
    mode: TimerMode;
    language: Settings['languagePreference'];
  };
}

let creatingOffscreenDocument: Promise<void> | null = null;
let appWindowId: number | null = null;
let openingAppWindow: Promise<void> | null = null;
const timerOperationQueue = createSerializedOperationQueue();
const enqueueTimerOperation = timerOperationQueue.enqueue;
const runtimeAccessDiagnostics: RuntimeAccessDiagnosticsBridge | null =
  registerRuntimeAccessDiagnostics({
    enqueue: enqueueTimerOperation,
    broadcast: (message: unknown) => new Promise<void>((resolve) => {
      chrome.runtime.sendMessage(message, () => {
        void chrome.runtime.lastError;
        resolve();
      });
    })
  });
const getAuthoritativeAccessContext = () =>
  runtimeAccessDiagnostics?.getAccessContext() ?? DEFAULT_ACCESS_CONTEXT;

const sendMessage = (message: RuntimeMessage): Promise<void> =>
  new Promise((resolve) => {
    chrome.runtime.sendMessage(message, () => {
      void chrome.runtime.lastError;
      resolve();
    });
  });

const buildAppWindowUrl = (options?: { screen?: string; statsView?: string }): string => {
  const url = new URL(chrome.runtime.getURL(APP_WINDOW_URL));
  if (options?.screen) url.searchParams.set('screen', options.screen);
  if (options?.statsView) url.searchParams.set('statsView', options.statsView);
  return url.toString();
};

const readRememberedAppWindowId = (): Promise<number | null> =>
  new Promise((resolve) => {
    chrome.storage.session.get([APP_WINDOW_SESSION_KEY], (stored) => {
      const error = chrome.runtime.lastError;
      resolve(error ? null : normalizeAppWindowId(stored[APP_WINDOW_SESSION_KEY]));
    });
  });

const rememberAppWindowId = (windowId: number): Promise<void> =>
  new Promise((resolve, reject) => {
    appWindowId = windowId;
    chrome.storage.session.set({ [APP_WINDOW_SESSION_KEY]: windowId }, () => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve();
    });
  });

const forgetAppWindowId = async (removedWindowId?: number): Promise<void> => {
  const rememberedWindowId = appWindowId ?? await readRememberedAppWindowId();
  if (removedWindowId !== undefined && rememberedWindowId !== removedWindowId) return;
  appWindowId = null;
  await new Promise<void>((resolve) => {
    chrome.storage.session.remove(APP_WINDOW_SESSION_KEY, () => {
      void chrome.runtime.lastError;
      resolve();
    });
  });
};

const findExistingAppWindowId = async (): Promise<number | null> => {
  const appUrl = chrome.runtime.getURL(APP_WINDOW_URL);
  if (chrome.runtime.getContexts) {
    const contexts = await new Promise<chrome.runtime.ExtensionContext[]>((resolve) => {
      chrome.runtime.getContexts(
        { contextTypes: [chrome.runtime.ContextType.TAB] },
        (items) => {
          void chrome.runtime.lastError;
          resolve(items ?? []);
        }
      );
    });
    const context = contexts.find(
      (item) => item.windowId >= 0 && item.documentUrl?.startsWith(appUrl)
    );
    if (context) {
      await rememberAppWindowId(context.windowId);
      return context.windowId;
    }
  }
  return null;
};

const focusAppWindow = (windowId: number): Promise<boolean> =>
  new Promise((resolve) => {
    chrome.windows.update(windowId, { focused: true }, (window) => {
      const error = chrome.runtime.lastError;
      resolve(!error && typeof window?.id === 'number');
    });
  });

const getKnownAppWindowId = async (): Promise<number | null> => {
  const candidate = appWindowId ?? await readRememberedAppWindowId();
  if (candidate === null) return null;

  return new Promise((resolve) => {
    chrome.windows.get(candidate, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        forgetAppWindowId(candidate).then(() => resolve(null));
        return;
      }
      appWindowId = candidate;
      resolve(candidate);
    });
  });
};

const toggleAppWindowMaximized = async (): Promise<boolean> => {
  const targetWindowId = (await getKnownAppWindowId()) ?? (await findExistingAppWindowId());
  if (targetWindowId === null) return false;
  appWindowId = targetWindowId;

  return new Promise<boolean>((resolve, reject) => {
    chrome.windows.get(targetWindowId, (currentWindow) => {
      const getError = chrome.runtime.lastError;
      if (getError) {
        reject(new Error(getError.message));
        return;
      }

      const nextState = getNextAppWindowState(currentWindow.state);
      chrome.windows.update(targetWindowId, { state: nextState, focused: true }, () => {
        const updateError = chrome.runtime.lastError;
        if (updateError) {
          reject(new Error(updateError.message));
          return;
        }
        resolve(nextState === 'fullscreen');
      });
    });
  });
};

const notifyAppWindowNavigation = async (
  options?: { screen?: string; statsView?: string }
): Promise<void> => {
  if (!options?.screen && !options?.statsView) return;
  await sendMessage({
    type: 'APP_WINDOW_NAVIGATE',
    payload: {
      ...(options.screen === 'timer' || options.screen === 'tasks' || options.screen === 'stats'
        ? { screen: options.screen }
        : {}),
      ...(options.statsView === 'list' || options.statsView === 'chart' || options.statsView === 'review'
        ? { statsView: options.statsView }
        : {})
    }
  });
};

const createAppWindow = (options?: { screen?: string; statsView?: string }): Promise<void> =>
  new Promise((resolve, reject) => {
    chrome.windows.create(
      {
        url: buildAppWindowUrl(options),
        type: 'popup',
        width: APP_WINDOW_WIDTH,
        height: APP_WINDOW_HEIGHT,
        focused: true
      },
      (window) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        const createdWindowId = normalizeAppWindowId(window?.id);
        if (createdWindowId === null) {
          reject(new Error('Chrome did not return the created app window id.'));
          return;
        }
        rememberAppWindowId(createdWindowId).then(resolve, reject);
      }
    );
  });

const openAppWindow = async (
  options?: { screen?: string; statsView?: string }
): Promise<void> => {
  if (openingAppWindow) {
    await openingAppWindow;
    if (appWindowId !== null) {
      await focusAppWindow(appWindowId);
      await notifyAppWindowNavigation(options);
    }
    return;
  }

  openingAppWindow = (async () => {
    const existingId = (await getKnownAppWindowId()) ?? await findExistingAppWindowId();
    if (existingId !== null && await focusAppWindow(existingId)) {
      await rememberAppWindowId(existingId);
      await notifyAppWindowNavigation(options);
      return;
    }
    appWindowId = null;
    await createAppWindow(options);
  })().finally(() => {
    openingAppWindow = null;
  });

  await openingAppWindow;
};

const hasOffscreenDocument = async (): Promise<boolean> => {
  const documentUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
      documentUrls: [documentUrl]
    });
    return contexts.length > 0;
  }

  // runtime.getContexts was introduced in Chrome 116.
  const worker = globalThis as unknown as {
    clients: { matchAll: () => Promise<Array<{ url: string }>> };
  };
  return (await worker.clients.matchAll()).some((client) => client.url === documentUrl);
};

const createOffscreenDocument = async (): Promise<void> => {
  if (await hasOffscreenDocument()) return;
  creatingOffscreenDocument ??= chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: [chrome.offscreen.Reason.AUDIO_PLAYBACK],
    justification: 'Plays the bundled focus music and timer completion sound.'
  }).finally(() => {
    creatingOffscreenDocument = null;
  });
  await creatingOffscreenDocument;
};

const sendAudioMessage = (
  message: Extract<RuntimeMessage, { type: 'OFFSCREEN_SYNC_FOCUS_MUSIC' | 'OFFSCREEN_PLAY_COMPLETION_CHIME' }>,
  timeoutMs: number
): Promise<void> =>
  new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Offscreen audio response timed out.')), timeoutMs);
    chrome.runtime.sendMessage(message, (response?: { ok: boolean; error?: string }) => {
      clearTimeout(timeout);
      const error = chrome.runtime.lastError;
      if (error || !response?.ok) {
        reject(new Error(error?.message ?? response?.error ?? 'Offscreen audio command failed.'));
      } else {
        resolve();
      }
    });
  });

const syncFocusMusic = async (settings: Settings, timerState: TimerState): Promise<void> => {
  const focusSettings = resolveActiveWorkFocusMusicSettings(settings, timerState);
  try {
    if (getFocusMusicDeadline(focusSettings, timerState) !== null) await createOffscreenDocument();
    else if (!(await hasOffscreenDocument())) return;

    await sendAudioMessage({
      type: 'OFFSCREEN_SYNC_FOCUS_MUSIC',
      payload: { settings: focusSettings, timerState }
    }, 3500);
  } catch (error) {
    console.warn('Could not synchronize focus music.', error);
  }
};

const getCompletionAlarmName = ({ isRunning, cycleId, targetEndTime }: TimerState): string | null =>
  isRunning && cycleId && targetEndTime
    ? COMPLETION_ALARM_PREFIX + cycleId + ':' + targetEndTime
    : null;

const syncCompletionAlarm = async (timerState: TimerState): Promise<void> => {
  const activeName = getCompletionAlarmName(timerState);
  const reconcile = async (): Promise<void> => {
    const alarms = await chrome.alarms.getAll();
    if (activeName && !alarms.some(({ name }) => name === activeName)) {
      // Chrome 109 schedules the alarm without a Promise return value.
      await chrome.alarms.create(activeName, { when: timerState.targetEndTime! });
    }
    for (const { name } of alarms) {
      if (name.startsWith(COMPLETION_ALARM_PREFIX) && name !== activeName) {
        await chrome.alarms.clear(name);
      }
    }
  };

  // Timer state is already committed. Retry once without reporting a failed timer action.
  try {
    await reconcile();
  } catch {
    await reconcile().catch((error) => console.warn('Could not reconcile the completion alarm.', error));
  }
};

const runCompletionEffects = async ({ timerState, completion }: TimerCompletionResult): Promise<void> => {
  if (!completion) return;

  try {
    await createOffscreenDocument();
    await sendAudioMessage({ type: 'OFFSCREEN_PLAY_COMPLETION_CHIME' }, 15000);
  } catch (error) {
    console.warn('Could not play the completion sound.', error);
  }

  const locale = resolveLocale(completion.language);
  const title = completion.mode === 'work'
    ? t(locale, 'notificationWorkDone')
    : completion.mode === 'shortBreak'
      ? t(locale, 'notificationBreakDone')
      : t(locale, 'notificationRestDone');
  try {
    chrome.notifications.create(COMPLETION_NOTIFICATION_PREFIX + completion.cycleId, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
      title,
      message: t(locale, 'notificationNextMode', {
        mode: getTimerModeLabel(locale, timerState.currentMode)
      })
    }, () => {
      const error = chrome.runtime.lastError;
      if (error) console.warn('Could not show the completion notification.', error.message);
    });
  } catch (error) {
    console.warn('Could not show the completion notification.', error);
  }

  await enqueueTimerOperation(async () => {
    const current = await readStoredData();
    await syncFocusMusic(current.settings, current.timerState);
  });
};

const reportBackgroundError = (error: unknown): void => {
  console.warn('Could not reconcile the Pomodoro Cult background state.', error);
};

const recoverTimerInQueue = async (data: StoredData): Promise<TimerCompletionResult> => {
  let { timerState } = data;
  if (timerState.isRunning && !timerState.cycleId) {
    timerState = { ...timerState, cycleId: createCycleId(), revision: getNextTimerRevision(timerState) };
    await setLocal({ timerState });
  }

  const result = await completeTimerInQueue({ ...data, timerState });
  await syncCompletionAlarm(result.timerState);
  if (!result.completion) await syncFocusMusic(data.settings, result.timerState);
  return result;
};

const ensureRuntimeReady = async (): Promise<void> => {
  const result = await enqueueTimerOperation(async () => recoverTimerInQueue(await initializeStorage()));
  void runCompletionEffects(result).catch(reportBackgroundError);
};

const buildRunningState = (
  timerState: TimerState,
  mode: TimerMode,
  durationSeconds: number,
  targetEndTime: number,
  activeTaskId: string | null,
  cycleId: string,
  cycleStartedAt: number | null,
  cycleStartedLocalDate: string | null,
  cycleLocalStartMinute: number | null,
  activeCycleSnapshot: FocusModeSnapshot
): TimerState => ({
  ...timerState,
  isRunning: true,
  isPaused: false,
  cycleStarted: true,
  revision: getNextTimerRevision(timerState),
  currentMode: mode,
  remainingSeconds: durationSeconds,
  targetEndTime,
  cycleId,
  cycleStartedAt,
  cycleStartedLocalDate,
  cycleLocalStartMinute,
  activeCycleSnapshot,
  activeTaskId
});

const handleStartTimer = async (mode: TimerMode, startedAt: number): Promise<TimerCompletionResult> => {
  const data = await readStoredData();
  let { tasks } = data;
  const { timerState } = data;

  if (timerState.isRunning) return recoverTimerInQueue(data);

  let activeTaskId = timerState.activeTaskId;
  let nextTasks = tasks;

  if (mode === 'work') {
    nextTasks = ensureNoTask(tasks);
    const selectedTaskExists = nextTasks.some((task) => task.id === timerState.activeTaskId);
    activeTaskId = selectedTaskExists ? timerState.activeTaskId : NO_TASK_ID;
    const now = Date.now();

    nextTasks = sortTasks(
      nextTasks.map((task) =>
        task.id === activeTaskId
          ? {
              ...task,
              usageCount: task.usageCount + 1,
              lastUsed: now
            }
          : task
      )
    );
  }

  const isResume =
    timerState.isPaused &&
    timerState.cycleStarted &&
    timerState.currentMode === mode &&
    timerState.activeCycleSnapshot !== null;
  const activeCycleSnapshot = isResume
    ? timerState.activeCycleSnapshot!
    : mode !== 'work' && timerState.activeCycleSnapshot
      ? timerState.activeCycleSnapshot
      : resolveNextWorkSnapshot({
          focusModes: data.focusModes,
          tasks: nextTasks,
          activeTaskId: activeTaskId ?? null,
          selectedFocusModeId: data.selectedFocusModeId,
          manualSettings: data.manualSettings
        });
  const durationSeconds = isResume
    ? timerState.remainingSeconds
    : getSnapshotDurationSeconds(activeCycleSnapshot, mode);
  const targetEndTime = startedAt + durationSeconds * 1000;
  const cycleId = isResume && timerState.cycleId ? timerState.cycleId : createCycleId();
  const cycleStartedAt = isResume ? timerState.cycleStartedAt : startedAt;
  const cycleStartDate = new Date(startedAt);
  const cycleStartedLocalDate = isResume
    ? timerState.cycleStartedLocalDate
    : getLocalDateKey(cycleStartDate);
  const cycleLocalStartMinute = isResume
    ? timerState.cycleLocalStartMinute
    : getLocalStartMinute(cycleStartDate);
  const nextState = buildRunningState(
    timerState,
    mode,
    durationSeconds,
    targetEndTime,
    activeTaskId ?? null,
    cycleId,
    cycleStartedAt,
    cycleStartedLocalDate,
    cycleLocalStartMinute,
    activeCycleSnapshot
  );

  await setLocal({
    tasks: nextTasks,
    timerState: nextState
  });
  await syncCompletionAlarm(nextState);
  await syncFocusMusic(data.settings, nextState);
  return { timerState: nextState };
};

const handlePauseTimer = async (): Promise<TimerState> => {
  const data = await readStoredData();
  const { timerState } = data;

  if (!timerState.isRunning) {
    return timerState;
  }

  if (timerState.targetEndTime && timerState.targetEndTime <= Date.now()) {
    const result = await completeTimerInQueue(data, false);
    await syncCompletionAlarm(result.timerState);
    await syncFocusMusic(data.settings, result.timerState);
    return result.timerState;
  }

  const remainingSeconds = timerState.targetEndTime
    ? getRunningDisplaySeconds(timerState.targetEndTime)
    : timerState.remainingSeconds;
  const nextState: TimerState = {
    ...timerState,
    isRunning: false,
    isPaused: true,
    revision: getNextTimerRevision(timerState),
    remainingSeconds,
    targetEndTime: null
  };

  await setLocal({ timerState: nextState });
  await syncCompletionAlarm(nextState);
  await syncFocusMusic(data.settings, nextState);
  return nextState;
};

const handleResetTimer = async (): Promise<TimerState> => {
  const data = await readStoredData();
  const { timerState } = await completeTimerInQueue(data, false);
  const nextWorkSnapshot = resolveNextWorkSnapshot({
    focusModes: data.focusModes,
    tasks: data.tasks,
    activeTaskId: timerState.activeTaskId,
    selectedFocusModeId: data.selectedFocusModeId,
    manualSettings: data.manualSettings
  });
  const nextState: TimerState = {
    ...timerState,
    isRunning: false,
    isPaused: false,
    cycleStarted: false,
    revision: getNextTimerRevision(timerState),
    currentMode: 'work',
    remainingSeconds: getSnapshotDurationSeconds(nextWorkSnapshot, 'work'),
    targetEndTime: null,
    cycleId: null,
    cycleStartedAt: null,
    cycleStartedLocalDate: null,
    cycleLocalStartMinute: null,
    activeCycleSnapshot: null,
    completedSessions: 0
  };

  await setLocal({ timerState: nextState });
  await syncCompletionAlarm(nextState);
  await syncFocusMusic(data.settings, nextState);
  return nextState;
};

const handleSkipBreak = async (shortOnly = false): Promise<TimerState> => {
  const data = await readStoredData();
  const { timerState } = data;

  if (timerState.currentMode === 'work' || (shortOnly && timerState.currentMode !== 'shortBreak')) {
    return timerState;
  }

  const nextWorkSnapshot = resolveNextWorkSnapshot({
    focusModes: data.focusModes,
    tasks: data.tasks,
    activeTaskId: timerState.activeTaskId,
    selectedFocusModeId: data.selectedFocusModeId,
    manualSettings: data.manualSettings
  });
  const nextState: TimerState = {
    ...timerState,
    isRunning: false,
    isPaused: false,
    cycleStarted: false,
    revision: getNextTimerRevision(timerState),
    currentMode: 'work',
    remainingSeconds: getSnapshotDurationSeconds(nextWorkSnapshot, 'work'),
    targetEndTime: null,
    cycleId: null,
    cycleStartedAt: null,
    cycleStartedLocalDate: null,
    cycleLocalStartMinute: null,
    activeCycleSnapshot: null
  };

  await setLocal({ timerState: nextState });
  await syncCompletionAlarm(nextState);
  await syncFocusMusic(data.settings, nextState);
  return nextState;
};

const completeTimerInQueue = async (
  data: StoredData,
  allowAutoStart = true
): Promise<TimerCompletionResult> => {
  let { tasks, statistics, sessionEvents } = data;
  const { timerState } = data;
  const { cycleId, currentMode, targetEndTime } = timerState;
  if (!timerState.isRunning || !cycleId || !targetEndTime || targetEndTime > Date.now()) {
    return { timerState };
  }

  const completion = allowAutoStart
    ? { cycleId, mode: currentMode, language: data.settings.languagePreference }
    : undefined;
  if (currentMode === 'work') {
    const snapshot = timerState.activeCycleSnapshot;
    if (!snapshot) return { timerState };
    tasks = ensureNoTask(tasks);
    const activeTaskId = timerState.activeTaskId ?? NO_TASK_ID;
    const activeTask = tasks.find((task) => task.id === activeTaskId);
    const taskTitle = activeTask?.title ?? '';
    const completedSessions = timerState.completedSessions + 1;
    const nextMode =
      completedSessions % snapshot.cyclesBeforeRest === 0 ? 'longBreak' : 'shortBreak';
    const nextDuration = getSnapshotDurationSeconds(snapshot, nextMode);
    const completedAt = Date.now();
    const durationSeconds = getSnapshotDurationSeconds(snapshot, 'work');
    const nextTargetEndTime = (allowAutoStart && snapshot.autoStartBreaks)
      ? completedAt + nextDuration * 1000
      : null;
    const nextCycleId = nextTargetEndTime ? createCycleId() : null;

    statistics = addSessionStatistics(
      statistics,
      activeTaskId,
      taskTitle,
      durationSeconds,
      completedAt
    );
    sessionEvents = [
      ...sessionEvents,
      createSessionEvent({
        cycleId: timerState.cycleId,
        taskId: activeTaskId,
        taskTitleSnapshot: taskTitle,
        focusModeId: snapshot.appliedFocusModeId,
        cycleStartedAt: timerState.cycleStartedAt,
        cycleStartedLocalDate: timerState.cycleStartedLocalDate,
        cycleLocalStartMinute: timerState.cycleLocalStartMinute,
        completedAt,
        durationSeconds
      })
    ];

    const nextState: TimerState = {
      ...timerState,
      isRunning: (allowAutoStart && snapshot.autoStartBreaks),
      isPaused: false,
      revision: getNextTimerRevision(timerState),
      currentMode: nextMode,
      remainingSeconds: nextDuration,
      targetEndTime: nextTargetEndTime,
      cycleId: nextCycleId,
      cycleStartedAt: nextTargetEndTime ? completedAt : null,
      cycleStartedLocalDate: nextTargetEndTime
        ? getLocalDateKey(new Date(completedAt))
        : null,
      cycleLocalStartMinute: nextTargetEndTime
        ? getLocalStartMinute(new Date(completedAt))
        : null,
      activeTaskId,
      completedSessions
    };

    await setLocal({
      tasks,
      statistics,
      sessionEvents,
      timerState: nextState
    });

    return { timerState: nextState, completion };
  }

  const patch = prepareWorkAfterBreak(data, Date.now(), createCycleId, allowAutoStart);
  await setLocal(patch);
  return { timerState: patch.timerState, completion };
};

const handleDeleteTaskStatistics = async (taskId: string) => {
  const { statistics, sessionEvents } = await readStoredData();
  const nextStatistics = removeTaskStatistics(statistics, taskId);
  const nextSessionEvents = removeTaskSessionEvents(sessionEvents, taskId);
  await setLocal({ statistics: nextStatistics, sessionEvents: nextSessionEvents });
  return { statistics: nextStatistics, sessionEvents: nextSessionEvents };
};

const handleSaveFocusReviewGoals = async (payload: unknown) => {
  if (!isFocusReviewGoalsPayload(payload)) {
    throw new Error('Invalid Focus Review goals payload.');
  }
  const focusReviewGoals = normalizeFocusReviewGoals(payload);
  await setLocal({ focusReviewGoals });
  return { focusReviewGoals };
};

const handleFocusModeMutation = async (message: FocusModeMutationMessage) => {
  const now = Date.now();
  const readResult = await readStoredDataResult();
  const data = readResult.data;
  const result = applyFocusModeMutation(data, message, {
    now,
    includePlanningCascade: readResult.storageIntegrity.status !== 'blocked'
  });
  const nextData = { ...data, ...result.patch };
  const nextWorkSnapshot = resolveNextWorkSnapshot({
    focusModes: nextData.focusModes,
    tasks: nextData.tasks,
    activeTaskId: nextData.timerState.activeTaskId,
    selectedFocusModeId: nextData.selectedFocusModeId,
    manualSettings: nextData.manualSettings
  });
  const timerState = !nextData.timerState.cycleStarted && nextData.timerState.currentMode === 'work'
    ? {
        ...nextData.timerState,
        revision: getNextTimerRevision(nextData.timerState),
        remainingSeconds: getSnapshotDurationSeconds(nextWorkSnapshot, 'work'),
        activeCycleSnapshot: null
      }
    : nextData.timerState;
  const patch = timerState === nextData.timerState ? result.patch : { ...result.patch, timerState };
  await setLocal(patch);
  if (message.type === 'SAVE_FOCUS_MUSIC_SETTINGS') {
    await syncFocusMusic(nextData.settings, timerState);
  }
  return { ...patch, ...(result.focusModeId ? { focusModeId: result.focusModeId } : {}) };
};

const getPlanningRuntimeState = async () => {
  const context = createRuntimePlanningContext();
  const readResult = await readStoredDataResult();
  return {
    data: readResult.data,
    storageIntegrity: readResult.storageIntegrity,
    accessContext: getAuthoritativeAccessContext(),
    scheduleEvaluations: readResult.data.focusPlanSchedules.map((schedule) => ({
      scheduleId: schedule.id,
      evaluation: evaluateFocusPlanSchedule(schedule, context.today)
    }))
  };
};

const handlePlanningMutation = async (message: PlanningMessage) => {
  const context = createRuntimePlanningContext();
  const readResult = await readStoredDataResult();
  if (readResult.storageIntegrity.status === 'blocked') {
    throw new Error(readResult.storageIntegrity.reason);
  }
  const accessContext = getAuthoritativeAccessContext();
  const result = applyFocusPlanMutation(readResult.data, message, accessContext, context);
  if (Object.keys(result.patch).length > 0) await setLocal(result.patch);
  const data = { ...readResult.data, ...result.patch };
  return {
    data,
    storageIntegrity: readResult.storageIntegrity,
    accessContext,
    scheduleEvaluations: data.focusPlanSchedules.map((schedule) => ({
      scheduleId: schedule.id,
      evaluation: evaluateFocusPlanSchedule(schedule, context.today)
    })),
    ...(result.run ? { run: result.run } : {})
  };
};

const handleTaskMutation = async (message: TaskMutationMessage) => {
  const data = await readStoredData();
  const result = applyTaskMutation(data, message);
  const nextData = { ...data, ...result.patch };
  const nextWorkSnapshot = resolveNextWorkSnapshot({
    focusModes: nextData.focusModes,
    tasks: nextData.tasks,
    activeTaskId: nextData.timerState.activeTaskId,
    selectedFocusModeId: nextData.selectedFocusModeId,
    manualSettings: nextData.manualSettings
  });
  const timerState = !nextData.timerState.cycleStarted && nextData.timerState.currentMode === 'work'
    ? {
        ...nextData.timerState,
        revision: getNextTimerRevision(nextData.timerState),
        remainingSeconds: getSnapshotDurationSeconds(nextWorkSnapshot, 'work'),
        activeCycleSnapshot: null
      }
    : nextData.timerState;
  const patch = timerState === nextData.timerState ? result.patch : { ...result.patch, timerState };
  await setLocal(patch);
  return { ...patch, ...(result.taskId ? { taskId: result.taskId } : {}) };
};

chrome.runtime.onInstalled.addListener(() => {
  void ensureRuntimeReady().catch(reportBackgroundError);
});

chrome.runtime.onStartup.addListener(() => {
  void ensureRuntimeReady().catch(reportBackgroundError);
});

const completeScheduledTimer = (name: string): Promise<TimerCompletionResult | undefined> =>
  enqueueTimerOperation(async () => {
    const data = await readStoredData();
    if (getCompletionAlarmName(data.timerState) !== name) return;

    const result = await completeTimerInQueue(data);
    await syncCompletionAlarm(result.timerState);
    return result;
  });

chrome.alarms.onAlarm.addListener(({ name }) => {
  if (!name.startsWith(COMPLETION_ALARM_PREFIX)) return;

  void completeScheduledTimer(name).catch(async () => {
    // A one-shot alarm is already consumed. Retry a transient storage failure once.
    await new Promise((resolve) => setTimeout(resolve, 1000));
    return completeScheduledTimer(name);
  }).then((result) => {
    if (result) return runCompletionEffects(result);
  }).catch(reportBackgroundError);
});

chrome.notifications.onClicked.addListener((notificationId) => {
  if (!notificationId.startsWith(COMPLETION_NOTIFICATION_PREFIX)) return;

  void openAppWindow().then(() => {
    chrome.notifications.clear(notificationId, () => {
      void chrome.runtime.lastError;
    });
  }).catch(reportBackgroundError);
});

chrome.windows.onRemoved.addListener((windowId) => {
  void forgetAppWindowId(windowId);
});

chrome.runtime.onMessage.addListener((message: RuntimeMessage, _sender, sendResponse) => {
  const respond = async (): Promise<void> => {
    if (!message?.type) {
      sendResponse({ ok: false, error: 'Unknown message' });
      return;
    }

    const diagnosticsResponse = await runtimeAccessDiagnostics?.handleMessage(message);
    if (diagnosticsResponse) {
      sendResponse(diagnosticsResponse);
      return;
    }

    switch (message.type) {
      case 'POPUP_ENSURE_READY':
        await ensureRuntimeReady();
        sendResponse({ ok: true });
        return;
      case 'GET_ACCESS_CONTEXT':
        sendResponse({ ok: true, accessContext: getAuthoritativeAccessContext() });
        return;
      case 'ACCESS_CONTEXT_CHANGED':
        sendResponse({ ok: true, ignored: true });
        return;
      case 'GET_PLANNING_STATE':
        sendResponse({ ok: true, ...(await enqueueTimerOperation(getPlanningRuntimeState)) });
        return;
      case 'OPEN_APP_WINDOW':
        await openAppWindow(message.payload);
        sendResponse({ ok: true });
        return;
      case 'APP_WINDOW_READY':
        await rememberAppWindowId(message.payload.windowId);
        sendResponse({ ok: true });
        return;
      case 'APP_WINDOW_CLOSED':
        await forgetAppWindowId();
        sendResponse({ ok: true });
        return;
      case 'TOGGLE_APP_WINDOW_MAXIMIZED':
        sendResponse({ ok: true, maximized: await toggleAppWindowMaximized() });
        return;
      case 'POPUP_START_TIMER': {
        const result = await enqueueTimerOperation(() =>
          handleStartTimer(message.payload.mode, message.payload.startedAt)
        );
        void runCompletionEffects(result).catch(reportBackgroundError);
        sendResponse({ ok: true, timerState: result.timerState });
        return;
      }
      case 'POPUP_PAUSE_TIMER':
        sendResponse({ ok: true, timerState: await enqueueTimerOperation(handlePauseTimer) });
        return;
      case 'POPUP_RESET_TIMER':
        sendResponse({ ok: true, timerState: await enqueueTimerOperation(handleResetTimer) });
        return;
      case 'POPUP_SKIP_BREAK':
        sendResponse({ ok: true, timerState: await enqueueTimerOperation(() => handleSkipBreak()) });
        return;

      case 'POPUP_SKIP_SHORT_BREAK':
        sendResponse({ ok: true, timerState: await enqueueTimerOperation(() => handleSkipBreak(true)) });
        return;
      case 'DELETE_TASK_STATISTICS': {
        const result = await enqueueTimerOperation(() =>
          handleDeleteTaskStatistics(message.payload.taskId)
        );
        sendResponse({ ok: true, ...result });
        return;
      }
      case 'SAVE_FOCUS_REVIEW_GOALS': {
        const result = await enqueueTimerOperation(() =>
          handleSaveFocusReviewGoals(message.payload)
        );
        sendResponse({ ok: true, ...result });
        return;
      }
      case 'IMPORT_USER_DATA': {
        const data = await enqueueTimerOperation(async () => {
          const imported = await importStoredData(message.payload.raw);
          await syncCompletionAlarm(imported.timerState);
          await syncFocusMusic(imported.settings, imported.timerState);
          return imported;
        });
        sendResponse({ ok: true, data });
        return;
      }
      case 'SELECT_FOCUS_MODE':
      case 'CREATE_FOCUS_MODE':
      case 'UPDATE_FOCUS_MODE':
      case 'DELETE_FOCUS_MODE':
      case 'SET_TASK_FOCUS_MODE':
      case 'SAVE_MANUAL_SETTINGS':
      case 'SAVE_FOCUS_MUSIC_SETTINGS': {
        const result = await enqueueTimerOperation(() => handleFocusModeMutation(message));
        sendResponse({ ok: true, ...result });
        return;
      }
      case 'SELECT_TASK':
      case 'ADD_TASK':
      case 'UPDATE_TASK':
      case 'DELETE_TASK':
      case 'ARCHIVE_TASK':
      case 'RESTORE_TASK': {
        const result = await enqueueTimerOperation(() => handleTaskMutation(message));
        sendResponse({ ok: true, ...result });
        return;
      }
      case 'CREATE_TASK_TEMPLATE':
      case 'UPDATE_TASK_TEMPLATE':
      case 'DELETE_TASK_TEMPLATE':
      case 'CREATE_FOCUS_PLAN':
      case 'UPDATE_FOCUS_PLAN':
      case 'DELETE_FOCUS_PLAN':
      case 'CREATE_FOCUS_PLAN_SCHEDULE':
      case 'UPDATE_FOCUS_PLAN_SCHEDULE':
      case 'SET_FOCUS_PLAN_SCHEDULE_ENABLED':
      case 'DELETE_FOCUS_PLAN_SCHEDULE':
      case 'START_FOCUS_PLAN':
      case 'SKIP_FOCUS_PLAN_OCCURRENCE': {
        const planningMessage = parsePlanningMessage(message);
        const result = await enqueueTimerOperation(() => handlePlanningMutation(planningMessage));
        sendResponse({ ok: true, ...result });
        return;
      }
      default:
        sendResponse({ ok: true, ignored: true });
    }
  };

  respond().catch((error) => {
    sendResponse({
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    });
  });

  return true;
});

// The worker can be recreated without onStartup or onInstalled firing again.
void ensureRuntimeReady().catch(reportBackgroundError);
