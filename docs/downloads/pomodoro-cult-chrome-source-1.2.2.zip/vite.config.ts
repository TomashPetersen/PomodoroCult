import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { crx } from '@crxjs/vite-plugin';
import chromeManifest from './manifest.json';
import firefoxManifest from './manifest.firefox';

const runtimeEnv = (globalThis as typeof globalThis & {
  process?: { env?: Record<string, string | undefined> };
}).process?.env;

const resolvedTargetBrowser =
  runtimeEnv?.TARGET_BROWSER === 'firefox' || runtimeEnv?.npm_lifecycle_event === 'build:firefox'
    ? 'firefox'
    : 'chrome';
const manifest = resolvedTargetBrowser === 'firefox' ? firefoxManifest : chromeManifest;
const rollupInput: Record<string, string> = resolvedTargetBrowser === 'firefox'
  ? { popup: 'index.html', app: 'app.html', background: 'background-firefox.html' }
  : { popup: 'index.html', app: 'app.html', offscreen: 'offscreen.html' };

const createRuntimeAccessVirtualPlugin = (development: boolean) => {
  const runtimeId = 'virtual:pomodoro-runtime-access';
  const uiId = 'virtual:pomodoro-access-ui';
  const resolvedRuntimeId = `\0${runtimeId}`;
  const resolvedUiId = `\0${uiId}`;

  return {
    name: 'pomodoro-runtime-access-boundary',
    enforce: 'pre' as const,
    resolveId(id: string) {
      if (id === runtimeId) return resolvedRuntimeId;
      if (id === uiId) return resolvedUiId;
      return null;
    },
    load(id: string) {
      if (id === resolvedRuntimeId) {
        return development
          ? `export { registerRuntimeAccessDiagnostics } from '/src/dev/accessSimulatorRuntime.ts';`
          : `export const registerRuntimeAccessDiagnostics = () => null;`;
      }
      if (id === resolvedUiId) {
        return development
          ? `export { default } from '/src/dev/RuntimeAccessDiagnosticsPanel.tsx';`
          : `export default function RuntimeAccessDiagnosticsSlot() { return null; }`;
      }
      return null;
    }
  };
};

export default defineConfig(({ command }) => ({
  plugins: [createRuntimeAccessVirtualPlugin(command === 'serve'), react(), crx({ manifest: manifest as never })],
  define: {
    __APP_VERSION__: JSON.stringify(manifest.version)
  },
  build: {
    outDir: resolvedTargetBrowser === 'firefox' ? 'dist-firefox' : 'dist',
    sourcemap: resolvedTargetBrowser === 'firefox',
    emptyOutDir: true,
    rollupOptions: {
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]',
        sourcemapPathTransform: (sourcePath) =>
          /^(?:\.\.[\\/])+@crx[\\/]manifest$/.test(sourcePath) ? '/@crx/manifest' : sourcePath,
        hashCharacters: 'hex'
      },
      input: rollupInput
    }
  }
}));
