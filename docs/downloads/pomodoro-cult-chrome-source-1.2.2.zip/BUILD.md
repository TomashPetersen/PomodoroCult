# Pomodoro Cult 1.2.2 - исходные файлы для Chrome

Расширение распространяется по Mozilla Public License 2.0. Текст лицензии
находится в файле LICENSE. Сведения об авторах звуков находятся в
docs/chrome-store/audio-credits.txt.

## Сборка

Распакуйте архив в отдельную папку. Проверено на Windows с Node.js 24.15.0,
npm 11.12.1 и PowerShell 7.6.9.

```powershell
npm.cmd ci --no-audit --no-fund
$env:TARGET_BROWSER = 'chrome'
npm.cmd run build
.\scripts\package-chrome-artifacts.ps1
```

Если зависимости уже есть в локальном кеше, подходит команда
`npm.cmd ci --offline --no-audit --no-fund`.

Результат сборки: artifacts/pomodoro-cult-chrome-1.2.2.zip.
Проверенная контрольная сумма SHA-256: 6a182e5e43e8f768dd1d07d0cfb11904b8bb19143e0d5505b8b8900697a77030.

Этот архив содержит необходимые файлы для сборки Chrome. Он не является
полным архивом сборки Firefox. Исправление 1.2.2 меняет только номер
Chrome и четыре значка. Работа таймера и формат пользовательских данных
совпадают с Chrome 1.2.1.
